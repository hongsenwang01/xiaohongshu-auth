/**
 * 过滤名单模板与解析（Excel SpreadsheetML .xls，两列：小红书昵称, 小红书号）
 * - 下载模板：包含两个sheet页（过滤列表、重点关注列表）
 * - 上传解析：昵称必填，小红书号可选
 * - 存储：同时保存 entries（结构化）与 usernames（扁平化便于快速匹配）
 */

// 生成包含两个sheet页的完整模板
export function generateFilterTemplate() {
  const headers = ['小红书昵称', '小红书号'];
  const headerCells = headers.map(v => `<Cell><Data ss:Type="String">${escapeXml(v)}</Data></Cell>`).join('');
  
  const xml = `<?xml version="1.0"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
 <Worksheet ss:Name="过滤列表">
  <Table>
   <Row>${headerCells}</Row>
  </Table>
 </Worksheet>
 <Worksheet ss:Name="重点关注列表">
  <Table>
   <Row>${headerCells}</Row>
  </Table>
 </Worksheet>
</Workbook>`;
  return new Blob([xml], { type: 'application/vnd.ms-excel' });
}

// 兼容旧版本的函数（已废弃，但保留以防兼容性问题）
export function generateExcludeListTemplate() {
  return generateFilterTemplate();
}

export function generateFocusListTemplate() {
  return generateFilterTemplate();
}

function escapeXml(s) {
  return String(s || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

// 生成可下载链接并触发下载
export function downloadTemplate(blob, filename) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename || 'template.xls';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// 解析上传的 .xls（SpreadsheetML XML，来源于本模板）
// 返回对象：{ excludeList: [], focusList: [] }
export async function parseExcelFile(file) {
  return new Promise((resolve, reject) => {
    const name = (file?.name || '').toLowerCase();
    if (!name.endsWith('.xls')) {
      reject(new Error('请上传模板生成的Excel(.xls)文件'));
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const xml = decodeToText(e.target.result);
        const result = parseSpreadsheetMLWithSheets(xml);
        resolve(result);
      } catch (err) {
        reject(new Error('文件解析失败: ' + err.message));
      }
    };
    reader.onerror = () => reject(new Error('文件读取失败'));
    reader.readAsArrayBuffer(file);
  });
}

// 兼容旧版本：解析单个sheet（已废弃）
export async function parseExcelFileLegacy(file) {
  return new Promise((resolve, reject) => {
    const name = (file?.name || '').toLowerCase();
    if (!name.endsWith('.xls')) {
      reject(new Error('请上传模板生成的Excel(.xls)文件'));
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const xml = decodeToText(e.target.result);
        const entries = parseSpreadsheetML(xml);
        resolve(entries);
      } catch (err) {
        reject(new Error('文件解析失败: ' + err.message));
      }
    };
    reader.onerror = () => reject(new Error('文件读取失败'));
    reader.readAsArrayBuffer(file);
  });
}

function decodeToText(arrayBuffer) {
  const bytes = new Uint8Array(arrayBuffer);
  // UTF-16 BOM
  if (bytes.length >= 2 && bytes[0] === 0xFF && bytes[1] === 0xFE) {
    return new TextDecoder('utf-16le').decode(bytes);
  }
  if (bytes.length >= 2 && bytes[0] === 0xFE && bytes[1] === 0xFF) {
    return new TextDecoder('utf-16be').decode(bytes);
  }
  try { return new TextDecoder('utf-8', { fatal: true }).decode(bytes); } catch {}
  return new TextDecoder('utf-8', { fatal: false }).decode(bytes);
}

// 解析包含多个sheet的SpreadsheetML
function parseSpreadsheetMLWithSheets(xml) {
  const worksheetRegex = /<Worksheet[\s\S]*?ss:Name="([^"]*)"[\s\S]*?>([\s\S]*?)<\/Worksheet>/gi;
  const sheets = {};
  let match;
  
  while ((match = worksheetRegex.exec(xml)) !== null) {
    const sheetName = match[1];
    const sheetContent = match[2];
    sheets[sheetName] = parseSheetContent(sheetContent);
  }
  
  return {
    excludeList: sheets['过滤列表'] || [],
    focusList: sheets['重点关注列表'] || []
  };
}

// 解析单个sheet的内容
function parseSheetContent(sheetXml) {
  const rows = [];
  const rowRegex = /<Row[\s\S]*?>[\s\S]*?<\/Row>/gi;
  let m;
  while ((m = rowRegex.exec(sheetXml)) !== null) {
    rows.push(m[0]);
  }
  if (rows.length <= 1) return [];
  
  const entries = [];
  for (let i = 1; i < rows.length; i++) { // 从第二行开始
    const row = rows[i];
    const cells = [];
    const cellRegex = /<Cell[\s\S]*?>[\s\S]*?<\/Cell>/gi;
    let cm;
    while ((cm = cellRegex.exec(row)) !== null) {
      const cellXml = cm[0];
      const dataMatch = cellXml.match(/<Data[\s\S]*?>([\s\S]*?)<\/Data>/i);
      const val = dataMatch ? unescapeXml(dataMatch[1]).trim() : '';
      cells.push(val);
    }
    const nickname = (cells[0] || '').trim();
    const redId = (cells[1] || '').trim();
    if (!nickname && !redId) continue;
    if (!nickname) continue;
    entries.push({ nickname, redId });
  }
  return entries;
}

// 解析 SpreadsheetML（Excel 2003 XML）为 entries（兼容旧版本）
function parseSpreadsheetML(xml) {
  const rows = [];
  const rowRegex = /<Row[\s\S]*?>[\s\S]*?<\/Row>/gi;
  let m;
  while ((m = rowRegex.exec(xml)) !== null) {
    rows.push(m[0]);
  }
  if (rows.length <= 1) return [];
  const entries = [];
  for (let i = 1; i < rows.length; i++) { // 从第二行开始
    const row = rows[i];
    const cells = [];
    const cellRegex = /<Cell[\s\S]*?>[\s\S]*?<\/Cell>/gi;
    let cm;
    while ((cm = cellRegex.exec(row)) !== null) {
      const cellXml = cm[0];
      const dataMatch = cellXml.match(/<Data[\s\S]*?>([\s\S]*?)<\/Data>/i);
      const val = dataMatch ? unescapeXml(dataMatch[1]).trim() : '';
      cells.push(val);
    }
    const nickname = (cells[0] || '').trim();
    const redId = (cells[1] || '').trim();
    if (!nickname && !redId) continue;
    if (!nickname) continue;
    entries.push({ nickname, redId });
  }
  return entries;
}

function unescapeXml(s) {
  return String(s || '')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, '&');
}

// 校验：昵称必填（1-100），小红书号可选（<=100）
// 支持新格式：{ excludeList: [], focusList: [] }
export function validateUsernames(data) {
  // 新格式：包含两个列表
  if (data && typeof data === 'object' && ('excludeList' in data || 'focusList' in data)) {
    const excludeList = data.excludeList || [];
    const focusList = data.focusList || [];
    
    const excludeValidation = validateEntriesList(excludeList);
    const focusValidation = validateEntriesList(focusList);
    
    if (!excludeValidation.valid && !focusValidation.valid) {
      return { valid: false, message: '两个列表都为空或无效' };
    }
    
    const messages = [];
    if (excludeList.length > 0) {
      messages.push(`过滤列表: ${excludeList.length} 个用户`);
    }
    if (focusList.length > 0) {
      messages.push(`重点关注: ${focusList.length} 个用户`);
    }
    
    return {
      valid: true,
      message: `成功加载 ${messages.join('，')}`,
      excludeCount: excludeList.length,
      focusCount: focusList.length
    };
  }
  
  // 旧格式：单个数组（兼容）
  return validateEntriesList(data);
}

// 验证单个列表
function validateEntriesList(entries) {
  if (Array.isArray(entries) && entries.length && typeof entries[0] === 'string') {
    entries = entries.map(n => ({ nickname: String(n || '').trim(), redId: '' }));
  }
  if (!entries || entries.length === 0) return { valid: false, message: '列表为空', count: 0 };
  if (entries.length > 1000) return { valid: false, message: '用户数量不能超过1000', count: 0 };
  let invalid = 0;
  for (const e of entries) {
    const nickname = (e?.nickname || '').trim();
    const redId = (e?.redId || '').trim();
    if (!nickname || nickname.length > 100) { invalid++; continue; }
    if (redId && redId.length > 100) { invalid++; }
  }
  if (invalid > 0) return { valid: false, message: `发现 ${invalid} 条无效数据（昵称必填，长度1-100；小红书号可选）`, count: 0 };
  return { valid: true, message: `成功加载 ${entries.length} 个用户`, count: entries.length };
}

// 保存：同时保存 entries 与扁平化的匹配数组（兼容旧逻辑）
export async function saveUsernamesToStorage(key, entries) {
  const flat = [];
  if (Array.isArray(entries)) {
    for (const e of entries) {
      const n = (e?.nickname || '').trim();
      const r = (e?.redId || '').trim();
      if (n) flat.push(n);
      if (r) flat.push(r);
    }
  }
  return new Promise((resolve, reject) => {
    const data = {
      usernames: flat,            // 兼容旧逻辑：用于快速匹配（包含昵称与小红书号）
      entries: Array.isArray(entries) ? entries : [],
      timestamp: new Date().toISOString(),
      count: Array.isArray(entries) ? entries.length : 0, // 行数
    };
    chrome.storage.local.set({ [key]: data }, () => {
      if (chrome.runtime.lastError) reject(new Error('保存失败: ' + chrome.runtime.lastError.message));
      else resolve(data);
    });
  });
}

export async function getUsernamesFromStorage(key) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get([key], (result) => {
      if (chrome.runtime.lastError) reject(new Error('读取失败: ' + chrome.runtime.lastError.message));
      else resolve(result[key] || null);
    });
  });
}

export async function clearUsernamesFromStorage(key) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.remove(key, () => {
      if (chrome.runtime.lastError) reject(new Error('清除失败: ' + chrome.runtime.lastError.message));
      else resolve();
    });
  });
}

