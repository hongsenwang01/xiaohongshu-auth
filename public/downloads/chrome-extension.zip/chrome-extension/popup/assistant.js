import { MESSAGE_TYPES } from '../shared/constants.js';
import { checkIsXhsPage } from './services/message.js';
import { getBrowseState, restoreTaskId } from './services/state.js';
import { showToast } from './ui/toast.js';
import { showPageDetectCard, showNormalUI } from './ui/page-detect.js';
import { handleBrowseUpdate } from './handlers/browse.js';
import { launchXiaohongshu } from './utils/helpers.js';
import { 
    loadHistoryStats, 
    viewHistory, 
    hideHistory, 
    exportHistoryToFile, 
    clearHistoryRecords 
} from './handlers/history.js';
import { initFilterOptions } from './handlers/filter.js';

import { tabController } from './controllers/tab-controller.js';
import { configController } from './controllers/config-controller.js';
import { browseController } from './controllers/browse-controller.js';
import { fetchController } from './controllers/fetch-controller.js';

class XiaohongshuAssistant {
    constructor() {
        this.posts = [];
        this.isFetchingPosts = false;
        this.fetchedPosts = [];
        this.init();
    }

    async init() {
        const isXhsPage = await checkIsXhsPage();
        if (!isXhsPage) {
            this.showPageDetect();
            return;
        }

        this.showNormal();
        await this.restoreState();
        this.bindEvents();
        initFilterOptions();
        this.initTabState();
        this.listenToMessages();
        await loadHistoryStats();
        await this.restoreDurationConfig();
        await this.restoreBrowseCountConfig();
        await this.restoreToggleStates();
        await this.restoreCommentContents();
        await this.restoreCollapseStates();
    }

    showPageDetect() {
        showPageDetectCard();

        const launchBtn = document.getElementById('launchXhsBtn');
        if (!launchBtn) return;

        launchBtn.addEventListener('click', async () => {
            try {
                showToast('正在打开小红书...', 'info');
                await launchXiaohongshu();
            } catch (error) {
                showToast('启动失败，请手动打开小红书页面', 'error');
            }
        });
    }

    showNormal() {
        showNormalUI();
    }

    bindEvents() {
        this.bindTabEvents();
        this.bindHelpTooltip();
        this.bindDurationInputs();
        this.bindToggleEvents();
        this.bindCollapsibleHeaders();

        const startBrowseBtn = document.getElementById('startBrowseBtn');
        const stopBrowseBtn = document.getElementById('stopBrowseBtn');
        const viewHistoryBtn = document.getElementById('viewHistoryBtn');
        const exportHistoryBtn = document.getElementById('exportHistoryBtn');
        const clearHistoryBtn = document.getElementById('clearHistoryBtn');
        const backBtn = document.getElementById('backBtn');

        if (startBrowseBtn) {
            startBrowseBtn.addEventListener('click', () => this.handleStartBrowse());
        }

        if (stopBrowseBtn) {
            stopBrowseBtn.addEventListener('click', () => this.handleStopBrowse());
        }


        if (viewHistoryBtn) {
            let historyVisible = false;
            viewHistoryBtn.addEventListener('click', () => {
                if (historyVisible) {
                    hideHistory();
                    viewHistoryBtn.textContent = '查看历史';
                } else {
                    viewHistory();
                    viewHistoryBtn.textContent = '隐藏历史';
                }
                historyVisible = !historyVisible;
            });
        }

        if (exportHistoryBtn) {
            exportHistoryBtn.addEventListener('click', () => exportHistoryToFile());
        }

        if (clearHistoryBtn) {
            clearHistoryBtn.addEventListener('click', () => clearHistoryRecords());
        }

        if (backBtn) {
            backBtn.addEventListener('click', () => {
                window.location.href = chrome.runtime.getURL('popup.html');
            });
        }
    }

    listenToMessages() {
        chrome.runtime.onMessage.addListener((message) => {
            if (message.action === MESSAGE_TYPES.BROWSE_UPDATE) {
                handleBrowseUpdate(message);
            }
        });
    }

    async restoreState() {
        try {
            const taskId = restoreTaskId();
            if (!taskId) {
                this.setButtonState('idle');
                return;
            }

            const state = await getBrowseState(taskId);
            if (state && state.isRunning) {
                console.log('✅ 检测到任务正在运行，恢复UI状态');
                this.setButtonState('browsing');
                if (state.posts && state.posts.length > 0) {
                    this.posts = state.posts;
                    console.log(`🔄 恢复任务进度: ${state.currentIndex}/${state.totalPosts}`);
                }
            } else {
                this.setButtonState('idle');
            }
        } catch (error) {
            console.error('恢复状态失败:', error);
            this.setButtonState('idle');
        }
    }

}

Object.assign(
    XiaohongshuAssistant.prototype,
    tabController,
    configController,
    browseController,
    fetchController
);

export default XiaohongshuAssistant;
