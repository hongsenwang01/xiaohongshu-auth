// 快速涨粉页面脚本
import { MESSAGE_TYPES } from '../shared/constants.js';
import { showToast } from './ui/toast.js';
import { addFollowedUser, getFollowedUserNames } from './services/followed-users.js';
import { initFollowedUsersController } from './controllers/followed-users-controller.js';
import { uploadFollowList } from './services/license.js';
import { getCachedUserInfo } from './services/cache.js';

// 执行状态管理
let isExecuting = false;
let shouldStop = false;
let currentWindowId = null;

/**
 * 获取当前窗口ID
 * @returns {Promise<number|null>}
 */
async function getCurrentWindowId() {
    try {
        const window = await chrome.windows.getCurrent();
        return window.id;
    } catch (error) {
        console.error('[QuickFollow] 获取窗口ID失败:', error);
        return null;
    }
}

/**
 * 发送消息到标签页（带重试机制）
 * @param {number} tabId - 标签页ID
 * @param {object} message - 消息对象
 * @param {number} maxRetries - 最大重试次数
 * @returns {Promise<object>} 响应对象
 */
async function sendMessageWithRetry(tabId, message, maxRetries = 3) {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            const response = await chrome.tabs.sendMessage(tabId, message);
            return response;
        } catch (error) {
            if (attempt < maxRetries) {
                console.log(`[Retry] 第 ${attempt} 次尝试失败，等待1秒后重试...`);
                await new Promise(resolve => setTimeout(resolve, 1000));
            } else {
                throw error;
            }
        }
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    // 获取当前窗口ID
    currentWindowId = await getCurrentWindowId();
    console.log('[QuickFollow] 当前窗口ID:', currentWindowId);
    
    // 初始化已关注用户列表控制器
    await initFollowedUsersController();
    
    // 返回按钮
    const backBtn = document.getElementById('backBtn');
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            window.location.href = chrome.runtime.getURL('popup.html');
        });
    }

    // 开始/停止执行按钮
    const executeBtn = document.getElementById('executeBtn');
    if (executeBtn) {
        executeBtn.addEventListener('click', async () => {
            // 如果正在执行，则停止
            if (isExecuting) {
                console.log('[QuickFollow] 用户请求停止执行');
                shouldStop = true;
                showToast('正在停止...', 'info');
                executeBtn.disabled = true;
                return;
            }
            
            // 开始执行
            const searchKeyword = document.getElementById('searchKeyword')?.value?.trim() || '互关';
            const followCount = document.getElementById('followCount')?.value || 10;
            const commentContent = document.getElementById('commentContent')?.value || '';
            const timeRange = parseInt(document.getElementById('timeRange')?.value || '1440', 10); // 默认1440分钟（24小时）
            const includeSubComments = document.getElementById('includeSubComments')?.checked ?? true; // 默认开启二级评论
            
            console.log('[QuickFollow] 开始执行快速涨粉');
            console.log('[QuickFollow] 配置:', { searchKeyword, followCount, commentContent, timeRange, includeSubComments });
            
            // 更新按钮状态
            isExecuting = true;
            shouldStop = false;
            updateExecuteButton(executeBtn, true);
            
            try {
                // 获取当前标签页
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                if (!tab || !tab.url.includes('xiaohongshu.com')) {
                    showToast('请在小红书页面使用此功能', 'error');
                    isExecuting = false;
                    updateExecuteButton(executeBtn, false);
                    return;
                }
                
                // 从缓存中获取当前用户的小红书号（用于上传到服务器）
                let ownerRedid = '';
                try {
                    const cachedUserInfo = await getCachedUserInfo(currentWindowId);
                    if (cachedUserInfo) {
                        ownerRedid = cachedUserInfo.redId || cachedUserInfo.userId || '';
                        console.log('[QuickFollow] ✅ 从缓存读取当前用户小红书号:', ownerRedid);
                        console.log('[QuickFollow] 缓存的用户信息:', {
                            userId: cachedUserInfo.userId,
                            redId: cachedUserInfo.redId,
                            username: cachedUserInfo.username
                        });
                    } else {
                        console.warn('[QuickFollow] ⚠️ 缓存中没有用户信息');
                    }
                } catch (error) {
                    console.error('[QuickFollow] ❌ 读取缓存用户信息失败:', error);
                }
                
                // 初始化关注列表收集器（用于上传到服务器）
                const followListForUpload = [];
                
                // 第一步：搜索关键词
                showToast(`正在搜索"${searchKeyword}"关键词...`, 'info');
                const searchResponse = await chrome.tabs.sendMessage(tab.id, {
                    action: MESSAGE_TYPES.SEARCH_KEYWORD,
                    keyword: searchKeyword
                });
                
                if (searchResponse && searchResponse.success) {
                    showToast('搜索成功！', 'success');
                    console.log('[QuickFollow] ✅ 搜索成功');
                    
                    // 等待搜索结果加载
                    await new Promise(resolve => setTimeout(resolve, 2000));
                    
                    // 第二步和第三步：循环打开帖子，发现用户并立即关注
                    showToast(`正在查找并关注用户...`, 'info');
                        
                        const processedUsers = new Set(); // 已处理的用户ID集合，用于去重
                        let followedCount = 0; // 成功关注的数量
                        let errorCount = 0; // 失败数量
                        let alreadyFollowedCount = 0; // 已关注的数量
                        const maxPosts = 10; // 最多打开10个帖子
                        
                        // 生成随机的帖子访问顺序（避免每次都从第一个开始）
                        const postIndices = Array.from({ length: maxPosts }, (_, i) => i);
                        // Fisher-Yates 洗牌算法，打乱顺序
                        for (let i = postIndices.length - 1; i > 0; i--) {
                            const j = Math.floor(Math.random() * (i + 1));
                            [postIndices[i], postIndices[j]] = [postIndices[j], postIndices[i]];
                        }
                        console.log('[QuickFollow] 📋 随机帖子访问顺序:', postIndices);
                        
                        let currentPostIdx = 0; // 当前处理的帖子在随机序列中的索引
                        
                        // 获取已关注用户昵称列表，用于过滤（按窗口ID隔离）
                        // 优先从本地缓存读取，如果缓存为空则从服务器获取
                        console.log('[QuickFollow] 📋 开始加载已关注用户列表...');
                        const followedUserNames = await getFollowedUserNames(currentWindowId, ownerRedid);
                        console.log(`[QuickFollow] ✅ 已加载 ${followedUserNames.length} 个已关注用户（窗口${currentWindowId}）`);
                        
                        if (followedUserNames.length > 0) {
                            console.log(`[QuickFollow] 已关注用户昵称列表（前10个）:`, followedUserNames.slice(0, 10));
                            showToast(`已加载 ${followedUserNames.length} 个已关注用户`, 'info');
                        } else {
                            console.log('[QuickFollow] ⚠️ 关注列表为空，将不进行过滤');
                            showToast('关注列表为空', 'info');
                        }
                        
                        // 循环打开帖子，发现用户并立即关注（按随机顺序）
                        while (followedCount < followCount && currentPostIdx < maxPosts && !shouldStop) {
                            const postIndex = postIndices[currentPostIdx]; // 获取随机顺序中的帖子索引
                            console.log(`[QuickFollow] 📝 打开第 ${currentPostIdx + 1} 个帖子（实际索引: ${postIndex}）`);
                            showToast(`打开第 ${currentPostIdx + 1} 个帖子...`, 'info');
                            
                            // 检查是否需要停止
                            if (shouldStop) {
                                console.log('[QuickFollow] ⏹️ 用户停止执行');
                                showToast('已停止执行', 'warning');
                                break;
                            }
                            
                            // 打开帖子
                            const openPostResponse = await chrome.tabs.sendMessage(tab.id, {
                                action: MESSAGE_TYPES.OPEN_POST_BY_INDEX,
                                index: postIndex
                            });
                            
                            if (!openPostResponse || !openPostResponse.success) {
                                console.error('[QuickFollow] ❌ 打开帖子失败');
                                break;
                            }
                            
                            // 等待帖子页面加载
                            await new Promise(resolve => setTimeout(resolve, 3000));
                            
                            // 在当前帖子中查找用户并立即关注
                            let scrollAttempts = 0;
                            let noNewUsersCount = 0; // 连续没有新用户的次数
                            let isEndOfComments = false; // 是否到达评论底部
                            
                            console.log(`[QuickFollow] 🔍 在第 ${postIndex + 1} 个帖子中查找用户并关注`);
                            
                            while (followedCount < followCount && !shouldStop && !isEndOfComments) {
                                // 检查是否需要停止
                                if (shouldStop) {
                                    console.log('[QuickFollow] ⏹️ 用户停止执行');
                                    break;
                                }
                                
                                console.log(`[QuickFollow] 📊 第 ${scrollAttempts + 1} 轮查找，当前已关注 ${followedCount}/${followCount} 个用户`);
                                
                                // 获取当前页面所有符合条件的评论者（传入已处理的用户ID和已关注用户昵称）
                                // 注意：如果启用了二级评论，后端会自动展开符合条件的一级评论的回复
                                const allCommentersResponse = await chrome.tabs.sendMessage(tab.id, {
                                    action: MESSAGE_TYPES.GET_ALL_RECENT_COMMENTERS,
                                    collectedUrls: Array.from(processedUsers), // 传入已处理的用户ID数组
                                    followedUserNames: followedUserNames, // 传入已关注用户昵称数组，用于过滤
                                    maxMinutes: timeRange, // 传入时间范围（分钟数）
                                    includeSubComments: includeSubComments // 传入是否查询二级评论
                                });
                                
                                if (allCommentersResponse && allCommentersResponse.success) {
                                    const { users, totalChecked } = allCommentersResponse.data;
                                    console.log(`[QuickFollow] 📝 本轮检查了 ${totalChecked} 条评论，找到 ${users.length} 个新用户`);
                                    
                                    // 立即关注每个新发现的用户
                                    for (const user of users) {
                                        // 检查是否请求停止
                                        if (shouldStop) {
                                            console.log(`[QuickFollow] ⏹️ 检测到停止请求，终止关注流程`);
                                            break;
                                        }
                                        
                                        if (followedCount >= followCount) {
                                            console.log(`[QuickFollow] 🎉 已关注够 ${followCount} 个用户`);
                                            break;
                                        }
                                        
                                        // 检查是否已处理过（去重）
                                        if (processedUsers.has(user.userId)) {
                                            console.log(`[QuickFollow] ⏭️ 用户 ${user.userName} 已处理过，跳过`);
                                            continue;
                                        }
                                        
                                        // 标记为已处理
                                        processedUsers.add(user.userId);
                                        
                                        console.log(`[QuickFollow] 🎯 发现新用户: ${user.userName} (${user.timeText}) [ID: ${user.userId}]`);
                                        console.log(`[QuickFollow] 🚀 立即开始关注该用户...`);
                                        
                                        // 立即关注该用户（传入帖子TabID和评论内容）
                                        const followResult = await followSingleUser(
                                            user.userUrl, 
                                            user.userId, 
                                            followedCount + alreadyFollowedCount + errorCount + 1, 
                                            followCount,
                                            tab.id,  // 帖子页面的TabID，用于回复评论
                                            commentContent  // 评论内容
                                        );
                                        
                                        if (followResult.success) {
                                            if (followResult.alreadyFollowed) {
                                                alreadyFollowedCount++;
                                                console.log(`[QuickFollow] ✅ 用户 ${followResult.userName} 已关注过 (总进度: ${followedCount}/${followCount})`);
                                            } else {
                                                followedCount++;
                                                console.log(`[QuickFollow] ✅ 成功关注 ${followResult.userName} (${followedCount}/${followCount})`);
                                                
                                                // 关注成功（不是已关注），添加到上传列表
                                                if (followResult.userInfo && followResult.userInfo.targetRedid) {
                                                    followListForUpload.push(followResult.userInfo);
                                                    console.log(`[QuickFollow] 📝 已添加到上传列表: ${followResult.userName}`);
                                                }
                                            }
                                            showToast(`已关注 ${followedCount}/${followCount} 个用户`, 'success');
                                        } else {
                                            errorCount++;
                                            console.log(`[QuickFollow] ❌ 关注 ${followResult.userName} 失败`);
                                        }
                                        
                                        // 检查是否已完成目标
                                        if (followedCount >= followCount) {
                                            console.log(`[QuickFollow] 🎉 已完成目标，成功关注 ${followCount} 个用户！`);
                                            break;
                                        }
                                    }
                                    
                                    // 检查是否请求停止
                                    if (shouldStop) {
                                        console.log(`[QuickFollow] ⏹️ 检测到停止请求，退出当前帖子`);
                                        break;
                                    }
                                    
                                    // 如果已经关注够了，退出循环
                                    if (followedCount >= followCount) {
                                        console.log(`[QuickFollow] 🎉 已关注够 ${followCount} 个用户`);
                                        break;
                                    }
                                    
                                    // 如果没有找到新用户
                                    if (users.length === 0) {
                                        noNewUsersCount++;
                                        console.log(`[QuickFollow] ⚠️ 本轮未找到新用户（连续 ${noNewUsersCount} 次）`);
                                        
                                        if (noNewUsersCount >= 5) {
                                            console.log(`[QuickFollow] ⚠️ 连续5次未找到新用户，停止查找`);
                                            break;
                                        }
                                    } else {
                                        noNewUsersCount = 0;
                                    }
                                }
                                
                                // 检查是否请求停止
                                if (shouldStop) {
                                    console.log(`[QuickFollow] ⏹️ 检测到停止请求，不再滚动加载`);
                                    break;
                                }
                                
                                // 如果还没关注够且还没到底部，则滚动加载更多评论
                                if (followedCount < followCount && !isEndOfComments) {
                                    scrollAttempts++;
                                    console.log(`[QuickFollow] 📜 第 ${scrollAttempts} 次滚动评论区，等待加载更多评论...`);
                                    
                                    const scrollResponse = await chrome.tabs.sendMessage(tab.id, {
                                        action: MESSAGE_TYPES.SCROLL_COMMENTS
                                    });
                                    
                                    if (scrollResponse && scrollResponse.success) {
                                        // 等待新评论加载
                                        console.log('[QuickFollow] ⏳ 等待3秒让新评论加载...');
                                        await new Promise(resolve => setTimeout(resolve, 3000));
                                        
                                        // 检测是否到达评论底部
                                        const checkEndResponse = await chrome.tabs.sendMessage(tab.id, {
                                            action: MESSAGE_TYPES.CHECK_END_OF_COMMENTS
                                        });
                                        
                                        if (checkEndResponse && checkEndResponse.success && checkEndResponse.data && checkEndResponse.data.isEnd) {
                                            console.log('[QuickFollow] ✅ 检测到评论已到达底部 "- THE END -"，停止查找');
                                            isEndOfComments = true;
                                            break;
                                        }
                                    } else {
                                        console.error('[QuickFollow] ❌ 滚动评论区失败');
                                        break;
                                    }
                                }
                            }
                            
                            // 关闭当前帖子详情（点击空白处）
                            console.log(`[QuickFollow] 关闭第 ${currentPostIdx + 1} 个帖子详情`);
                            const closeResponse = await chrome.tabs.sendMessage(tab.id, {
                                action: MESSAGE_TYPES.CLOSE_POST_DETAIL
                            });
                            
                            if (closeResponse && closeResponse.success) {
                                console.log('[QuickFollow] ✅ 帖子详情已关闭');
                            }
                            
                            // 等待关闭动画完成
                            await new Promise(resolve => setTimeout(resolve, 1000));
                            
                            // 移动到下一个帖子
                            currentPostIdx++;
                            
                            // 如果还没关注够，继续下一个帖子
                            if (followedCount < followCount && currentPostIdx < maxPosts) {
                                console.log(`[QuickFollow] 当前已关注 ${followedCount}/${followCount} 个用户，继续下一个帖子`);
                            }
                        }
                        
                        // 检查是否已停止或完成
                        if (shouldStop) {
                            console.log('[QuickFollow] ⏹️ 执行已停止');
                            console.log(`[QuickFollow] 📊 停止前统计: 成功关注: ${followedCount}, 失败: ${errorCount}, 已关注: ${alreadyFollowedCount}`);
                            showToast(`已停止执行。成功: ${followedCount}${alreadyFollowedCount > 0 ? `, 已关注: ${alreadyFollowedCount}` : ''}, 失败: ${errorCount}`, 'warning');
                        } else {
                            // 显示最终结果
                            console.log(`[QuickFollow] 🎉 完成！成功关注: ${followedCount}, 失败: ${errorCount}, 已关注: ${alreadyFollowedCount}`);
                            
                            if (followedCount === 0 && alreadyFollowedCount === 0 && errorCount === 0) {
                                showToast('未找到符合条件的用户', 'warning');
                            } else {
                                showToast(`关注完成！成功: ${followedCount}${alreadyFollowedCount > 0 ? `, 已关注: ${alreadyFollowedCount}` : ''}, 失败: ${errorCount}`, 'success');
                            }
                        }
                        
                        // 无论是停止还是完成，都上传关注列表到服务器
                        if (followListForUpload.length > 0 && ownerRedid) {
                            console.log(`[QuickFollow] 📤 准备上传 ${followListForUpload.length} 个关注记录到服务器...`);
                            showToast(`正在上传 ${followListForUpload.length} 条关注记录...`, 'info');
                            
                            const uploadResult = await uploadFollowList(ownerRedid, followListForUpload);
                            
                            if (uploadResult.success) {
                                const data = uploadResult.data;
                                console.log(`[QuickFollow] ✅ 上传成功！成功: ${data.successCount}, 跳过: ${data.skippedCount}, 失败: ${data.failedCount}`);
                                showToast(`上传成功！成功: ${data.successCount}, 跳过: ${data.skippedCount}`, 'success');
                            } else {
                                console.error(`[QuickFollow] ❌ 上传失败:`, uploadResult.error);
                                showToast(`上传失败: ${uploadResult.error}`, 'error');
                            }
                        } else if (followListForUpload.length > 0 && !ownerRedid) {
                            console.warn('[QuickFollow] ⚠️ 未获取到当前用户小红书号，跳过上传');
                        } else {
                            console.log('[QuickFollow] ℹ️ 没有新的关注记录需要上传');
                        }
                } else {
                    throw new Error(searchResponse?.error || '搜索失败');
                }
                
            } catch (error) {
                console.error('[QuickFollow] ❌ 执行失败:', error);
                showToast('执行失败: ' + error.message, 'error');
            } finally {
                // 恢复按钮状态
                isExecuting = false;
                shouldStop = false;
                updateExecuteButton(executeBtn, false);
            }
        });
    }
});

/**
 * 关注单个用户
 * @param {string} userUrl - 用户主页URL
 * @param {string} userId - 用户ID
 * @param {number} index - 当前序号
 * @param {number} total - 总数
 * @param {number} postTabId - 帖子页面的TabID（用于回复评论）
 * @param {string} commentContent - 评论内容（可选）
 * @returns {Promise<{success: boolean, userName: string, alreadyFollowed: boolean, userInfo: Object}>}
 */
async function followSingleUser(userUrl, userId, index, total, postTabId = null, commentContent = null) {
    let userTab = null;
    try {
        console.log(`[QuickFollow] 正在关注第 ${index}/${total} 个用户`);
        showToast(`正在关注第 ${index}/${total} 个用户...`, 'info');
        
        // 打开用户主页
        userTab = await chrome.tabs.create({
            url: userUrl,
            active: false
        });
        
        // 等待页面加载
        console.log(`[QuickFollow] ⏳ 等待页面加载...`);
        await new Promise(resolve => setTimeout(resolve, 5000));
        
        // 获取用户信息（用于保存到已关注列表和上传到服务器）
        const userInfoResponse = await sendMessageWithRetry(userTab.id, {
            action: MESSAGE_TYPES.GET_USER_INFO
        }, 3);
        
        let userName = '未知用户';
        let avatarUrl = '';
        let targetRedid = '';
        let profileUrl = userUrl;
        
        if (userInfoResponse && userInfoResponse.success) {
            const data = userInfoResponse.data;
            userName = data.username || '未知用户';
            avatarUrl = data.avatar || '';
            targetRedid = data.redId || data.userId || userId;
            profileUrl = userUrl;
        }
        
        // 检查关注状态并执行关注（使用重试机制）
        const followResponse = await sendMessageWithRetry(userTab.id, {
            action: MESSAGE_TYPES.CHECK_USER_FOLLOWED
        }, 3);
        
        if (followResponse && followResponse.success) {
            const { followed, buttonFound } = followResponse.data;
            
            if (!buttonFound) {
                console.warn(`[QuickFollow] ⚠️ 用户 ${index} 未找到关注按钮`);
                return { 
                    success: false, 
                    userName, 
                    alreadyFollowed: false,
                    userInfo: { targetRedid, nickname: userName, avatarUrl, profileUrl }
                };
            } else if (followed) {
                console.log(`[QuickFollow] ℹ️ 用户 ${index} ${userName} 已关注过，记录到关注列表`);
                
                // 保存到已关注列表（按窗口ID隔离）
                try {
                    await addFollowedUser({
                        userId: userId,
                        userName: userName,
                        userUrl: userUrl
                    }, currentWindowId);
                    console.log(`[QuickFollow] ✅ 已将 ${userName} 添加到关注列表（窗口${currentWindowId}）`);
                } catch (error) {
                    console.error(`[QuickFollow] ❌ 保存到关注列表失败:`, error);
                }
                
                return { 
                    success: true, 
                    userName, 
                    alreadyFollowed: true,
                    userInfo: { targetRedid, nickname: userName, avatarUrl, profileUrl }
                };
            } else {
                // 执行关注操作（使用重试机制）
                const clickResponse = await sendMessageWithRetry(userTab.id, {
                    action: MESSAGE_TYPES.FOLLOW_USER,
                    delay: 0
                }, 3);
                
                if (clickResponse && clickResponse.success) {
                    console.log(`[QuickFollow] ✅ 用户 ${index} ${userName} 关注成功`);
                    
                    // 关注成功后也保存到已关注列表（按窗口ID隔离）
                    try {
                        await addFollowedUser({
                            userId: userId,
                            userName: userName,
                            userUrl: userUrl
                        }, currentWindowId);
                        console.log(`[QuickFollow] ✅ 已将 ${userName} 添加到关注列表（窗口${currentWindowId}）`);
                    } catch (error) {
                        console.error(`[QuickFollow] ❌ 保存到关注列表失败:`, error);
                    }
                    
                    // 如果有评论内容且有帖子TabID，则回复评论
                    if (commentContent && commentContent.trim() && postTabId) {
                        console.log(`[QuickFollow] 💬 准备回复评论给用户 ${userName}...`);
                        try {
                            const replyResponse = await chrome.tabs.sendMessage(postTabId, {
                                action: MESSAGE_TYPES.REPLY_TO_COMMENT,
                                userId: userId,
                                commentContent: commentContent
                            });
                            
                            if (replyResponse && replyResponse.success && replyResponse.data && replyResponse.data.replied) {
                                console.log(`[QuickFollow] ✅ 成功回复评论给用户 ${userName}`);
                            } else {
                                console.log(`[QuickFollow] ⚠️ 回复评论跳过或失败: ${replyResponse?.data?.reason || '未知原因'}`);
                            }
                        } catch (error) {
                            console.error(`[QuickFollow] ❌ 回复评论失败:`, error);
                        }
                    }
                    
                    return { 
                        success: true, 
                        userName, 
                        alreadyFollowed: false,
                        userInfo: { targetRedid, nickname: userName, avatarUrl, profileUrl }
                    };
                } else {
                    console.error(`[QuickFollow] ❌ 用户 ${index} ${userName} 关注失败`);
                    return { 
                        success: false, 
                        userName, 
                        alreadyFollowed: false,
                        userInfo: { targetRedid, nickname: userName, avatarUrl, profileUrl }
                    };
                }
            }
        } else {
            console.error(`[QuickFollow] ❌ 用户 ${index} 未收到响应`);
            return { 
                success: false, 
                userName, 
                alreadyFollowed: false,
                userInfo: { targetRedid, nickname: userName, avatarUrl, profileUrl }
            };
        }
        
    } catch (error) {
        console.error(`[QuickFollow] ❌ 处理用户 ${index} 时出错:`, error);
        return { 
            success: false, 
            userName: '未知用户', 
            alreadyFollowed: false,
            userInfo: { targetRedid: '', nickname: '未知用户', avatarUrl: '', profileUrl: '' }
        };
    } finally {
        // 确保关闭用户主页标签
        if (userTab && userTab.id) {
            try {
                await chrome.tabs.remove(userTab.id);
            } catch (e) {
                console.warn(`[QuickFollow] ⚠️ 关闭标签页失败:`, e);
            }
        }
        
        // 等待一下，避免操作过快
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
}

/**
 * 更新执行按钮的状态
 * @param {HTMLElement} button - 按钮元素
 * @param {boolean} executing - 是否正在执行
 */
function updateExecuteButton(button, executing) {
    if (!button) return;
    
    if (executing) {
        // 正在执行：显示"停止执行"
        button.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="6" y="6" width="12" height="12"></rect>
            </svg>
            停止执行
        `;
        button.style.background = 'linear-gradient(135deg, #FF6B6B 0%, #FF2D55 100%)';
        button.disabled = false;
    } else {
        // 未执行：显示"开始执行"
        button.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polygon points="5 3 19 12 5 21 5 3"></polygon>
            </svg>
            开始执行
        `;
        button.style.background = 'linear-gradient(135deg, #FF6B6B 0%, #FF2D55 100%)';
        button.disabled = false;
    }
}
