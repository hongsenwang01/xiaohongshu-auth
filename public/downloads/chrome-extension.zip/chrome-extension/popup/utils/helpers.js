// 辅助工具函数
import { sleep } from '../../shared/utils.js';

/**
 * 启动小红书页面
 * @returns {Promise<void>}
 */
export async function launchXiaohongshu() {
    try {
        console.log('启动小红书...');
        
        // 打开小红书页面
        await chrome.tabs.create({
            url: 'https://www.xiaohongshu.com/explore',
            active: true
        });
        
        // 关闭当前popup
        setTimeout(() => {
            window.close();
        }, 500);
        
    } catch (error) {
        console.error('启动小红书失败:', error);
        throw error;
    }
}

export { sleep };

