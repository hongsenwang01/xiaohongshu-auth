import { MESSAGE_TYPES, BROWSE_EVENT_TYPES } from '../shared/constants.js';
import { getDurationConfig, getBrowseCountConfig, getToggleStates } from './services/config.js';
import { getCachedCommentContents } from './services/cache.js';
import { getUsernamesFromStorage } from '../shared/excel-templates.js';
import { stopBrowseTask, getBrowseState, restoreTaskId } from './services/state.js';

function $(id) { return document.getElementById(id); }

let isStopped = false;

async function getWindowId() {
  try {
    const w = await chrome.windows.getCurrent();
    return w.id;
  } catch {
    return null;
  }
}

function setKV(id, value) {
  const el = $(id);
  if (el) el.textContent = value;
}

function boolText(v) { return v ? '开启' : '关闭'; }

function appendLog(text) {
  const list = $('progressList');
  if (!list) return;
  const item = document.createElement('div');
  item.className = 'progress-item';
  const ts = new Date();
  const hh = ts.getHours().toString().padStart(2, '0');
  const mm = ts.getMinutes().toString().padStart(2, '0');
  const ss = ts.getSeconds().toString().padStart(2, '0');
  item.textContent = `[${hh}:${mm}:${ss}] ${text}`;
  list.appendChild(item);
  list.scrollTop = list.scrollHeight;
}

function setCurrentAction(text) {
  const el = $('currentAction');
  if (el) el.textContent = text;
}

function disableStopButton() {
  const stopBtn = $('stopBtn');
  if (stopBtn) {
    stopBtn.disabled = true;
    isStopped = true;
  }
}

/**
 * 检查事件类型是否应该显示在日志中
 * 某些内部事件（如 tabClosed）不需要显示给用户
 */
function shouldShowEvent(type) {
  // 这些事件类型不显示在日志中
  const hiddenEvents = [
    'tabClosed', // 标签页关闭事件
    'tabCreated', // 标签页创建事件
  ];
  return !hiddenEvents.includes(type);
}

/**
 * 将事件类型转换为人类可读的文本
 * 如果返回 null，表示该事件不应显示
 */
function humanizeEvent(type, data = {}) {
  switch (type) {
    case BROWSE_EVENT_TYPES.STARTED:
      return `开始执行，共 ${data.totalPosts ?? '-'} 个帖子`;
    case BROWSE_EVENT_TYPES.PROGRESS:
      return `进度 ${data.currentIndex}/${data.totalPosts}：${data.currentPost?.title ?? ''}`;
    case BROWSE_EVENT_TYPES.TAB_OPENED:
      return `已打开帖子标签页`;
    case BROWSE_EVENT_TYPES.LIKING:
      return `准备点赞，约 ${data.delay}s 后执行`;
    case BROWSE_EVENT_TYPES.LIKE_SUCCESS:
      return data.alreadyLiked ? '已点赞过，跳过' : '点赞成功';
    case BROWSE_EVENT_TYPES.LIKE_ERROR:
      return `点赞失败：${data.error || ''}`;
    case BROWSE_EVENT_TYPES.COLLECTING:
      return `准备收藏，约 ${data.delay}s 后执行`;
    case BROWSE_EVENT_TYPES.COLLECT_SUCCESS:
      return data.alreadyCollected ? '已收藏过，跳过' : '收藏成功';
    case BROWSE_EVENT_TYPES.COLLECT_ERROR:
      return `收藏失败：${data.error || ''}`;
    case BROWSE_EVENT_TYPES.FOLLOWING:
      return `准备关注，约 ${data.delay}s 后执行`;
    case BROWSE_EVENT_TYPES.FOLLOW_SUCCESS:
      return data.alreadyFollowed ? '已关注过，跳过' : '关注成功';
    case BROWSE_EVENT_TYPES.FOLLOW_ERROR:
      return `关注失败：${data.error || ''}`;
    case BROWSE_EVENT_TYPES.COMMENTING:
      return `准备评论，约 ${data.delay}s 后执行：${data.content ?? ''}`;
    case BROWSE_EVENT_TYPES.COMMENT_SUCCESS:
      return '评论成功';
    case BROWSE_EVENT_TYPES.COMMENT_ERROR:
      return `评论失败：${data.error || ''}`;
    case BROWSE_EVENT_TYPES.ERROR:
      return `错误：${data.error || ''}`;
    case BROWSE_EVENT_TYPES.STOPPED:
      return '已停止执行';
    case BROWSE_EVENT_TYPES.COMPLETED:
      return '执行完成';
    default:
      // 对于未知的内部事件，返回 null 表示不显示
      return shouldShowEvent(type) ? `事件：${type}` : null;
  }
}

function handleBrowseUpdate(message) {
  // 如果已停止，不再处理新的消息
  if (isStopped) {
    return;
  }

  const { type, data } = message;
  const text = humanizeEvent(type, data);
  
  // 只有当返回值不为 null 时才显示
  if (text) {
    setCurrentAction(text);
    appendLog(text);
  }

  // 当执行停止或完成时，禁用停止按钮
  if (type === BROWSE_EVENT_TYPES.STOPPED || type === BROWSE_EVENT_TYPES.COMPLETED) {
    disableStopButton();
  }
}

async function loadConfigAndFilters() {
  const windowId = await getWindowId();

  // Config
  const duration = await getDurationConfig(windowId);
  const count = await getBrowseCountConfig(windowId);
  const toggles = await getToggleStates(windowId);
  const comments = await getCachedCommentContents(windowId);

  setKV('cfgBrowseCount', count ?? '-');
  setKV('cfgDuration', duration ? `${duration.min}-${duration.max} 秒` : '-');
  setKV('cfgLike', boolText(!!toggles?.autoLike));
  setKV('cfgCollect', boolText(!!toggles?.autoCollect));
  setKV('cfgFollow', boolText(!!toggles?.autoFollow));
  setKV('cfgComment', boolText(!!toggles?.autoComment));
  setKV('cfgComments', (comments && comments.length > 0) ? comments.join('、') : '无');

  // Filters (read from storage keys used by filter.js)
  const onlyKey = `filter_following_toggle_window_${windowId}`;
  const excludeToggleKey = `filter_exclude_toggle_window_${windowId}`;
  const focusToggleKey = `filter_focus_toggle_window_${windowId}`;

  const excludeDataKey = `filter_exclude_list_window_${windowId}`;
  const focusDataKey = `filter_focus_list_window_${windowId}`;

  const togglesRaw = await chrome.storage.local.get([onlyKey, excludeToggleKey, focusToggleKey]);
  const onlyFollowing = !!togglesRaw[onlyKey];
  const excludeEnabled = !!togglesRaw[excludeToggleKey];
  const focusEnabled = !!togglesRaw[focusToggleKey];

  setKV('fltOnlyFollowing', boolText(onlyFollowing));
  setKV('fltExcludeEnabled', boolText(excludeEnabled));
  setKV('fltFocusEnabled', boolText(focusEnabled));

  let excludeCount = 0, focusCount = 0;
  if (excludeEnabled) {
    const ex = await getUsernamesFromStorage(excludeDataKey);
    excludeCount = ex?.count || ex?.usernames?.length || 0;
  }
  if (focusEnabled) {
    const fo = await getUsernamesFromStorage(focusDataKey);
    focusCount = fo?.count || fo?.usernames?.length || 0;
  }
  setKV('fltExcludeCount', excludeCount);
  setKV('fltFocusCount', focusCount);
}

async function init() {
  // Buttons
  $('backBtn')?.addEventListener('click', () => {
    // 返回到主面板
    window.location.href = chrome.runtime.getURL('side-panel.html');
  });

  $('stopBtn')?.addEventListener('click', async () => {
    if (isStopped) {
      // 如果已停止，点击返回按钮返回
      $('backBtn')?.click();
      return;
    }

    try {
      const stopped = await stopBrowseTask();
      if (stopped) {
        setCurrentAction('已停止执行');
        appendLog('手动停止');
        disableStopButton();
      }
    } catch {}
  });

  await loadConfigAndFilters();

  // Restore state summary
  try {
    const taskId = restoreTaskId();
    if (taskId) {
      const state = await getBrowseState(taskId);
      if (state?.isRunning) {
        setCurrentAction(`恢复任务：${state.currentIndex}/${state.totalPosts}`);
      } else {
        disableStopButton();
      }
    }
  } catch {}

  // Listen to live updates
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === MESSAGE_TYPES.BROWSE_UPDATE) {
      handleBrowseUpdate(message);
    }
  });
}

document.addEventListener('DOMContentLoaded', init);

