// side-panel.js - 成品号维护阶段页面入口
import XiaohongshuAssistant from './assistant.js';

// 实例化助手
document.addEventListener('DOMContentLoaded', () => {
    console.log('[SidePanel] 成品号维护页面初始化...');
    new XiaohongshuAssistant();
});

