// 缓存管理服务

/**
 * 缓存配置
 */
const CACHE_CONFIG = {
    USER_INFO_TTL: 24 * 60 * 60 * 1000,  // 用户信息缓存24小时
    POSTS_TTL: 5 * 60 * 1000,             // 帖子信息缓存5分钟
};

/**
 * 缓存键名
 */
const CACHE_KEYS = {
    USER_INFO: 'cached_user_info',
    USER_INFO_TIMESTAMP: 'cached_user_info_timestamp',
    POSTS: 'cached_posts',
    POSTS_TIMESTAMP: 'cached_posts_timestamp',
    COMMENT_CONTENTS: 'cached_comment_contents',
};

/**
 * 生成窗口特定的缓存键
 * @param {string} baseKey - 基础键名
 * @param {number|null} windowId - 窗口ID
 * @returns {string}
 */
function getWindowCacheKey(baseKey, windowId) {
    if (windowId) {
        return `${baseKey}_window_${windowId}`;
    }
    return baseKey; // 兼容旧版本
}

/**
 * 保存用户信息到缓存（按窗口ID隔离）
 * @param {Object} userInfo - 用户信息对象（包含授权信息：licenseCode, licenseValid, licenseDaysRemaining）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<void>}
 */
export async function cacheUserInfo(userInfo, windowId = null) {
    try {
        const timestamp = Date.now();
        const userInfoKey = getWindowCacheKey(CACHE_KEYS.USER_INFO, windowId);
        const timestampKey = getWindowCacheKey(CACHE_KEYS.USER_INFO_TIMESTAMP, windowId);
        
        await chrome.storage.local.set({
            [userInfoKey]: userInfo,
            [timestampKey]: timestamp
        });
        
        const licenseStatus = userInfo.licenseValid ? '已授权' : '未授权';
        console.log('[Cache] ✅ 用户信息已缓存', { 
            windowId, 
            timestamp, 
            userId: userInfo.userId,
            license: licenseStatus,
            daysRemaining: userInfo.licenseDaysRemaining || 'N/A'
        });
    } catch (error) {
        console.error('[Cache] ❌ 缓存用户信息失败:', error);
    }
}

/**
 * 获取缓存的用户信息（按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<Object|null>} 返回缓存的用户信息，如果过期或不存在则返回null
 */
export async function getCachedUserInfo(windowId = null) {
    try {
        const userInfoKey = getWindowCacheKey(CACHE_KEYS.USER_INFO, windowId);
        const timestampKey = getWindowCacheKey(CACHE_KEYS.USER_INFO_TIMESTAMP, windowId);
        
        const result = await chrome.storage.local.get([userInfoKey, timestampKey]);
        
        const userInfo = result[userInfoKey];
        const timestamp = result[timestampKey];
        
        // 检查缓存是否存在
        if (!userInfo || !timestamp) {
            console.log('[Cache] ⚠️ 用户信息缓存不存在', { windowId });
            return null;
        }
        
        // 检查缓存是否过期
        const age = Date.now() - timestamp;
        if (age > CACHE_CONFIG.USER_INFO_TTL) {
            console.log('[Cache] ⏰ 用户信息缓存已过期', {
                windowId,
                age: Math.round(age / 1000 / 60),
                ttl: Math.round(CACHE_CONFIG.USER_INFO_TTL / 1000 / 60)
            });
            // 清除过期缓存
            await clearUserInfoCache(windowId);
            return null;
        }
        
        console.log('[Cache] ✅ 使用缓存的用户信息', {
            windowId,
            age: Math.round(age / 1000 / 60) + '分钟前',
            userId: userInfo.userId
        });
        
        return userInfo;
    } catch (error) {
        console.error('[Cache] ❌ 获取缓存用户信息失败:', error);
        return null;
    }
}

/**
 * 清除用户信息缓存
 * @param {number|null} windowId - 窗口ID，如果为null则清除所有窗口的缓存
 * @returns {Promise<void>}
 */
export async function clearUserInfoCache(windowId = null) {
    try {
        if (windowId) {
            // 清除指定窗口的缓存
            const userInfoKey = getWindowCacheKey(CACHE_KEYS.USER_INFO, windowId);
            const timestampKey = getWindowCacheKey(CACHE_KEYS.USER_INFO_TIMESTAMP, windowId);
            
            await chrome.storage.local.remove([userInfoKey, timestampKey]);
            console.log('[Cache] 🗑️ 用户信息缓存已清除', { windowId });
        } else {
            // 清除所有窗口的缓存（获取所有相关键）
            const allData = await chrome.storage.local.get(null);
            const keysToRemove = Object.keys(allData).filter(key => 
                key.startsWith(CACHE_KEYS.USER_INFO) || 
                key.startsWith(CACHE_KEYS.USER_INFO_TIMESTAMP)
            );
            
            if (keysToRemove.length > 0) {
                await chrome.storage.local.remove(keysToRemove);
                console.log('[Cache] 🗑️ 所有窗口的用户信息缓存已清除', { count: keysToRemove.length });
            }
        }
    } catch (error) {
        console.error('[Cache] ❌ 清除用户信息缓存失败:', error);
    }
}

/**
 * 保存帖子列表到缓存
 * @param {Array} posts - 帖子数组
 * @param {string} pageUrl - 页面URL（用于区分不同页面的帖子）
 * @returns {Promise<void>}
 */
export async function cachePosts(posts, pageUrl) {
    try {
        const timestamp = Date.now();
        await chrome.storage.local.set({
            [CACHE_KEYS.POSTS]: {
                url: pageUrl,
                data: posts
            },
            [CACHE_KEYS.POSTS_TIMESTAMP]: timestamp
        });
        console.log('[Cache] ✅ 帖子列表已缓存', { count: posts.length, url: pageUrl });
    } catch (error) {
        console.error('[Cache] ❌ 缓存帖子列表失败:', error);
    }
}

/**
 * 获取缓存的帖子列表
 * @param {string} pageUrl - 页面URL
 * @returns {Promise<Array|null>} 返回缓存的帖子列表，如果过期或不存在则返回null
 */
export async function getCachedPosts(pageUrl) {
    try {
        const result = await chrome.storage.local.get([
            CACHE_KEYS.POSTS,
            CACHE_KEYS.POSTS_TIMESTAMP
        ]);
        
        const postsCache = result[CACHE_KEYS.POSTS];
        const timestamp = result[CACHE_KEYS.POSTS_TIMESTAMP];
        
        // 检查缓存是否存在
        if (!postsCache || !timestamp) {
            console.log('[Cache] ⚠️ 帖子列表缓存不存在');
            return null;
        }
        
        // 检查URL是否匹配
        if (postsCache.url !== pageUrl) {
            console.log('[Cache] ⚠️ 页面URL不匹配，缓存无效');
            return null;
        }
        
        // 检查缓存是否过期
        const age = Date.now() - timestamp;
        if (age > CACHE_CONFIG.POSTS_TTL) {
            console.log('[Cache] ⏰ 帖子列表缓存已过期');
            await clearPostsCache();
            return null;
        }
        
        console.log('[Cache] ✅ 使用缓存的帖子列表', {
            count: postsCache.data.length,
            age: Math.round(age / 1000) + '秒前'
        });
        
        return postsCache.data;
    } catch (error) {
        console.error('[Cache] ❌ 获取缓存帖子列表失败:', error);
        return null;
    }
}

/**
 * 清除帖子列表缓存
 * @returns {Promise<void>}
 */
export async function clearPostsCache() {
    try {
        await chrome.storage.local.remove([
            CACHE_KEYS.POSTS,
            CACHE_KEYS.POSTS_TIMESTAMP
        ]);
        console.log('[Cache] 🗑️ 帖子列表缓存已清除');
    } catch (error) {
        console.error('[Cache] ❌ 清除帖子列表缓存失败:', error);
    }
}

/**
 * 清除所有缓存
 * @returns {Promise<void>}
 */
export async function clearAllCache() {
    try {
        await clearUserInfoCache();
        await clearPostsCache();
        console.log('[Cache] 🗑️ 所有缓存已清除');
    } catch (error) {
        console.error('[Cache] ❌ 清除所有缓存失败:', error);
    }
}

/**
 * 获取缓存统计信息
 * @returns {Promise<Object>}
 */
export async function getCacheStats() {
    try {
        const result = await chrome.storage.local.get([
            CACHE_KEYS.USER_INFO,
            CACHE_KEYS.USER_INFO_TIMESTAMP,
            CACHE_KEYS.POSTS,
            CACHE_KEYS.POSTS_TIMESTAMP
        ]);
        
        const stats = {
            userInfo: {
                exists: !!result[CACHE_KEYS.USER_INFO],
                timestamp: result[CACHE_KEYS.USER_INFO_TIMESTAMP],
                age: result[CACHE_KEYS.USER_INFO_TIMESTAMP] 
                    ? Date.now() - result[CACHE_KEYS.USER_INFO_TIMESTAMP] 
                    : null
            },
            posts: {
                exists: !!result[CACHE_KEYS.POSTS],
                timestamp: result[CACHE_KEYS.POSTS_TIMESTAMP],
                count: result[CACHE_KEYS.POSTS]?.data?.length || 0,
                age: result[CACHE_KEYS.POSTS_TIMESTAMP] 
                    ? Date.now() - result[CACHE_KEYS.POSTS_TIMESTAMP] 
                    : null
            }
        };
        
        return stats;
    } catch (error) {
        console.error('[Cache] ❌ 获取缓存统计失败:', error);
        return null;
    }
}

/**
 * 保存评论内容到缓存（按窗口ID隔离）
 * @param {Array<string>} comments - 评论内容数组（最多3条）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<void>}
 */
export async function cacheCommentContents(comments, windowId = null) {
    try {
        const commentsKey = getWindowCacheKey(CACHE_KEYS.COMMENT_CONTENTS, windowId);
        
        // 过滤掉空字符串，最多保存3条
        const validComments = comments.filter(c => c && c.trim()).slice(0, 3);
        
        await chrome.storage.local.set({
            [commentsKey]: validComments
        });
        
        console.log('[Cache] ✅ 评论内容已缓存', { windowId, count: validComments.length });
    } catch (error) {
        console.error('[Cache] ❌ 缓存评论内容失败:', error);
    }
}

/**
 * 获取缓存的评论内容（按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<Array<string>>} 返回缓存的评论内容数组，如果不存在则返回空数组
 */
export async function getCachedCommentContents(windowId = null) {
    try {
        const commentsKey = getWindowCacheKey(CACHE_KEYS.COMMENT_CONTENTS, windowId);
        const result = await chrome.storage.local.get([commentsKey]);
        
        const comments = result[commentsKey];
        
        if (!comments || !Array.isArray(comments)) {
            console.log('[Cache] ⚠️ 评论内容缓存不存在', { windowId });
            return [];
        }
        
        console.log('[Cache] ✅ 使用缓存的评论内容', { windowId, count: comments.length });
        return comments;
    } catch (error) {
        console.error('[Cache] ❌ 获取缓存评论内容失败:', error);
        return [];
    }
}

/**
 * 清除评论内容缓存
 * @param {number|null} windowId - 窗口ID，如果为null则清除所有窗口的缓存
 * @returns {Promise<void>}
 */
export async function clearCommentContentsCache(windowId = null) {
    try {
        if (windowId) {
            // 清除指定窗口的缓存
            const commentsKey = getWindowCacheKey(CACHE_KEYS.COMMENT_CONTENTS, windowId);
            await chrome.storage.local.remove([commentsKey]);
            console.log('[Cache] 🗑️ 评论内容缓存已清除', { windowId });
        } else {
            // 清除所有窗口的缓存
            const allData = await chrome.storage.local.get(null);
            const keysToRemove = Object.keys(allData).filter(key => 
                key.startsWith(CACHE_KEYS.COMMENT_CONTENTS)
            );
            
            if (keysToRemove.length > 0) {
                await chrome.storage.local.remove(keysToRemove);
                console.log('[Cache] 🗑️ 所有窗口的评论内容缓存已清除', { count: keysToRemove.length });
            }
        }
    } catch (error) {
        console.error('[Cache] ❌ 清除评论内容缓存失败:', error);
    }
}

