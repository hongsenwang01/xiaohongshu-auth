// 配置管理服务（按窗口ID隔离）

/**
 * 配置键名
 */
const CONFIG_KEYS = {
    DURATION: 'duration_config',
    BROWSE_COUNT: 'browse_count_config',
    TOGGLE_STATES: 'toggle_states_config',
};

/**
 * 生成窗口特定的配置键
 * @param {string} baseKey - 基础键名
 * @param {number|null} windowId - 窗口ID
 * @returns {string}
 */
function getWindowConfigKey(baseKey, windowId) {
    if (windowId) {
        return `${baseKey}_window_${windowId}`;
    }
    return baseKey; // 兼容旧版本
}

/**
 * 获取当前窗口ID
 * @returns {Promise<number|null>}
 */
async function getCurrentWindowId() {
    try {
        const currentWindow = await chrome.windows.getCurrent();
        return currentWindow.id;
    } catch (error) {
        console.error('[Config] 获取窗口ID失败:', error);
        return null;
    }
}

/**
 * 保存浏览时长配置（按窗口ID隔离）
 * @param {number} min - 最小时长（秒）
 * @param {number} max - 最大时长（秒）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<void>}
 */
export async function saveDurationConfig(min, max, windowId = null) {
    try {
        const wid = windowId || await getCurrentWindowId();
        const configKey = getWindowConfigKey(CONFIG_KEYS.DURATION, wid);
        
        await chrome.storage.local.set({
            [configKey]: { min, max }
        });
        console.log('[Config] ✅ 已保存浏览时长配置:', { min, max, windowId: wid });
    } catch (error) {
        console.error('[Config] ❌ 保存浏览时长配置失败:', error);
    }
}

/**
 * 获取浏览时长配置（按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<{min: number, max: number}|null>}
 */
export async function getDurationConfig(windowId = null) {
    try {
        const wid = windowId || await getCurrentWindowId();
        const configKey = getWindowConfigKey(CONFIG_KEYS.DURATION, wid);
        
        const result = await chrome.storage.local.get([configKey]);
        if (result[configKey]) {
            console.log('[Config] ✅ 获取浏览时长配置:', result[configKey], { windowId: wid });
            return result[configKey];
        }
        return null;
    } catch (error) {
        console.error('[Config] ❌ 获取浏览时长配置失败:', error);
        return null;
    }
}

/**
 * 保存浏览数量配置（按窗口ID隔离）
 * @param {number} count - 浏览数量
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<void>}
 */
export async function saveBrowseCountConfig(count, windowId = null) {
    try {
        const wid = windowId || await getCurrentWindowId();
        const configKey = getWindowConfigKey(CONFIG_KEYS.BROWSE_COUNT, wid);
        
        await chrome.storage.local.set({
            [configKey]: count
        });
        console.log('[Config] ✅ 已保存浏览数量配置:', count, { windowId: wid });
    } catch (error) {
        console.error('[Config] ❌ 保存浏览数量配置失败:', error);
    }
}

/**
 * 获取浏览数量配置（按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<number|null>}
 */
export async function getBrowseCountConfig(windowId = null) {
    try {
        const wid = windowId || await getCurrentWindowId();
        const configKey = getWindowConfigKey(CONFIG_KEYS.BROWSE_COUNT, wid);
        
        const result = await chrome.storage.local.get([configKey]);
        if (result[configKey]) {
            console.log('[Config] ✅ 获取浏览数量配置:', result[configKey], { windowId: wid });
            return result[configKey];
        }
        return null;
    } catch (error) {
        console.error('[Config] ❌ 获取浏览数量配置失败:', error);
        return null;
    }
}

/**
 * 保存开关状态配置（按窗口ID隔离）
 * @param {Object} toggleStates - 开关状态对象
 * @param {boolean} toggleStates.autoLike - 自动点赞
 * @param {boolean} toggleStates.autoCollect - 自动收藏
 * @param {boolean} toggleStates.autoComment - 自动评论
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<void>}
 */
export async function saveToggleStates(toggleStates, windowId = null) {
    try {
        const wid = windowId || await getCurrentWindowId();
        const configKey = getWindowConfigKey(CONFIG_KEYS.TOGGLE_STATES, wid);
        
        await chrome.storage.local.set({
            [configKey]: toggleStates
        });
        console.log('[Config] ✅ 已保存开关状态配置:', toggleStates, { windowId: wid });
    } catch (error) {
        console.error('[Config] ❌ 保存开关状态配置失败:', error);
    }
}

/**
 * 获取开关状态配置（按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<Object|null>}
 */
export async function getToggleStates(windowId = null) {
    try {
        const wid = windowId || await getCurrentWindowId();
        const configKey = getWindowConfigKey(CONFIG_KEYS.TOGGLE_STATES, wid);
        
        const result = await chrome.storage.local.get([configKey]);
        if (result[configKey]) {
            console.log('[Config] ✅ 获取开关状态配置:', result[configKey], { windowId: wid });
            return result[configKey];
        }
        return null;
    } catch (error) {
        console.error('[Config] ❌ 获取开关状态配置失败:', error);
        return null;
    }
}

/**
 * 清除指定窗口的所有配置
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<void>}
 */
export async function clearWindowConfig(windowId = null) {
    try {
        const wid = windowId || await getCurrentWindowId();
        const keysToRemove = [
            getWindowConfigKey(CONFIG_KEYS.DURATION, wid),
            getWindowConfigKey(CONFIG_KEYS.BROWSE_COUNT, wid),
            getWindowConfigKey(CONFIG_KEYS.TOGGLE_STATES, wid),
        ];
        
        await chrome.storage.local.remove(keysToRemove);
        console.log('[Config] 🗑️ 已清除窗口配置', { windowId: wid });
    } catch (error) {
        console.error('[Config] ❌ 清除窗口配置失败:', error);
    }
}

