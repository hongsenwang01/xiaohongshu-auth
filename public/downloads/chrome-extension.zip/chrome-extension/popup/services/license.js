// 授权验证服务

/**
 * 后端授权API配置
 */
const LICENSE_API = {
    //BASE_URL: 'https://oyosyatukogk.sealoshzh.site',
    BASE_URL: 'https://wmlkymczdpsc.sealoshzh.site',
    VERIFY_PATH: '/api/license/verify',
    BIND_PATH: '/api/license/bind'
};

/**
 * 验证授权
 * @param {string} redid - 小红书 redid
 * @returns {Promise<Object>} 返回验证结果
 */
export async function verifyLicense(redid) {
    try {
        //console.log('[License] 开始验证授权:', redid);
        
        if (!redid || !redid.trim()) {
            console.error('[License] redid 为空');
            return {
                valid: false,
                message: '无法获取账号信息',
                licenseCode: null,
                expiresAt: null
            };
        }
        
        const url = `${LICENSE_API.BASE_URL}${LICENSE_API.VERIFY_PATH}`;
        
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                redid: redid
            })
        });
        
        if (!response.ok) {
            console.error('[License] API 请求失败:', response.status, response.statusText);
            return {
                valid: false,
                message: '授权验证服务异常，请稍后重试',
                licenseCode: null,
                expiresAt: null
            };
        }
        
        const result = await response.json();
        
        // console.log('[License] 验证结果:', {
        //     valid: result.valid,
        //     message: result.message,
        //     licenseCode: result.licenseCode ? '***' : null,
        //     expiresAt: result.expiresAt
        // });
        
        return result;
        
    } catch (error) {
        console.error('[License] 授权验证失败:', error);
        return {
            valid: false,
            message: '授权验证服务连接失败，请检查网络',
            licenseCode: null,
            expiresAt: null
        };
    }
}

/**
 * 格式化过期时间
 * @param {string} expiresAt - ISO 格式的过期时间
 * @returns {string} 格式化后的时间字符串
 */
export function formatExpiresAt(expiresAt) {
    if (!expiresAt) return '';
    
    try {
        const date = new Date(expiresAt);
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        
        return `${year}-${month}-${day}`;
    } catch (error) {
        console.error('[License] 格式化过期时间失败:', error);
        return expiresAt;
    }
}

/**
 * 检查是否即将过期（7天内）
 * @param {string} expiresAt - ISO 格式的过期时间
 * @returns {boolean} 是否即将过期
 */
export function isExpiringSoon(expiresAt) {
    if (!expiresAt) return false;
    
    try {
        const expireDate = new Date(expiresAt);
        const now = new Date();
        const diffDays = Math.floor((expireDate - now) / (1000 * 60 * 60 * 24));
        
        return diffDays >= 0 && diffDays <= 7;
    } catch (error) {
        console.error('[License] 检查过期时间失败:', error);
        return false;
    }
}

/**
 * 获取剩余天数
 * @param {string} expiresAt - ISO 格式的过期时间
 * @returns {number} 剩余天数（负数表示已过期）
 */
export function getRemainingDays(expiresAt) {
    if (!expiresAt) return -1;
    
    try {
        const expireDate = new Date(expiresAt);
        const now = new Date();
        const diffDays = Math.ceil((expireDate - now) / (1000 * 60 * 60 * 24));
        
        return diffDays;
    } catch (error) {
        console.error('[License] 计算剩余天数失败:', error);
        return -1;
    }
}

/**
 * 绑定授权码到小红书账号
 * @param {string} licenseCode - 授权码
 * @param {string} redid - 小红书 redid
 * @returns {Promise<Object>} 返回绑定结果
 */
export async function bindLicense(licenseCode, redid) {
    try {
        console.log('[License] 开始绑定授权码:', { licenseCode, redid });
        
        if (!licenseCode || !licenseCode.trim()) {
            return {
                success: false,
                message: '授权码不能为空'
            };
        }
        
        if (!redid || !redid.trim()) {
            return {
                success: false,
                message: '无法获取账号信息'
            };
        }
        
        const url = `${LICENSE_API.BASE_URL}${LICENSE_API.BIND_PATH}`;
        
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                licenseCode: licenseCode.trim(),
                redid: redid
            })
        });
        
        if (!response.ok) {
            console.error('[License] 绑定API请求失败:', response.status, response.statusText);
            return {
                success: false,
                message: '授权服务异常，请稍后重试'
            };
        }
        
        const result = await response.json();
        
        console.log('[License] 绑定结果:', {
            success: result.success,
            message: result.message,
            boundCount: result.boundCount,
            maxBindings: result.maxBindings
        });
        
        return result;
        
    } catch (error) {
        console.error('[License] 绑定授权码失败:', error);
        return {
            success: false,
            message: '授权服务连接失败，请检查网络'
        };
    }
}

