/**
 * 已关注用户列表管理模块
 * 用于保存、加载、导出已关注的用户信息
 * 按窗口ID隔离存储
 */

import { fetchFollowList } from './license.js';

const STORAGE_KEY_BASE = 'followedUsersList';

/**
 * 生成窗口特定的存储键
 * @param {number|null} windowId - 窗口ID
 * @returns {string}
 */
function getWindowStorageKey(windowId) {
    if (windowId) {
        return `${STORAGE_KEY_BASE}_window_${windowId}`;
    }
    return STORAGE_KEY_BASE; // 兼容旧版本（无窗口ID）
}

/**
 * 添加用户到已关注列表（按窗口ID隔离）
 * @param {Object} userInfo - 用户信息
 * @param {string} userInfo.userId - 用户ID
 * @param {string} userInfo.userName - 用户昵称
 * @param {string} userInfo.userUrl - 用户主页URL
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<void>}
 */
export async function addFollowedUser(userInfo, windowId = null) {
    try {
        const list = await getFollowedUsers(windowId);
        
        // 检查是否已存在（使用userId去重）
        const exists = list.some(user => user.userId === userInfo.userId);
        if (exists) {
            console.log('[FollowedUsers] 用户已在列表中:', userInfo.userName, { windowId });
            return;
        }
        
        // 添加到列表
        list.push({
            userId: userInfo.userId,
            userName: userInfo.userName,
            userUrl: userInfo.userUrl,
            followedAt: new Date().toISOString()
        });
        
        // 保存到存储
        await saveFollowedUsers(list, windowId);
        console.log('[FollowedUsers] 添加用户成功:', userInfo.userName, { windowId });
    } catch (error) {
        console.error('[FollowedUsers] 添加用户失败:', error);
        throw error;
    }
}

/**
 * 获取已关注用户列表（按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<Array>}
 */
export async function getFollowedUsers(windowId = null) {
    return new Promise((resolve, reject) => {
        const storageKey = getWindowStorageKey(windowId);
        chrome.storage.local.get([storageKey], (result) => {
            if (chrome.runtime.lastError) {
                reject(new Error('读取失败: ' + chrome.runtime.lastError.message));
            } else {
                resolve(result[storageKey] || []);
            }
        });
    });
}

/**
 * 获取已关注用户的ID列表（用于快速过滤，按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<Array<string>>}
 */
export async function getFollowedUserIds(windowId = null) {
    const list = await getFollowedUsers(windowId);
    return list.map(user => user.userId);
}

/**
 * 获取已关注用户的昵称列表（用于快速过滤，按窗口ID隔离）
 * 优先从本地缓存读取，如果缓存为空则从服务器获取并初始化
 * @param {number|null} windowId - 窗口ID
 * @param {string} ownerRedid - 号主的小红书号（用于从服务器获取列表）
 * @returns {Promise<Array<string>>}
 */
export async function getFollowedUserNames(windowId = null, ownerRedid = null) {
    const list = await getFollowedUsers(windowId);
    
    // 如果本地缓存为空且提供了 ownerRedid，则尝试从服务器获取
    if (list.length === 0 && ownerRedid) {
        console.log('[FollowedUsers] 本地缓存为空，尝试从服务器获取关注列表...');
        const initialized = await initFollowedUsersFromServer(ownerRedid, windowId);
        if (initialized > 0) {
            // 重新获取列表
            const newList = await getFollowedUsers(windowId);
            return newList.map(user => user.userName);
        }
    }
    
    return list.map(user => user.userName);
}

/**
 * 从服务器初始化关注列表（只在本地缓存为空时调用）
 * @param {string} ownerRedid - 号主的小红书号
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<number>} 初始化的用户数量
 */
export async function initFollowedUsersFromServer(ownerRedid, windowId = null) {
    try {
        console.log('[FollowedUsers] 开始从服务器初始化关注列表...', { ownerRedid, windowId });
        
        // 调用接口获取关注列表
        const result = await fetchFollowList(ownerRedid);
        
        if (!result.success || !result.nicknameList || result.nicknameList.length === 0) {
            console.log('[FollowedUsers] 服务器返回空列表或失败');
            return 0;
        }
        
        // 将昵称列表转换为用户对象并保存到本地
        const userList = result.nicknameList.map(nickname => ({
            userId: nickname, // 使用昵称作为ID
            userName: nickname,
            userUrl: '',
            followedAt: new Date().toISOString(),
            fromServer: true // 标记为从服务器获取
        }));
        
        await saveFollowedUsers(userList, windowId);
        console.log(`[FollowedUsers] ✅ 从服务器初始化完成，共 ${userList.length} 个用户`, { windowId });
        
        return userList.length;
    } catch (error) {
        console.error('[FollowedUsers] ❌ 从服务器初始化失败:', error);
        return 0;
    }
}

/**
 * 保存已关注用户列表（按窗口ID隔离）
 * @param {Array} list - 用户列表
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<void>}
 */
async function saveFollowedUsers(list, windowId = null) {
    return new Promise((resolve, reject) => {
        const storageKey = getWindowStorageKey(windowId);
        chrome.storage.local.set({ [storageKey]: list }, () => {
            if (chrome.runtime.lastError) {
                reject(new Error('保存失败: ' + chrome.runtime.lastError.message));
            } else {
                resolve();
            }
        });
    });
}

/**
 * 清除已关注用户列表（按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID，如果为null则清除所有窗口的列表
 * @returns {Promise<void>}
 */
export async function clearFollowedUsers(windowId = null) {
    return new Promise(async (resolve, reject) => {
        try {
            if (windowId) {
                // 清除指定窗口的列表
                const storageKey = getWindowStorageKey(windowId);
                await chrome.storage.local.remove(storageKey);
                console.log('[FollowedUsers] 已清除指定窗口的已关注用户', { windowId });
                resolve();
            } else {
                // 清除所有窗口的列表
                const allData = await chrome.storage.local.get(null);
                const keysToRemove = Object.keys(allData).filter(key => 
                    key.startsWith(STORAGE_KEY_BASE)
                );
                
                if (keysToRemove.length > 0) {
                    await chrome.storage.local.remove(keysToRemove);
                    console.log('[FollowedUsers] 已清除所有窗口的已关注用户', { count: keysToRemove.length });
                }
                resolve();
            }
        } catch (error) {
            reject(new Error('清除失败: ' + error.message));
        }
    });
}

/**
 * 检查用户是否已在关注列表中（按窗口ID隔离）
 * @param {string} userId - 用户ID
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<boolean>}
 */
export async function isUserFollowed(userId, windowId = null) {
    const list = await getFollowedUsers(windowId);
    return list.some(user => user.userId === userId);
}

