// 消息通信服务
import { MESSAGE_TYPES } from '../../shared/constants.js';

/**
 * 发送消息到 content script
 * @param {number} tabId - 标签页ID
 * @param {Object} message - 消息对象
 * @returns {Promise<*>}
 */
export async function sendToContentScript(tabId, message) {
    try {
        const response = await chrome.tabs.sendMessage(tabId, message);
        return response;
    } catch (error) {
        console.error('发送消息到 content script 失败:', error);
        throw error;
    }
}

/**
 * 发送消息到 background script
 * @param {Object} message - 消息对象
 * @returns {Promise<*>}
 */
export async function sendToBackground(message) {
    try {
        const response = await chrome.runtime.sendMessage(message);
        return response;
    } catch (error) {
        console.error('发送消息到 background 失败:', error);
        throw error;
    }
}

/**
 * 获取当前活动标签页
 * @returns {Promise<chrome.tabs.Tab>}
 */
export async function getCurrentTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab;
}

/**
 * 检查当前页面是否是小红书
 * @returns {Promise<boolean>}
 */
export async function checkIsXhsPage() {
    try {
        const tab = await getCurrentTab();
        if (!tab || !tab.url) {
            return false;
        }
        return tab.url.includes('xiaohongshu.com');
    } catch (error) {
        console.error('检测页面失败:', error);
        return false;
    }
}

/**
 * 打开新标签页
 * @param {string} url - URL地址
 * @param {boolean} active - 是否激活
 * @returns {Promise<chrome.tabs.Tab>}
 */
export async function openNewTab(url, active = true) {
    return await chrome.tabs.create({ url, active });
}

/**
 * 等待标签页加载完成
 * @param {number} tabId - 标签页ID
 * @returns {Promise<void>}
 */
export function waitForTabLoad(tabId) {
    return new Promise((resolve) => {
        chrome.tabs.get(tabId, (tab) => {
            if (tab.status === 'complete') {
                console.log('标签页已完成加载');
                resolve();
            } else {
                console.log('等待标签页加载...');
                const listener = (updatedTabId, changeInfo) => {
                    if (updatedTabId === tabId && changeInfo.status === 'complete') {
                        console.log('标签页加载完成');
                        chrome.tabs.onUpdated.removeListener(listener);
                        resolve();
                    }
                };
                chrome.tabs.onUpdated.addListener(listener);
                
                // 设置超时防止无限等待
                setTimeout(() => {
                    chrome.tabs.onUpdated.removeListener(listener);
                    console.log('等待超时，继续执行');
                    resolve();
                }, 10000);
            }
        });
    });
}

