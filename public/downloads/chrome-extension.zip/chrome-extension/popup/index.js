// 小红书助手 - Popup 主入口
import { MESSAGE_TYPES, ERROR_MESSAGES, DEFAULT_CONFIG } from '../shared/constants.js';
import { checkIsXhsPage } from './services/message.js';
import { getBrowseState, startBrowseTask, stopBrowseTask, restoreTaskId, getCurrentTaskId } from './services/state.js';
import { showToast } from './ui/toast.js';
import { showPageDetectCard, showNormalUI } from './ui/page-detect.js';
import { handleBrowseUpdate } from './handlers/browse.js';
import { getUserInfo, refreshUserInfo } from './handlers/user.js';
import { launchXiaohongshu } from './utils/helpers.js';
import { loadHistoryStats, viewHistory, hideHistory, exportHistoryToFile, clearHistoryRecords } from './handlers/history.js';
import { initFilterOptions, getFilterConfig } from './handlers/filter.js';
import { 
    saveDurationConfig, 
    getDurationConfig, 
    saveBrowseCountConfig, 
    getBrowseCountConfig, 
    saveToggleStates, 
    getToggleStates 
} from './services/config.js';
import { 
    cacheCommentContents, 
    getCachedCommentContents,
    getCachedUserInfo
} from './services/cache.js';
import { verifyLicense, formatExpiresAt } from './services/license.js';
import { initLicensePageEvents, showLicensePage } from './handlers/license.js';

// 小红书助手类
class XiaohongshuAssistant {
    constructor() {
        this.posts = [];
        this.isFetchingPosts = false;  // 是否正在执行获取帖子任务
        this.fetchedPosts = [];  // 已获取的帖子列表（供后续执行使用）
        this.init();
    }

    async init() {
        //console.log('小红书助手已初始化');
        
        // 检测当前页面
        const isXhsPage = await checkIsXhsPage();
        
        if (!isXhsPage) {
            // 不是小红书页面，显示提示
            this.showPageDetect();
            return;
        }
        
        // 是小红书页面，正常初始化
        this.showNormal();
        
        // ⚠️ 重要：在绑定事件之前先恢复状态，避免按钮闪烁
        await this.restoreState();
        
        // 绑定事件
        this.bindEvents();

        // 初始化授权页面事件
        initLicensePageEvents();
        
        // 初始化过滤选项
        initFilterOptions();

        // 初始化页签状态
        this.initTabState();
        
        // 监听后台消息
        this.listenToMessages();
        
        // 获取用户信息
        await getUserInfo();
        
        // 加载历史统计
        await loadHistoryStats();
        
        // 恢复浏览时长配置
        await this.restoreDurationConfig();
        
        // 恢复浏览数量配置
        await this.restoreBrowseCountConfig();
        
        // 恢复开关状态
        await this.restoreToggleStates();
        
        // 恢复评论内容
        await this.restoreCommentContents();
    }
    
    /**
     * 显示页面检测提示
     */
    showPageDetect() {
        showPageDetectCard();
        
        // 绑定启动按钮事件
        const launchBtn = document.getElementById('launchXhsBtn');
        if (launchBtn) {
            launchBtn.addEventListener('click', async () => {
                try {
                    showToast('正在打开小红书...', 'info');
                    await launchXiaohongshu();
                } catch (error) {
                    showToast('启动失败，请手动打开小红书页面', 'error');
                }
            });
        }
    }
    
    /**
     * 显示正常UI
     */
    showNormal() {
        showNormalUI();
    }

    /**
     * 初始化页签状态
     */
    initTabState() {
        // 默认显示数量设置页签
        this.switchTab('count');

        // 根据是否有获取的帖子来设置自动化设置页签的禁用状态
        this.updateAutomationTabState();
    }

    /**
     * 更新自动化设置页签状态
     */
    updateAutomationTabState() {
        const automationTab = document.getElementById('automationTab');

        if (!automationTab) return;

        // 检查是否有已获取的帖子
        const hasPosts = this.fetchedPosts && this.fetchedPosts.length > 0;

        if (hasPosts) {
            // 有帖子，解锁自动化设置页签
            automationTab.disabled = false;
        } else {
            // 没有帖子，禁用自动化设置页签
            automationTab.disabled = true;
        }
    }
    
    /**
     * 绑定 Tab 切换事件
     */
    bindTabEvents() {
        const tabBtns = document.querySelectorAll('.tab-btn');

        tabBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                // 检查是否禁用
                if (btn.disabled) {
                    // 如果是自动化设置页签被禁用，显示提示
                    if (btn.getAttribute('data-tab') === 'automation') {
                        showToast('请先在"数量设置"页签获取帖子', 'info');
                    }
                    return;
                }

                const targetTab = btn.getAttribute('data-tab');
                this.switchTab(targetTab);
            });
        });
    }
    
    /**
     * 切换 Tab
     */
    switchTab(tabName) {
        // 更新按钮状态
        const tabBtns = document.querySelectorAll('.tab-btn');
        tabBtns.forEach(btn => {
            if (btn.getAttribute('data-tab') === tabName) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });
        
        // 更新面板显示
        const tabPanels = document.querySelectorAll('.tab-panel');
        tabPanels.forEach(panel => {
            if (panel.id === `${tabName}Panel`) {
                panel.classList.add('active');
            } else {
                panel.classList.remove('active');
            }
        });
        
        // 如果切换到自动化设置页签，更新帖子准备状态
        if (tabName === 'automation') {
            this.updatePostsReadyStatus();
        }
    }
    
    /**
     * 绑定帮助提示定位
     */
    bindHelpTooltip() {
        const helpIcon = document.getElementById('durationHelpIcon');
        if (!helpIcon) return;
        
        const tooltip = helpIcon.querySelector('.help-tooltip');
        if (!tooltip) return;
        
        helpIcon.addEventListener('mouseenter', () => {
            const rect = helpIcon.getBoundingClientRect();
            tooltip.style.left = `${rect.right + 5}px`;
            tooltip.style.top = `${rect.top - 10}px`;
        });
        
        // 绑定浏览数量帮助提示
        const countHelpIcon = document.getElementById('countHelpIcon');
        if (!countHelpIcon) return;
        
        const countTooltip = countHelpIcon.querySelector('.help-tooltip');
        if (!countTooltip) return;
        
        countHelpIcon.addEventListener('mouseenter', () => {
            const rect = countHelpIcon.getBoundingClientRect();
            countTooltip.style.left = `${rect.right + 5}px`;
            countTooltip.style.top = `${rect.top - 10}px`;
        });
    }
    
    /**
     * 恢复浏览时长配置（按窗口隔离）
     */
    async restoreDurationConfig() {
        try {
            const config = await getDurationConfig();
            if (config) {
                const durationMin = document.getElementById('durationMin');
                const durationMax = document.getElementById('durationMax');
                
                if (durationMin && config.min) {
                    durationMin.value = config.min;
                }
                if (durationMax && config.max) {
                    durationMax.value = config.max;
                }
                console.log('[Config] 已恢复浏览时长配置:', config);
            }
        } catch (error) {
            console.error('[Config] 恢复浏览时长配置失败:', error);
        }
    }
    
    /**
     * 恢复浏览数量配置（按窗口隔离）
     */
    async restoreBrowseCountConfig() {
        try {
            const count = await getBrowseCountConfig();
            if (count) {
                const browseCount = document.getElementById('browseCount');
                if (browseCount) {
                    browseCount.value = count;
                }
                console.log('[Config] 已恢复浏览数量配置:', count);
            }
        } catch (error) {
            console.error('[Config] 恢复浏览数量配置失败:', error);
        }
    }
    
    /**
     * 绑定时长输入框事件
     */
    bindDurationInputs() {
        const durationMin = document.getElementById('durationMin');
        const durationMax = document.getElementById('durationMax');
        
        if (durationMin) {
            durationMin.addEventListener('change', () => {
                const min = parseInt(durationMin.value) || 10;
                const max = parseInt(durationMax?.value) || 30;
                saveDurationConfig(min, max); // 使用新的配置服务
            });
        }
        
        if (durationMax) {
            durationMax.addEventListener('change', () => {
                const min = parseInt(durationMin?.value) || 10;
                const max = parseInt(durationMax.value) || 30;
                saveDurationConfig(min, max); // 使用新的配置服务
            });
        }
        
        // 绑定浏览数量输入框变化事件
        const browseCount = document.getElementById('browseCount');
        if (browseCount) {
            browseCount.addEventListener('change', () => {
                const count = parseInt(browseCount.value) || DEFAULT_CONFIG.DEFAULT_BROWSE_COUNT;
                // 限制范围
                const validCount = Math.max(
                    DEFAULT_CONFIG.MIN_BROWSE_COUNT,
                    Math.min(DEFAULT_CONFIG.MAX_BROWSE_COUNT, count)
                );
                browseCount.value = validCount;
                saveBrowseCountConfig(validCount); // 使用新的配置服务
            });
        }
    }
    
    /**
     * 恢复开关状态（按窗口隔离）
     */
    async restoreToggleStates() {
        try {
            const toggleStates = await getToggleStates();
            if (toggleStates) {
                const autoLikeToggle = document.getElementById('autoLikeToggle');
                const autoCollectToggle = document.getElementById('autoCollectToggle');
                const autoFollowToggle = document.getElementById('autoFollowToggle');
                const autoCommentToggle = document.getElementById('autoCommentToggle');
                const commentContentWrapper = document.getElementById('commentContentWrapper');
                
                if (autoLikeToggle && toggleStates.autoLike !== undefined) {
                    autoLikeToggle.checked = toggleStates.autoLike;
                }
                if (autoCollectToggle && toggleStates.autoCollect !== undefined) {
                    autoCollectToggle.checked = toggleStates.autoCollect;
                }
                if (autoFollowToggle && toggleStates.autoFollow !== undefined) {
                    autoFollowToggle.checked = toggleStates.autoFollow;
                }
                if (autoCommentToggle && toggleStates.autoComment !== undefined) {
                    autoCommentToggle.checked = toggleStates.autoComment;
                    
                    // 根据自动评论开关状态展开/收起评论内容区域
                    if (commentContentWrapper) {
                        if (toggleStates.autoComment) {
                            commentContentWrapper.classList.add('expanded');
                        } else {
                            commentContentWrapper.classList.remove('expanded');
                        }
                    }
                }
                
                console.log('[Config] 已恢复开关状态:', toggleStates);
            }
        } catch (error) {
            console.error('[Config] 恢复开关状态失败:', error);
        }
    }
    
    /**
     * 保存开关状态（按窗口隔离）
     */
    async saveToggleStatesInternal() {
        try {
            const autoLikeToggle = document.getElementById('autoLikeToggle');
            const autoCollectToggle = document.getElementById('autoCollectToggle');
            const autoFollowToggle = document.getElementById('autoFollowToggle');
            const autoCommentToggle = document.getElementById('autoCommentToggle');

            const toggleStates = {
                autoLike: autoLikeToggle ? autoLikeToggle.checked : false,
                autoCollect: autoCollectToggle ? autoCollectToggle.checked : false,
                autoFollow: autoFollowToggle ? autoFollowToggle.checked : false,
                autoComment: autoCommentToggle ? autoCommentToggle.checked : false
            };
            
            await saveToggleStates(toggleStates); // 使用新的配置服务
            console.log('[Config] 已保存开关状态:', toggleStates);
        } catch (error) {
            console.error('[Config] 保存开关状态失败:', error);
        }
    }
    
    /**
     * 绑定开关变化事件
     */
    bindToggleEvents() {
        const autoLikeToggle = document.getElementById('autoLikeToggle');
        const autoCollectToggle = document.getElementById('autoCollectToggle');
        const autoFollowToggle = document.getElementById('autoFollowToggle');
        const autoCommentToggle = document.getElementById('autoCommentToggle');
        const commentContentWrapper = document.getElementById('commentContentWrapper');
        
        if (autoLikeToggle) {
            autoLikeToggle.addEventListener('change', () => {
                this.saveToggleStatesInternal();
            });
        }
        
        if (autoCollectToggle) {
            autoCollectToggle.addEventListener('change', () => {
                this.saveToggleStatesInternal();
            });
        }

        if (autoFollowToggle) {
            autoFollowToggle.addEventListener('change', () => {
                this.saveToggleStatesInternal();
            });
        }

        if (autoCommentToggle) {
            autoCommentToggle.addEventListener('change', () => {
                // 切换评论内容区域的显示/隐藏
                if (commentContentWrapper) {
                    if (autoCommentToggle.checked) {
                        commentContentWrapper.classList.add('expanded');
                    } else {
                        commentContentWrapper.classList.remove('expanded');
                    }
                }
                this.saveToggleStatesInternal();
            });
        }
        
        // 绑定评论输入框的变化事件
        this.bindCommentInputs();
    }
    
    /**
     * 绑定评论输入框事件
     */
    bindCommentInputs() {
        const commentInput1 = document.getElementById('commentInput1');
        const commentInput2 = document.getElementById('commentInput2');
        const commentInput3 = document.getElementById('commentInput3');
        
        // 保存评论内容（防抖）
        let saveTimeout;
        const saveComments = async () => {
            clearTimeout(saveTimeout);
            saveTimeout = setTimeout(async () => {
                await this.saveCommentContents();
            }, 500); // 500ms 防抖
        };
        
        if (commentInput1) {
            commentInput1.addEventListener('input', saveComments);
        }
        if (commentInput2) {
            commentInput2.addEventListener('input', saveComments);
        }
        if (commentInput3) {
            commentInput3.addEventListener('input', saveComments);
        }
    }
    
    /**
     * 保存评论内容到缓存
     */
    async saveCommentContents() {
        try {
            const commentInput1 = document.getElementById('commentInput1');
            const commentInput2 = document.getElementById('commentInput2');
            const commentInput3 = document.getElementById('commentInput3');
            
            const comments = [
                commentInput1?.value?.trim() || '',
                commentInput2?.value?.trim() || '',
                commentInput3?.value?.trim() || ''
            ];
            
            // 获取当前窗口ID
            const currentWindow = await chrome.windows.getCurrent();
            const windowId = currentWindow.id;
            
            await cacheCommentContents(comments, windowId);
            console.log('[Comment] ✅ 评论内容已保存', { windowId, comments });
        } catch (error) {
            console.error('[Comment] ❌ 保存评论内容失败:', error);
        }
    }
    
    /**
     * 恢复评论内容
     */
    async restoreCommentContents() {
        try {
            // 获取当前窗口ID
            const currentWindow = await chrome.windows.getCurrent();
            const windowId = currentWindow.id;
            
            const comments = await getCachedCommentContents(windowId);
            
            const commentInput1 = document.getElementById('commentInput1');
            const commentInput2 = document.getElementById('commentInput2');
            const commentInput3 = document.getElementById('commentInput3');
            
            if (commentInput1 && comments[0]) {
                commentInput1.value = comments[0];
            }
            if (commentInput2 && comments[1]) {
                commentInput2.value = comments[1];
            }
            if (commentInput3 && comments[2]) {
                commentInput3.value = comments[2];
            }
            
            console.log('[Comment] ✅ 评论内容已恢复', { windowId, count: comments.length });
        } catch (error) {
            console.error('[Comment] ❌ 恢复评论内容失败:', error);
        }
    }
    
    /**
     * 绑定事件
     */
    bindEvents() {
        // Tab 切换
        this.bindTabEvents();
        
        // 绑定帮助提示定位
        this.bindHelpTooltip();
        
        // 绑定时长输入框变化事件
        this.bindDurationInputs();
        
        // 绑定开关变化事件
        this.bindToggleEvents();
        
        const startBrowseBtn = document.getElementById('startBrowseBtn');
        const stopBrowseBtn = document.getElementById('stopBrowseBtn');
        const refreshUserBtn = document.getElementById('refreshUserBtn');
        const viewHistoryBtn = document.getElementById('viewHistoryBtn');
        const exportHistoryBtn = document.getElementById('exportHistoryBtn');
        const clearHistoryBtn = document.getElementById('clearHistoryBtn');
        
        if (startBrowseBtn) {
            startBrowseBtn.addEventListener('click', () => this.handleStartBrowse());
        }
        
        if (stopBrowseBtn) {
            stopBrowseBtn.addEventListener('click', () => this.handleStopBrowse());
        }
        
        if (refreshUserBtn) {
            refreshUserBtn.addEventListener('click', () => this.handleRefreshUser());
        }
        
        if (viewHistoryBtn) {
            let historyVisible = false;
            viewHistoryBtn.addEventListener('click', () => {
                if (historyVisible) {
                    hideHistory();
                    viewHistoryBtn.textContent = '查看历史';
                    historyVisible = false;
                } else {
                    viewHistory();
                    viewHistoryBtn.textContent = '隐藏历史';
                    historyVisible = true;
                }
            });
        }
        
        if (exportHistoryBtn) {
            exportHistoryBtn.addEventListener('click', () => exportHistoryToFile());
        }
        
        if (clearHistoryBtn) {
            clearHistoryBtn.addEventListener('click', () => clearHistoryRecords());
        }
        
        // 获取帖子按钮
        const fetchPostsBtn = document.getElementById('fetchPostsBtn');
        const stopFetchPostsBtn = document.getElementById('stopFetchPostsBtn');
        
        if (fetchPostsBtn) {
            fetchPostsBtn.addEventListener('click', () => this.handleStartFetchPosts());
        }
        
        if (stopFetchPostsBtn) {
            stopFetchPostsBtn.addEventListener('click', () => this.handleStopFetchPosts());
        }
    }
    
    /**
     * 监听后台消息
     */
    listenToMessages() {
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            if (message.action === MESSAGE_TYPES.BROWSE_UPDATE) {
                handleBrowseUpdate(message);
            }
        });
    }
    
    /**
     * 恢复浏览状态
     */
    async restoreState() {
        try {
            // 恢复任务 ID
            const taskId = restoreTaskId();
            //console.log('📊 恢复任务ID:', taskId);
            
            if (taskId) {
                // 获取该任务的状态
                const state = await getBrowseState(taskId);
                
                //console.log('📊 检查浏览状态:', state);
                
                if (state && state.isRunning) {
                    // 任务正在运行
                    console.log('✅ 检测到任务正在运行，恢复UI状态');
                    
                    // 恢复按钮状态 - 显示"停止执行"按钮
                    this.setButtonState('browsing');
                    
                    // 恢复帖子数据
                    if (state.posts && state.posts.length > 0) {
                        this.posts = state.posts;
                        console.log(`🔄 恢复任务进度: ${state.currentIndex}/${state.totalPosts}`);
                    }
                } else {
                    // 任务未运行或已完成
                    //console.log('⏸️ 任务未运行，显示"开始执行"按钮');
                    this.setButtonState('idle');
                }
            } else {
                // 没有保存的任务ID
                //console.log('⏸️ 没有保存的任务，显示"开始执行"按钮');
                this.setButtonState('idle');
            }
        } catch (error) {
            console.error('恢复状态失败:', error);
            // 出错时默认显示"开始执行"按钮
            this.setButtonState('idle');
        }
    }
    
    /**
     * 更新帖子准备状态显示
     */
    updatePostsReadyStatus() {
        const postsReadyStatus = document.getElementById('postsReadyStatus');
        const postsReadyText = document.getElementById('postsReadyText');
        
        if (!postsReadyStatus || !postsReadyText) return;
        
        if (this.fetchedPosts && this.fetchedPosts.length > 0) {
            postsReadyStatus.style.display = 'block';
            postsReadyText.textContent = `已准备 ${this.fetchedPosts.length} 个帖子，可以开始执行`;
        } else {
            postsReadyStatus.style.display = 'none';
        }
    }
    
    /**
     * 处理开始执行
     */
    async handleStartBrowse() {
        try {
            // 检查是否已获取帖子
            if (!this.fetchedPosts || this.fetchedPosts.length === 0) {
                showToast('请先在"数量设置"页签获取帖子', 'error');
                // 自动跳转到数量设置页签
                this.switchTab('count');
                return;
            }
            
            console.log(`[Start Browse] 开始执行，共 ${this.fetchedPosts.length} 个帖子`);
            
            // 检查缓存的授权信息
            const currentWindow = await chrome.windows.getCurrent();
            const windowId = currentWindow.id;
            const userInfo = await getCachedUserInfo(windowId);
            
            if (!userInfo) {
                showToast('无法获取账号信息，请刷新后重试', 'error');
                return;
            }
            
            // 检查授权状态
            if (!userInfo.licenseValid) {
                console.error('[License] 授权验证失败: 该账号未授权或授权已过期');
                showToast('该账号未授权，请绑定授权码', 'error');
                // 显示授权页面
                showLicensePage();
                return;
            }
            
            // console.log('[License] ✅ 授权验证通过 (来自缓存)', {
            //     code: userInfo.licenseCode,
            //     daysRemaining: userInfo.licenseDaysRemaining
            // });
            
            // 读取自动化配置
            const config = this.getAutomationConfig();
            console.log('当前自动化配置:', config);
            
            // 检查是否至少开启了一个功能
            if (!config.autoLike && !config.autoCollect && !config.autoFollow && !config.autoComment) {
                showToast('请至少开启一个自动化功能', 'error');
                return;
            }
            
            // 检查自动评论的内容
            if (config.autoComment && (!config.commentContents || config.commentContents.length === 0)) {
                showToast('请至少输入一条评论内容', 'error');
                // 自动跳转到自动化设置页签
                this.switchTab('automation');
                return;
            }
            
            // 使用已获取的帖子列表
            this.posts = this.fetchedPosts;

            // 在开始执行前，先检查页面是否能响应消息
            try {
                const tab = await chrome.tabs.query({ active: true, currentWindow: true });
                if (tab[0]) {
                    await chrome.tabs.sendMessage(tab[0].id, { action: 'ping' });
                }
            } catch (error) {
                console.error('[Start Browse] 页面连接检查失败:', error);
                if (error.message.includes('Could not establish connection') || error.message.includes('Receiving end does not exist')) {
                    showToast('内容脚本未加载，正在刷新页面...', 'info');
                    const tab = await chrome.tabs.query({ active: true, currentWindow: true });
                    if (tab[0]) {
                        await chrome.tabs.reload(tab[0].id);
                        setTimeout(() => {
                            window.close();
                        }, 1000);
                    }
                    return;
                }
                throw error;
            }

            // 发送开始命令到后台
            const result = await startBrowseTask(this.posts, config);
            
            if (result.success) {
                // 切换按钮状态为"停止执行"
                this.setButtonState('browsing');
                
                const enabledFeatures = [];
                if (config.autoLike) enabledFeatures.push('点赞');
                if (config.autoCollect) enabledFeatures.push('收藏');
                if (config.autoComment) enabledFeatures.push('评论');
                showToast(`开始自动执行 ${this.posts.length} 个帖子（${enabledFeatures.join('、')}）`, 'success');
                //console.log(`✅ 任务已启动，任务ID: ${result.taskId}`);
            } else {
                this.setButtonState('idle');
            }

        } catch (error) {
            console.error('开始执行失败:', error);
            showToast('开始执行失败', 'error');
            this.setButtonState('idle');
        }
    }
    
    
    /**
     * 获取自动化配置
     */
    getAutomationConfig() {
        const autoLikeToggle = document.getElementById('autoLikeToggle');
        const autoCollectToggle = document.getElementById('autoCollectToggle');
        const autoFollowToggle = document.getElementById('autoFollowToggle');
        const autoCommentToggle = document.getElementById('autoCommentToggle');
        const durationMin = document.getElementById('durationMin');
        const durationMax = document.getElementById('durationMax');
        
        // 获取评论内容
        const commentInput1 = document.getElementById('commentInput1');
        const commentInput2 = document.getElementById('commentInput2');
        const commentInput3 = document.getElementById('commentInput3');
        
        const commentContents = [
            commentInput1?.value?.trim() || '',
            commentInput2?.value?.trim() || '',
            commentInput3?.value?.trim() || ''
        ].filter(content => content.length > 0); // 过滤掉空内容
        
        // 获取浏览时长配置
        let minDuration = parseInt(durationMin?.value) || 10;
        let maxDuration = parseInt(durationMax?.value) || 30;
        
        // 验证和修正时长范围
        minDuration = Math.max(5, Math.min(120, minDuration));
        maxDuration = Math.max(5, Math.min(120, maxDuration));
        
        // 确保最小值不大于最大值
        if (minDuration > maxDuration) {
            [minDuration, maxDuration] = [maxDuration, minDuration];
        }
        
        return {
            autoLike: autoLikeToggle ? autoLikeToggle.checked : false,
            autoCollect: autoCollectToggle ? autoCollectToggle.checked : false,
            autoFollow: autoFollowToggle ? autoFollowToggle.checked : false,
            autoComment: autoCommentToggle ? autoCommentToggle.checked : false,
            commentContents: commentContents, // 评论内容数组
            durationMin: minDuration,
            durationMax: maxDuration
        };
    }
    
    /**
     * 处理停止浏览
     */
    async handleStopBrowse() {
        try {
            const success = await stopBrowseTask();
            
            if (success) {
                // 切换按钮状态
                this.setButtonState('idle');
                console.log('已发送停止命令');
            }
        } catch (error) {
            console.error('停止浏览失败:', error);
        }
    }
    
    /**
     * 设置按钮状态
     * @param {string} state - 状态：'idle', 'browsing'
     */
    setButtonState(state) {
        const startBtn = document.getElementById('startBrowseBtn');
        const stopBrowseBtn = document.getElementById('stopBrowseBtn');
        
        //console.log(`🔄 设置按钮状态: ${state}`);
        
        if (!startBtn || !stopBrowseBtn) {
            console.warn('⚠️ 按钮元素未找到');
            return;
        }
        
        // 隐藏所有按钮
        startBtn.style.display = 'none';
        stopBrowseBtn.style.display = 'none';
        
        switch (state) {
            case 'idle':
                // 空闲状态 - 显示"开始执行"
                startBtn.style.display = 'flex';
                //console.log('✅ 显示"开始执行"按钮');
                break;
                
            case 'browsing':
                // 浏览中 - 显示"停止执行"
                stopBrowseBtn.style.display = 'flex';
                //console.log('✅ 显示"停止执行"按钮');
                break;
                
            default:
                startBtn.style.display = 'flex';
                console.warn('⚠️ 未知状态，显示默认按钮');
        }
    }
    
    /**
     * 切换浏览按钮状态（兼容旧代码）
     * @param {boolean} isRunning - 是否正在运行
     */
    toggleBrowseButtons(isRunning) {
        this.setButtonState(isRunning ? 'browsing' : 'idle');
    }
    
    /**
     * 处理刷新用户信息
     */
    async handleRefreshUser() {
        await refreshUserInfo();
    }
    
    /**
     * 处理开始获取帖子
     */
    async handleStartFetchPosts() {
        try {
            // 获取目标数量
            const browseCountInput = document.getElementById('browseCount');
            const targetCount = parseInt(browseCountInput?.value) || 50;
            
            console.log(`[Fetch] 📥 开始获取帖子，目标 ${targetCount} 个`);
            
            const fetchPostsBtn = document.getElementById('fetchPostsBtn');
            const stopFetchPostsBtn = document.getElementById('stopFetchPostsBtn');
            
            // 切换按钮
            if (fetchPostsBtn) fetchPostsBtn.style.display = 'none';
            if (stopFetchPostsBtn) stopFetchPostsBtn.style.display = 'block';
            
            // 初始化
            this.isFetchingPosts = true;
            this.fetchedPosts = [];
            
            // 开始获取流程
            await this.runFetchPosts(targetCount);
            
        } catch (error) {
            console.error('[Fetch] ❌ 获取失败:', error);
            showToast('获取帖子失败', 'error');
            this.handleStopFetchPosts();
        }
    }
    
    /**
     * 运行获取帖子流程
     */
    async runFetchPosts(targetCount) {
        try {
            // 获取当前页面的帖子
            const tab = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tab[0] || !tab[0].url.includes('xiaohongshu.com')) {
                showToast('请在小红书页面使用此功能', 'error');
                this.handleStopFetchPosts();
                return;
            }
            
            const tabId = tab[0].id;
            let allPosts = [];
            let displayedCount = 0;
            let scrollAttempts = 0;
            const maxScrollAttempts = 20; // 最大滚动次数
            
            while (this.isFetchingPosts && displayedCount < targetCount && scrollAttempts < maxScrollAttempts) {
                // 获取当前页面的所有帖子
                
                let response;
                try {
                    response = await chrome.tabs.sendMessage(tabId, {
                        action: MESSAGE_TYPES.GET_POSTS
                    });
                } catch (error) {
                    console.error('[Fetch] 连接错误:', error);
                    if (error.message.includes('Could not establish connection') || error.message.includes('Receiving end does not exist')) {
                        showToast('内容脚本未加载，正在刷新页面...', 'info');
                        // 刷新当前页面并关闭插件
                        await chrome.tabs.reload(tabId);
                        setTimeout(() => {
                            window.close();
                        }, 1000);
                        return;
                    }
                    throw error;
                }

                if (!response || !response.success) {
                    showToast('获取帖子失败', 'error');
                    break;
                }
                
                const currentPosts = response.data;
                
                //console.log(`[Fetch] 📖 第 ${scrollAttempts + 1} 次获取，当前页面共 ${currentPosts.length} 个帖子`);
                
                // 找出新增的帖子（通过 link 去重）
                const existingLinks = new Set(allPosts.map(p => p.link));
                const newPosts = currentPosts.filter(p => !existingLinks.has(p.link));
                
                if (newPosts.length > 0) {
                    //console.log(`[Fetch] ✅ 发现 ${newPosts.length} 个新帖子`);
                    
                    // 添加到总列表
                    allPosts.push(...newPosts);
                    
                    for (const post of newPosts) {
                        if (!this.isFetchingPosts || displayedCount >= targetCount) {
                            break;
                        }
                        
                        displayedCount++;
                        console.log(`[Fetch] 📝 第 ${displayedCount} 个帖子: ${post.title}`);
                    }
                } else if (scrollAttempts === 0) {
                    // 第一次获取，即使没有新帖子也显示（因为都是新的）
                    //console.log(`[Fetch] ✅ 首次获取 ${currentPosts.length} 个帖子`);
                    allPosts = currentPosts;
                    
                    // 显示所有帖子
                    for (const post of currentPosts) {
                        if (!this.isFetchingPosts || displayedCount >= targetCount) {
                            break;
                        }
                        
                        displayedCount++;
                        console.log(`[Fetch] 📝 显示第 ${displayedCount} 个帖子: ${post.title}`);
                    }
                } else {
                    console.log(`[Fetch] ⚠️ 第 ${scrollAttempts + 1} 次滚动后没有新增帖子`);
                }
                
                // 如果已经达到目标数量，退出
                if (displayedCount >= targetCount) {
                    //console.log(`[Fetch] ✅ 已达到目标数量 ${targetCount} 个帖子`);
                    break;
                }
                
                // 如果没有新增帖子且已经滚动过至少一次，再尝试几次
                if (newPosts.length === 0 && scrollAttempts > 0) {
                    if (scrollAttempts >= 3) {
                        console.log(`[Fetch] ⚠️ 连续多次没有新帖子，可能已到底部`);
                        showToast(`只获取到 ${displayedCount} 个帖子，可能已到底部`, 'warning');
                        break;
                    }
                }
                
                // 需要滚动加载更多
                if (displayedCount < targetCount) {
                    scrollAttempts++;
                    console.log(`[Fetch] 📜 第 ${scrollAttempts} 次滚动加载更多...`);

                    // 滚动页面
                    try {
                        await chrome.tabs.sendMessage(tabId, {
                            action: 'scrollPage'
                        });
                    } catch (error) {
                        console.error('[Fetch] 滚动操作连接错误:', error);
                        if (error.message.includes('Could not establish connection') || error.message.includes('Receiving end does not exist')) {
                            showToast('内容脚本未加载，正在刷新页面...', 'info');
                            // 刷新当前页面并关闭插件
                            await chrome.tabs.reload(tabId);
                            setTimeout(() => {
                                window.close();
                            }, 1000);
                            return;
                        }
                        throw error;
                    }

                    // 等待页面加载新内容（给足够的时间）
                    console.log(`[Fetch] ⏱️ 等待 3 秒让新帖子加载...`);
                    await this.sleep(3000);
                }
            }
            
            // 保存获取到的帖子列表
            this.fetchedPosts = allPosts.slice(0, displayedCount);
            
            // 完成
            console.log(`[Fetch] 🎉 获取完成！共获取 ${displayedCount} 个帖子，滚动 ${scrollAttempts} 次`);
            //console.log(`[Fetch] 📦 已保存 ${this.fetchedPosts.length} 个帖子URL供后续使用`);
            showToast(`获取完成！共 ${displayedCount} 个帖子`, 'success');
            
            // 恢复按钮
            const fetchPostsBtn = document.getElementById('fetchPostsBtn');
            const stopFetchPostsBtn = document.getElementById('stopFetchPostsBtn');
            if (fetchPostsBtn) fetchPostsBtn.style.display = 'block';
            if (stopFetchPostsBtn) stopFetchPostsBtn.style.display = 'none';
            
            this.isFetchingPosts = false;
            
            // 自动跳转到自动化设置页签
            setTimeout(() => {
                // 解锁自动化设置页签
                this.updateAutomationTabState();
                this.switchTab('automation');
                this.updatePostsReadyStatus();
                showToast(`已准备 ${displayedCount} 个帖子，可以开始执行`, 'info');
            }, 1000);
            
        } catch (error) {
            console.error('[Fetch] 获取帖子失败:', error);
            showToast('获取帖子失败', 'error');
            this.handleStopFetchPosts();
        }
    }
    
    /**
     * 处理停止获取帖子
     */
    handleStopFetchPosts() {
        console.log('[Fetch] 🛑 停止获取');

        this.isFetchingPosts = false;

        const fetchPostsBtn = document.getElementById('fetchPostsBtn');
        const stopFetchPostsBtn = document.getElementById('stopFetchPostsBtn');

        if (fetchPostsBtn) fetchPostsBtn.style.display = 'block';
        if (stopFetchPostsBtn) stopFetchPostsBtn.style.display = 'none';

        // 更新自动化设置页签状态
        this.updateAutomationTabState();

        showToast('获取已停止', 'info');
    }
    
    /**
     * 等待指定毫秒数
     */
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// 初始化应用
document.addEventListener('DOMContentLoaded', () => {
    try {
        window.xiaohongshuApp = new XiaohongshuAssistant();
    } catch (error) {
        console.error('初始化失败:', error);
    }
});
