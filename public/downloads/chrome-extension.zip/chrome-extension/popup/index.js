import XiaohongshuAssistant from './assistant.js';

document.addEventListener('DOMContentLoaded', () => {
    try {
        window.xiaohongshuApp = new XiaohongshuAssistant();
    } catch (error) {
        console.error('初始化失败:', error);
    }
});
