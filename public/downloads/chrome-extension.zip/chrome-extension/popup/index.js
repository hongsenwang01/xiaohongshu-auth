// popup 主页 - 阶段选择页面
// 复用 assistant.js 的逻辑来初始化用户信息等
import { checkIsXhsPage } from './services/message.js';
import { showToast } from './ui/toast.js';
import { showPageDetectCard, showNormalUI } from './ui/page-detect.js';
import { getUserInfo, refreshUserInfo } from './handlers/user.js';
import { launchXiaohongshu } from './utils/helpers.js';
import { initLicensePageEvents } from './handlers/license.js';
import { getCachedUserInfo } from './services/cache.js';

document.addEventListener('DOMContentLoaded', async () => {
    try {
        console.log('[Popup] 主页初始化...');
        
        // 检查是否在小红书页面
        const isXhsPage = await checkIsXhsPage();
        if (!isXhsPage) {
            // 跳转到独立的页面检测页面
            window.location.href = chrome.runtime.getURL('page-detect.html');
            return;
        }
        
        // 显示正常UI
        showNormalUI();
        
        // 初始化授权页面事件
        initLicensePageEvents();
        
        // 获取用户信息（复用已有逻辑）
        await getUserInfo();
        
        // 检查授权状态，如果未授权则自动显示授权页面
        const currentWindow = await chrome.windows.getCurrent();
        const windowId = currentWindow.id;
        const userInfo = await getCachedUserInfo(windowId);
        
        if (userInfo && !userInfo.licenseValid) {
            console.log('[Popup] 检测到未授权，自动显示授权页面');
            const { showLicensePage } = await import('./handlers/license.js');
            showLicensePage();
        }
        
        // 绑定刷新按钮
        const refreshUserBtn = document.getElementById('refreshUserBtn');
        if (refreshUserBtn) {
            refreshUserBtn.addEventListener('click', async () => {
                await refreshUserInfo();
                
                // 刷新后重新检查授权状态
                const updatedUserInfo = await getCachedUserInfo(windowId);
                if (updatedUserInfo && !updatedUserInfo.licenseValid) {
                    console.log('[Popup] 刷新后检测到未授权，自动显示授权页面');
                    const { showLicensePage } = await import('./handlers/license.js');
                    showLicensePage();
                }
            });
        }
        
        // 绑定阶段选择卡片
        const newAccountCard = document.getElementById('newAccountCard');
        const matureAccountCard = document.getElementById('matureAccountCard');
        
        if (newAccountCard) {
            newAccountCard.addEventListener('click', async () => {
                console.log('[Popup] 选择: 新号起号阶段');
                
                // 检查授权
                const currentWindow = await chrome.windows.getCurrent();
                const windowId = currentWindow.id;
                const userInfo = await getCachedUserInfo(windowId);
                
                if (!userInfo) {
                    showToast('无法获取账号信息，请刷新后重试', 'error');
                    return;
                }
                
                if (!userInfo.licenseValid) {
                    console.error('[License] 授权验证失败: 该账号未授权或授权已过期');
                    showToast('该账号未授权，请绑定授权码', 'error');
                    const { showLicensePage } = await import('./handlers/license.js');
                    showLicensePage();
                    return;
                }
                
                // 授权验证通过，跳转到快速涨粉页面
                console.log('[Popup] 授权验证通过，跳转到快速涨粉页面');
                window.location.href = chrome.runtime.getURL('quick-follow.html');
            });
        }
        
        if (matureAccountCard) {
            matureAccountCard.addEventListener('click', async () => {
                console.log('[Popup] 选择: 成品号维护阶段');
                
                // 检查授权
                const currentWindow = await chrome.windows.getCurrent();
                const windowId = currentWindow.id;
                const userInfo = await getCachedUserInfo(windowId);
                
                if (!userInfo) {
                    showToast('无法获取账号信息，请刷新后重试', 'error');
                    return;
                }
                
                if (!userInfo.licenseValid) {
                    console.error('[License] 授权验证失败: 该账号未授权或授权已过期');
                    showToast('该账号未授权，请绑定授权码', 'error');
                    const { showLicensePage } = await import('./handlers/license.js');
                    showLicensePage();
                    return;
                }
                
                // 授权验证通过，跳转到 side-panel 页面（原来的主功能页面）
                console.log('[Popup] 授权验证通过，跳转到成品号维护页面');
                window.location.href = chrome.runtime.getURL('side-panel.html');
            });
        }
    } catch (error) {
        console.error('[Popup] 初始化失败:', error);
    }
});
