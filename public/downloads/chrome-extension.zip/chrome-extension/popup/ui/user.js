// 用户信息显示组件

/**
 * 显示用户信息
 * @param {Object} userInfo - 用户信息对象
 */
export function displayUserInfo(userInfo) {
    //console.log('显示用户信息:', userInfo);
    
    const userInfoElement = document.getElementById('userInfo');
    const userAvatarElement = document.getElementById('userAvatar');
    const userNameElement = document.getElementById('userName');
    
    if (!userInfoElement || !userAvatarElement || !userNameElement) {
        console.error('用户信息元素未找到');
        return;
    }
    
    // 设置头像
    userAvatarElement.src = userInfo.avatar;
    userAvatarElement.onerror = () => {
        // 如果头像加载失败，使用默认头像
        userAvatarElement.src = getDefaultAvatar();
    };
    
    // 设置用户名
    userNameElement.textContent = userInfo.username;
    
    // 设置详细信息（如果有）
    setDetailInfo('redIdItem', 'redIdTooltip', userInfo.redId);
    setDetailInfo('ipItem', 'ipTooltip', userInfo.ip);
    setDetailInfo('descItem', 'descTooltip', userInfo.desc);
    
    // 设置授权信息
    setLicenseInfo(userInfo);
    
    // 设置绑定授权码链接的状态
    setBindLicenseLinkState(userInfo);
    
    // 设置统计数据（如果有）
    if (userInfo.follows || userInfo.fans || userInfo.liked) {
        const statsItem = document.getElementById('statsItem');
        const followsTooltip = document.getElementById('followsTooltip');
        const fansTooltip = document.getElementById('fansTooltip');
        const likedTooltip = document.getElementById('likedTooltip');
        
        if (statsItem && followsTooltip && fansTooltip && likedTooltip) {
            followsTooltip.textContent = userInfo.follows || '0';
            fansTooltip.textContent = userInfo.fans || '0';
            likedTooltip.textContent = userInfo.liked || '0';
            statsItem.style.display = 'flex';
        }
    }
    
    // 显示用户信息区域
    userInfoElement.style.display = 'flex';
    
    //console.log('✅ 用户信息显示完成');
}

/**
 * 设置详细信息项
 * @param {string} itemId - 项目ID
 * @param {string} tooltipId - Tooltip ID
 * @param {string} value - 值
 */
function setDetailInfo(itemId, tooltipId, value) {
    if (value) {
        const item = document.getElementById(itemId);
        const tooltip = document.getElementById(tooltipId);
        if (item && tooltip) {
            tooltip.textContent = value;
            item.style.display = 'flex';
        }
    }
}

/**
 * 设置授权信息
 * @param {Object} userInfo - 用户信息对象（包含授权信息）
 */
function setLicenseInfo(userInfo) {
    const licenseItem = document.getElementById('licenseItem');
    const licenseTooltip = document.getElementById('licenseTooltip');
    const licenseDaysItem = document.getElementById('licenseDaysItem');
    const licenseDaysTooltip = document.getElementById('licenseDaysTooltip');
    
    if (!licenseItem || !licenseTooltip || !licenseDaysItem || !licenseDaysTooltip) {
        console.warn('[UI] 授权信息元素未找到');
        return;
    }
    
    // 显示授权信息项
    licenseItem.style.display = 'flex';
    licenseDaysItem.style.display = 'flex';
    
    // 设置授权码
    if (userInfo.licenseValid && userInfo.licenseCode) {
        licenseTooltip.textContent = userInfo.licenseCode;
        licenseTooltip.style.color = '#34C759'; // 绿色表示已授权
    } else if (userInfo.licenseMessage && userInfo.licenseMessage.includes('已过期')) {
        // 授权码已过期（根据接口返回的消息判断）
        licenseTooltip.textContent = '授权码已过期，请联系管理员';
        licenseTooltip.style.color = '#FF3B30'; // 红色表示已过期
    } else {
        licenseTooltip.textContent = '未授权';
        licenseTooltip.style.color = '#8E8E93'; // 红色表示未授权
    }
    
    // 设置剩余天数
    if (userInfo.licenseValid && userInfo.licenseDaysRemaining !== null && userInfo.licenseDaysRemaining !== undefined) {
        const days = userInfo.licenseDaysRemaining;
        licenseDaysTooltip.textContent = days >= 0 ? `${days} 天` : '已过期';
        
        // 根据剩余天数设置颜色
        if (days < 0) {
            licenseDaysTooltip.style.color = '#FF3B30'; // 红色：已过期
        } else if (days <= 7) {
            licenseDaysTooltip.style.color = '#FF9500'; // 橙色：即将过期
        } else {
            licenseDaysTooltip.style.color = '#34C759'; // 绿色：正常
        }
    } else {
        licenseDaysTooltip.textContent = '-';
        licenseDaysTooltip.style.color = '#8E8E93'; // 灰色
    }
    
    // console.log('[UI] 授权信息已显示:', {
    //     valid: userInfo.licenseValid,
    //     code: userInfo.licenseCode,
    //     days: userInfo.licenseDaysRemaining
    // });
}

/**
 * 设置绑定授权码链接的状态
 * @param {Object} userInfo - 用户信息对象（包含授权信息）
 */
function setBindLicenseLinkState(userInfo) {
    const bindLicenseLink = document.getElementById('bindLicenseLink');
    
    if (!bindLicenseLink) {
        return;
    }
    
    // 始终保持可点击状态，允许用户更换或绑定授权码
    bindLicenseLink.style.opacity = '1';
    bindLicenseLink.style.cursor = 'pointer';
    bindLicenseLink.style.pointerEvents = 'auto';
    
    // 根据是否已有授权码设置不同的提示文字
    if (userInfo.licenseValid && userInfo.licenseCode) {
        bindLicenseLink.title = '点击更换授权码';
    } else {
        bindLicenseLink.title = '点击绑定授权码';
    }
}

/**
 * 获取默认头像
 * @returns {string}
 */
function getDefaultAvatar() {
    return 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32"><circle cx="16" cy="16" r="16" fill="%23ccc"/></svg>';
}

