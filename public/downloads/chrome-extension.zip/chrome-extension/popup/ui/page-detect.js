// 页面检测UI组件

/**
 * 显示页面检测提示卡片
 */
export function showPageDetectCard() {
    const pageDetectCard = document.getElementById('pageDetectCard');
    const tabContainer = document.getElementById('tabContainer');
    const progressCard = document.getElementById('progressCard');
    
    if (pageDetectCard) pageDetectCard.style.display = 'block';
    if (tabContainer) tabContainer.style.display = 'none';
    if (progressCard) progressCard.style.display = 'none';
}

/**
 * 显示正常UI
 */
export function showNormalUI() {
    const pageDetectCard = document.getElementById('pageDetectCard');
    const tabContainer = document.getElementById('tabContainer');
    
    if (pageDetectCard) pageDetectCard.style.display = 'none';
    if (tabContainer) tabContainer.style.display = 'block';
}

