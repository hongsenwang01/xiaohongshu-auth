// 消息提示组件
import { DEFAULT_CONFIG } from '../../shared/constants.js';

/**
 * 显示Toast消息
 * @param {string} message - 消息内容
 * @param {string} type - 消息类型 (info/success/error/warning)
 * @param {number} duration - 持续时间（毫秒）
 */
export function showToast(message, type = 'info', duration = DEFAULT_CONFIG.TOAST_DURATION) {
    const toastContainer = document.getElementById('toastContainer');
    if (!toastContainer) {
        console.warn('Toast容器未找到');
        return;
    }

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    
    toastContainer.appendChild(toast);
    
    // 自动移除
    setTimeout(() => {
        toast.classList.add('fade-out');
        setTimeout(() => {
            if (toast.parentNode) {
                toastContainer.removeChild(toast);
            }
        }, 300);
    }, duration);
}

