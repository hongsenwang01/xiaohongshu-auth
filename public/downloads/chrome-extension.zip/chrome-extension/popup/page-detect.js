// 页面检测页面脚本
import { showToast } from './ui/toast.js';
import { launchXiaohongshu } from './utils/helpers.js';

document.addEventListener('DOMContentLoaded', () => {
    const launchBtn = document.getElementById('launchXhsBtn');
    if (launchBtn) {
        launchBtn.addEventListener('click', async () => {
            try {
                showToast('正在打开小红书...', 'info');
                await launchXiaohongshu();
            } catch (error) {
                showToast('启动失败，请手动打开小红书页面', 'error');
            }
        });
    }
});

