/**
 * 过滤选项处理器
 * 管理过滤名单的下载、上传和存储
 */

import { 
    generateExcludeListTemplate, 
    generateFocusListTemplate,
    downloadTemplate,
    parseExcelFile,
    validateUsernames,
    saveUsernamesToStorage,
    getUsernamesFromStorage,
    clearUsernamesFromStorage
} from '../../shared/excel-templates.js';
import { showToast } from '../ui/toast.js';

const STORAGE_KEY_EXCLUDE = 'filter_exclude_list';
const STORAGE_KEY_FOCUS = 'filter_focus_list';

/**
 * 初始化过滤选项事件
 */
export function initFilterOptions() {
    // 排除名单事件
    bindExcludeFilterEvents();
    
    // 重点关注事件
    bindFocusFilterEvents();
    
    // 恢复已保存的过滤设置
    restoreFilterStates();
}

/**
 * 绑定排除名单事件
 */
function bindExcludeFilterEvents() {
    const toggleBtn = document.getElementById('filterExcludeToggle');
    const expandArea = document.getElementById('filterExcludeArea');
    const downloadBtn = document.getElementById('downloadExcludeTemplateBtn');
    const uploadBtn = document.getElementById('uploadExcludeFileBtn');
    const fileInput = document.getElementById('filterExcludeFileInput');
    const clearBtn = document.getElementById('clearExcludeFileBtn');
    
    if (!toggleBtn) return;
    
    // 切换展开区域
    toggleBtn.addEventListener('change', (e) => {
        if (e.target.checked) {
            expandArea.style.display = 'block';
            saveFilterToggleState('exclude', true);
        } else {
            expandArea.style.display = 'none';
            saveFilterToggleState('exclude', false);
        }
    });
    
    // 下载模板
    if (downloadBtn) {
        downloadBtn.addEventListener('click', () => {
            const blob = generateExcludeListTemplate();
            downloadTemplate(blob, '排除名单模板.csv');
            showToast('模板已下载，请填写后上传', 'success');
        });
    }
    
    // 上传文件
    if (uploadBtn) {
        uploadBtn.addEventListener('click', () => {
            fileInput.click();
        });
    }
    
    // 处理文件选择
    if (fileInput) {
        fileInput.addEventListener('change', (e) => {
            handleExcludeFileUpload(e.target.files[0]);
        });
    }
    
    // 清除文件
    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            clearUsernamesFromStorage(STORAGE_KEY_EXCLUDE).then(() => {
                document.getElementById('filterExcludeFileInfo').style.display = 'none';
                fileInput.value = '';
                showToast('已清除排除名单', 'success');
            }).catch(err => {
                showToast('清除失败: ' + err.message, 'error');
            });
        });
    }
}

/**
 * 绑定重点关注事件
 */
function bindFocusFilterEvents() {
    const toggleBtn = document.getElementById('filterFocusToggle');
    const expandArea = document.getElementById('filterFocusArea');
    const downloadBtn = document.getElementById('downloadFocusTemplateBtn');
    const uploadBtn = document.getElementById('uploadFocusFileBtn');
    const fileInput = document.getElementById('filterFocusFileInput');
    const clearBtn = document.getElementById('clearFocusFileBtn');
    
    if (!toggleBtn) return;
    
    // 切换展开区域
    toggleBtn.addEventListener('change', (e) => {
        if (e.target.checked) {
            expandArea.style.display = 'block';
            saveFilterToggleState('focus', true);
        } else {
            expandArea.style.display = 'none';
            saveFilterToggleState('focus', false);
        }
    });
    
    // 下载模板
    if (downloadBtn) {
        downloadBtn.addEventListener('click', () => {
            const blob = generateFocusListTemplate();
            downloadTemplate(blob, '重点关注模板.csv');
            showToast('模板已下载，请填写后上传', 'success');
        });
    }
    
    // 上传文件
    if (uploadBtn) {
        uploadBtn.addEventListener('click', () => {
            fileInput.click();
        });
    }
    
    // 处理文件选择
    if (fileInput) {
        fileInput.addEventListener('change', (e) => {
            handleFocusFileUpload(e.target.files[0]);
        });
    }
    
    // 清除文件
    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            clearUsernamesFromStorage(STORAGE_KEY_FOCUS).then(() => {
                document.getElementById('filterFocusFileInfo').style.display = 'none';
                fileInput.value = '';
                showToast('已清除重点关注名单', 'success');
            }).catch(err => {
                showToast('清除失败: ' + err.message, 'error');
            });
        });
    }
}

/**
 * 处理排除名单文件上传
 */
async function handleExcludeFileUpload(file) {
    if (!file) return;
    
    try {
        const usernames = await parseExcelFile(file);
        const validation = validateUsernames(usernames);
        
        if (!validation.valid) {
            showToast('验证失败: ' + validation.message, 'error');
            return;
        }
        
        // 保存到存储
        await saveUsernamesToStorage(STORAGE_KEY_EXCLUDE, usernames);
        
        // 显示成功信息
        document.getElementById('filterExcludeFileName').textContent = file.name;
        document.getElementById('filterExcludeFileInfo').style.display = 'flex';
        
        showToast(validation.message, 'success');
    } catch (error) {
        showToast('处理失败: ' + error.message, 'error');
    }
}

/**
 * 处理重点关注文件上传
 */
async function handleFocusFileUpload(file) {
    if (!file) return;
    
    try {
        const usernames = await parseExcelFile(file);
        const validation = validateUsernames(usernames);
        
        if (!validation.valid) {
            showToast('验证失败: ' + validation.message, 'error');
            return;
        }
        
        // 保存到存储
        await saveUsernamesToStorage(STORAGE_KEY_FOCUS, usernames);
        
        // 显示成功信息
        document.getElementById('filterFocusFileName').textContent = file.name;
        document.getElementById('filterFocusFileInfo').style.display = 'flex';
        
        showToast(validation.message, 'success');
    } catch (error) {
        showToast('处理失败: ' + error.message, 'error');
    }
}

/**
 * 恢复过滤状态
 */
async function restoreFilterStates() {
    try {
        // 恢复排除名单状态
        const excludeData = await getUsernamesFromStorage(STORAGE_KEY_EXCLUDE);
        if (excludeData && excludeData.usernames && excludeData.usernames.length > 0) {
            document.getElementById('filterExcludeFileName').textContent = `${excludeData.count} 个用户`;
            document.getElementById('filterExcludeFileInfo').style.display = 'flex';
        }
        
        // 恢复重点关注状态
        const focusData = await getUsernamesFromStorage(STORAGE_KEY_FOCUS);
        if (focusData && focusData.usernames && focusData.usernames.length > 0) {
            document.getElementById('filterFocusFileName').textContent = `${focusData.count} 个用户`;
            document.getElementById('filterFocusFileInfo').style.display = 'flex';
        }
    } catch (error) {
        console.error('恢复过滤状态失败:', error);
    }
}

/**
 * 保存过滤开关状态
 */
function saveFilterToggleState(type, state) {
    const key = `filter_${type}_toggle`;
    chrome.storage.local.set({ [key]: state });
}

/**
 * 获取过滤配置（供外部使用）
 */
export async function getFilterConfig() {
    try {
        const excludeData = await getUsernamesFromStorage(STORAGE_KEY_EXCLUDE);
        const focusData = await getUsernamesFromStorage(STORAGE_KEY_FOCUS);
        
        const onlyFollowing = document.getElementById('onlyFollowingToggle')?.checked || false;
        const filterExclude = document.getElementById('filterExcludeToggle')?.checked || false;
        const filterFocus = document.getElementById('filterFocusToggle')?.checked || false;
        
        return {
            onlyFollowing,
            filterExclude,
            excludeList: filterExclude && excludeData ? excludeData.usernames : [],
            filterFocus,
            focusList: filterFocus && focusData ? focusData.usernames : []
        };
    } catch (error) {
        console.error('获取过滤配置失败:', error);
        return {
            onlyFollowing: false,
            filterExclude: false,
            excludeList: [],
            filterFocus: false,
            focusList: []
        };
    }
}
