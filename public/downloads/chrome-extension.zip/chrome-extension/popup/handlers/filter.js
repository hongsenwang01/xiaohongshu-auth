/**
 * 过滤选项处理器
 * 管理过滤名单的下载、上传和存储
 */

import { 
    generateFilterTemplate,
    downloadTemplate,
    parseExcelFile,
    validateUsernames,
    saveUsernamesToStorage,
    getUsernamesFromStorage,
    clearUsernamesFromStorage
} from '../../shared/excel-templates.js';
import { showToast } from '../ui/toast.js';

const STORAGE_KEY_EXCLUDE = 'filter_exclude_list';
const STORAGE_KEY_FOCUS = 'filter_focus_list';

/**
 * 初始化过滤选项事件
 */
export function initFilterOptions() {
    // 绑定Excel上传事件
    bindExcelUploadEvents();
    
    // 绑定过滤开关事件
    bindFilterToggleEvents();
    
    // 恢复过滤开关状态
    restoreFilterToggleStates();
    
    // 恢复Excel加载状态
    restoreExcelLoadedStates();
}

/**
 * 绑定Excel上传事件
 */
function bindExcelUploadEvents() {
    const downloadBtn = document.getElementById('downloadTemplateBtn');
    const uploadBtn = document.getElementById('uploadFileBtn');
    const fileInput = document.getElementById('filterFileInput');
    const clearBtn = document.getElementById('clearAllListsBtn');
    
    // 下载模板
    if (downloadBtn) {
        downloadBtn.addEventListener('click', () => {
            const blob = generateFilterTemplate();
            downloadTemplate(blob, '过滤名单模板.xls');
            showToast('模板已下载，包含两个sheet页', 'success');
        });
    }
    
    // 上传文件
    if (uploadBtn) {
        uploadBtn.addEventListener('click', () => {
            fileInput.click();
        });
    }
    
    // 处理文件选择
    if (fileInput) {
        fileInput.addEventListener('change', (e) => {
            handleFileUpload(e.target.files[0]);
        });
    }
    
    // 清除所有名单
    if (clearBtn) {
        clearBtn.addEventListener('click', async () => {
            try {
                await clearUsernamesFromStorage(STORAGE_KEY_EXCLUDE);
                await clearUsernamesFromStorage(STORAGE_KEY_FOCUS);
                
                document.getElementById('excludeListInfo').style.display = 'none';
                document.getElementById('focusListInfo').style.display = 'none';
                document.getElementById('clearAllListsBtn').style.display = 'none';
                fileInput.value = '';
                
                showToast('已清除所有名单', 'success');
            } catch (err) {
                showToast('清除失败: ' + err.message, 'error');
            }
        });
    }
}

/**
 * 绑定过滤开关事件
 */
function bindFilterToggleEvents() {
    // 只获取关注的
    const onlyFollowingToggle = document.getElementById('onlyFollowingToggle');
    if (onlyFollowingToggle) {
        onlyFollowingToggle.addEventListener('change', (e) => {
            saveFilterToggleState('following', e.target.checked);
        });
    }
    
    // 排除名单
    const filterExcludeToggle = document.getElementById('filterExcludeToggle');
    if (filterExcludeToggle) {
        filterExcludeToggle.addEventListener('change', (e) => {
            saveFilterToggleState('exclude', e.target.checked);
        });
    }
    
    // 重点关注
    const filterFocusToggle = document.getElementById('filterFocusToggle');
    if (filterFocusToggle) {
        filterFocusToggle.addEventListener('change', (e) => {
            saveFilterToggleState('focus', e.target.checked);
        });
    }
}

/**
 * 处理文件上传（同时解析两个sheet）
 */
async function handleFileUpload(file) {
    if (!file) return;
    
    try {
        // 解析Excel文件（返回 { excludeList: [], focusList: [] }）
        const data = await parseExcelFile(file);
        const validation = validateUsernames(data);
        
        if (!validation.valid) {
            showToast('验证失败: ' + validation.message, 'error');
            return;
        }
        
        // 分别保存两个列表
        if (data.excludeList && data.excludeList.length > 0) {
            await saveUsernamesToStorage(STORAGE_KEY_EXCLUDE, data.excludeList);
            document.getElementById('excludeListCount').textContent = data.excludeList.length;
            document.getElementById('excludeListInfo').style.display = 'flex';
        } else {
            await clearUsernamesFromStorage(STORAGE_KEY_EXCLUDE);
            document.getElementById('excludeListInfo').style.display = 'none';
        }
        
        if (data.focusList && data.focusList.length > 0) {
            await saveUsernamesToStorage(STORAGE_KEY_FOCUS, data.focusList);
            document.getElementById('focusListCount').textContent = data.focusList.length;
            document.getElementById('focusListInfo').style.display = 'flex';
        } else {
            await clearUsernamesFromStorage(STORAGE_KEY_FOCUS);
            document.getElementById('focusListInfo').style.display = 'none';
        }
        
        // 显示清除按钮
        if ((data.excludeList && data.excludeList.length > 0) || 
            (data.focusList && data.focusList.length > 0)) {
            document.getElementById('clearAllListsBtn').style.display = 'inline-block';
        } else {
            document.getElementById('clearAllListsBtn').style.display = 'none';
        }
        
        showToast(validation.message, 'success');
    } catch (error) {
        showToast('处理失败: ' + error.message, 'error');
    }
}

/**
 * 恢复Excel加载状态
 */
async function restoreExcelLoadedStates() {
    try {
        // 恢复排除名单状态
        const excludeData = await getUsernamesFromStorage(STORAGE_KEY_EXCLUDE);
        if (excludeData && excludeData.usernames && excludeData.usernames.length > 0) {
            document.getElementById('excludeListCount').textContent = excludeData.count || excludeData.usernames.length;
            document.getElementById('excludeListInfo').style.display = 'flex';
        }
        
        // 恢复重点关注状态
        const focusData = await getUsernamesFromStorage(STORAGE_KEY_FOCUS);
        if (focusData && focusData.usernames && focusData.usernames.length > 0) {
            document.getElementById('focusListCount').textContent = focusData.count || focusData.usernames.length;
            document.getElementById('focusListInfo').style.display = 'flex';
        }
        
        // 如果有任何名单，显示清除按钮
        if ((excludeData && excludeData.usernames && excludeData.usernames.length > 0) ||
            (focusData && focusData.usernames && focusData.usernames.length > 0)) {
            document.getElementById('clearAllListsBtn').style.display = 'inline-block';
        }
    } catch (error) {
        console.error('恢复Excel加载状态失败:', error);
    }
}

/**
 * 保存过滤开关状态
 */
async function saveFilterToggleState(type, state) {
    try {
        const currentWindow = await chrome.windows.getCurrent();
        const windowId = currentWindow.id;
        const key = `filter_${type}_toggle_window_${windowId}`;
        await chrome.storage.local.set({ [key]: state });
        console.log(`[Filter] ✅ 已保存${type}过滤开关状态:`, state, { windowId });
    } catch (error) {
        console.error(`[Filter] ❌ 保存${type}过滤开关状态失败:`, error);
    }
}

/**
 * 恢复过滤开关状态
 */
async function restoreFilterToggleStates() {
    try {
        const currentWindow = await chrome.windows.getCurrent();
        const windowId = currentWindow.id;
        
        // 恢复只获取关注的开关
        const onlyFollowingKey = `filter_following_toggle_window_${windowId}`;
        const onlyFollowingResult = await chrome.storage.local.get([onlyFollowingKey]);
        const onlyFollowingToggle = document.getElementById('onlyFollowingToggle');
        if (onlyFollowingToggle && onlyFollowingResult[onlyFollowingKey] !== undefined) {
            onlyFollowingToggle.checked = onlyFollowingResult[onlyFollowingKey];
        }
        
        // 恢复排除名单开关
        const excludeKey = `filter_exclude_toggle_window_${windowId}`;
        const excludeResult = await chrome.storage.local.get([excludeKey]);
        const filterExcludeToggle = document.getElementById('filterExcludeToggle');
        const filterExcludeArea = document.getElementById('filterExcludeArea');
        if (filterExcludeToggle && excludeResult[excludeKey] !== undefined) {
            filterExcludeToggle.checked = excludeResult[excludeKey];
            if (filterExcludeArea && excludeResult[excludeKey]) {
                filterExcludeArea.style.display = 'block';
            }
        }
        
        // 恢复重点关注开关
        const focusKey = `filter_focus_toggle_window_${windowId}`;
        const focusResult = await chrome.storage.local.get([focusKey]);
        const filterFocusToggle = document.getElementById('filterFocusToggle');
        const filterFocusArea = document.getElementById('filterFocusArea');
        if (filterFocusToggle && focusResult[focusKey] !== undefined) {
            filterFocusToggle.checked = focusResult[focusKey];
            if (filterFocusArea && focusResult[focusKey]) {
                filterFocusArea.style.display = 'block';
            }
        }
        
        console.log('[Filter] ✅ 已恢复过滤开关状态', { windowId });
    } catch (error) {
        console.error('[Filter] ❌ 恢复过滤开关状态失败:', error);
    }
}

/**
 * 获取过滤配置（供外部使用）
 */
export async function getFilterConfig() {
    try {
        const excludeData = await getUsernamesFromStorage(STORAGE_KEY_EXCLUDE);
        const focusData = await getUsernamesFromStorage(STORAGE_KEY_FOCUS);
        
        const onlyFollowing = document.getElementById('onlyFollowingToggle')?.checked || false;
        const filterExclude = document.getElementById('filterExcludeToggle')?.checked || false;
        const filterFocus = document.getElementById('filterFocusToggle')?.checked || false;
        
        return {
            onlyFollowing,
            filterExclude,
            excludeList: filterExclude && excludeData ? excludeData.usernames : [],
            filterFocus,
            focusList: filterFocus && focusData ? focusData.usernames : []
        };
    } catch (error) {
        console.error('获取过滤配置失败:', error);
        return {
            onlyFollowing: false,
            filterExclude: false,
            excludeList: [],
            filterFocus: false,
            focusList: []
        };
    }
}
