// 浏览任务处理器
import { BROWSE_EVENT_TYPES, ERROR_MESSAGES } from '../../shared/constants.js';
import { showToast } from '../ui/toast.js';
import { loadHistoryStats } from './history.js';
import { getCurrentTaskId } from '../services/state.js';

// 保存当前浏览配置
let currentBrowseConfig = {
    durationMin: 10,
    durationMax: 30
};

/**
 * 处理浏览更新消息
 * @param {Object} message - 消息对象
 */
export function handleBrowseUpdate(message) {
    const { taskId, type, data } = message;
    
    // 只处理当前任务的消息
    const currentId = getCurrentTaskId();
    if (currentId && taskId !== currentId) {
        console.log(`[Browse Handler] 忽略其他任务的消息: ${taskId} (当前任务: ${currentId})`);
        return;
    }
    
    switch (type) {
        case BROWSE_EVENT_TYPES.STARTED:
            handleBrowseStarted(data);
            break;
            
        case BROWSE_EVENT_TYPES.PROGRESS:
            handleBrowseProgress(data);
            break;
            
        case BROWSE_EVENT_TYPES.TAB_OPENED:
            handleTabOpened(data);
            break;
            
        case BROWSE_EVENT_TYPES.TAB_CLOSED:
            handleTabClosed();
            break;
            
        case BROWSE_EVENT_TYPES.LIKING:
            handleLiking(data);
            break;
            
        case BROWSE_EVENT_TYPES.LIKE_SUCCESS:
            handleLikeSuccess(data);
            break;
            
        case BROWSE_EVENT_TYPES.LIKE_ERROR:
            handleLikeError(data);
            break;
            
        case BROWSE_EVENT_TYPES.COLLECTING:
            handleCollecting(data);
            break;
            
        case BROWSE_EVENT_TYPES.COLLECT_SUCCESS:
            handleCollectSuccess(data);
            break;
            
        case BROWSE_EVENT_TYPES.COLLECT_ERROR:
            handleCollectError(data);
            break;

        case BROWSE_EVENT_TYPES.FOLLOWING:
            handleFollowing(data);
            break;

        case BROWSE_EVENT_TYPES.FOLLOW_SUCCESS:
            handleFollowSuccess(data);
            break;

        case BROWSE_EVENT_TYPES.FOLLOW_ERROR:
            handleFollowError(data);
            break;

        case BROWSE_EVENT_TYPES.COMMENTING:
            handleCommenting(data);
            break;
            
        case BROWSE_EVENT_TYPES.COMMENT_SUCCESS:
            handleCommentSuccess();
            break;
            
        case BROWSE_EVENT_TYPES.COMMENT_ERROR:
            handleCommentError(data);
            break;
            
        case BROWSE_EVENT_TYPES.ERROR:
            handleError(data);
            break;
            
        case BROWSE_EVENT_TYPES.STOPPED:
            handleBrowseStopped();
            break;
            
        case BROWSE_EVENT_TYPES.COMPLETED:
            handleBrowseCompleted();
            break;
            
        default:
            console.warn('未知的浏览更新类型:', type);
    }
}

function handleBrowseStarted(data) {
    // 保存配置信息
    if (data.config) {
        currentBrowseConfig = {
            durationMin: data.config.durationMin || 10,
            durationMax: data.config.durationMax || 30
        };
    }
    console.log('📖 开始浏览任务');
}

function handleBrowseProgress(data) {
    console.log(`[${data.currentIndex}/${data.totalPosts}] 正在浏览: ${data.currentPost.title}`);
}

function handleTabOpened(data) {
    //console.log(`✅ 标签页已打开 (ID: ${data.tabId})`);
}

function handleTabClosed() {
    //console.log(`🗑️ 标签页已关闭`);
}

function handleLiking(data) {
    console.log(`👍 准备点赞，将在 ${data.delay} 秒后执行...`);
}

function handleLikeSuccess(data) {
    if (data.alreadyLiked) {
        console.log(`⏭️ 已经点赞过了`);
    } else {
        console.log(`✅ 点赞成功！`);
    }
}

function handleLikeError(data) {
    console.log(`⚠️ 点赞失败: ${data.error}`);
}

function handleCollecting(data) {
    console.log(`⭐ 准备收藏，将在 ${data.delay} 秒后执行...`);
}

function handleCollectSuccess(data) {
    if (data.alreadyCollected) {
        console.log(`⏭️ 已经收藏过了`);
    } else {
        console.log(`✅ 收藏成功！`);
    }
}

function handleCollectError(data) {
    console.log(`⚠️ 收藏失败: ${data.error}`);
}

function handleFollowing(data) {
    console.log(`👤 准备关注，将在 ${data.delay} 秒后执行...`);
}

function handleFollowSuccess(data) {
    if (data.alreadyFollowed) {
        console.log(`⏭️ 已经关注过了`);
    } else {
        console.log(`✅ 关注成功！`);
    }
}

function handleFollowError(data) {
    console.log(`⚠️ 关注失败: ${data.error}`);
}

function handleCommenting(data) {
    console.log(`💬 准备评论，将在 ${data.delay} 秒后执行...`);
}

function handleCommentSuccess() {
    console.log(`✅ 评论成功！`);
}

function handleCommentError(data) {
    console.log(`⚠️ 评论失败: ${data.error}`);
}

function handleError(data) {
    console.log(`❌ 错误: ${data.error}`);
}

function handleBrowseStopped() {
    showToast('已停止浏览', 'info');
    //console.log('⏹️ 浏览已停止');
    
    // 恢复按钮状态
    toggleBrowseButtonsFromHandler(false);
}

function handleBrowseCompleted() {
    showToast('浏览完成！', 'success');
    //console.log('🎉 所有帖子浏览完成！');
    
    // 恢复按钮状态
    toggleBrowseButtonsFromHandler(false);
    
    // 刷新历史统计
    loadHistoryStats();
}

/**
 * 从handler切换浏览按钮状态
 * @param {boolean} isRunning - 是否正在运行
 */
function toggleBrowseButtonsFromHandler(isRunning) {
    const startBtn = document.getElementById('startBrowseBtn');
    const stopBtn = document.getElementById('stopBrowseBtn');
    
    if (startBtn && stopBtn) {
        if (isRunning) {
            startBtn.style.display = 'none';
            stopBtn.style.display = 'flex';
        } else {
            startBtn.style.display = 'flex';
            stopBtn.style.display = 'none';
        }
    }
}
