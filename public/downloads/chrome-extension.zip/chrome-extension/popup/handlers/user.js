// 用户信息处理器
import { MESSAGE_TYPES } from '../../shared/constants.js';
import { getCurrentTab, sendToContentScript, openNewTab, waitForTabLoad } from '../services/message.js';
import { displayUserInfo } from '../ui/user.js';
import { showToast } from '../ui/toast.js';
import { sleep } from '../../shared/utils.js';
import { getCachedUserInfo, cacheUserInfo } from '../services/cache.js';
import { verifyLicense, getRemainingDays } from '../services/license.js';

/**
 * 获取当前窗口ID
 * @returns {Promise<number|null>}
 */
async function getCurrentWindowId() {
    try {
        const currentWindow = await chrome.windows.getCurrent();
        return currentWindow.id;
    } catch (error) {
        console.error('[User] 获取窗口ID失败:', error);
        return null;
    }
}

/**
 * 验证用户授权并添加授权信息到用户对象
 * @param {Object} userInfo - 用户信息对象
 * @returns {Promise<Object>} 返回包含授权信息的用户对象
 */
async function verifyAndAddLicenseInfo(userInfo) {
    try {
        // 如果没有 redId，标记为未授权
        if (!userInfo.redId) {
            console.log('[License] 无法获取 redId，跳过授权验证');
            return {
                ...userInfo,
                licenseCode: null,
                licenseValid: false,
                licenseDaysRemaining: null,
                licenseMessage: null
            };
        }
        
        //console.log('[License] 开始验证授权:', userInfo.redId);
        const licenseResult = await verifyLicense(userInfo.redId);
        
        // 添加授权信息到用户对象
        const userInfoWithLicense = {
            ...userInfo,
            licenseCode: licenseResult.licenseCode,
            licenseValid: licenseResult.valid,
            licenseDaysRemaining: licenseResult.expiresAt ? getRemainingDays(licenseResult.expiresAt) : null,
            licenseExpiresAt: licenseResult.expiresAt,
            licenseMessage: licenseResult.message || null // 保存授权消息
        };
        
        if (licenseResult.valid) {
            // console.log('[License] ✅ 授权验证通过', {
            //     code: licenseResult.licenseCode,
            //     daysRemaining: userInfoWithLicense.licenseDaysRemaining
            // });
        } else {
            console.log('[License] ❌ 授权验证失败:', licenseResult.message);
        }
        
        return userInfoWithLicense;
        
    } catch (error) {
        console.error('[License] 授权验证异常:', error);
        // 验证失败，标记为未授权
        return {
            ...userInfo,
            licenseCode: null,
            licenseValid: false,
            licenseDaysRemaining: null,
            licenseMessage: null
        };
    }
}

/**
 * 获取用户信息（带缓存，按窗口隔离）
 * @param {boolean} forceRefresh - 是否强制刷新，忽略缓存
 * @returns {Promise<void>}
 */
export async function getUserInfo(forceRefresh = false) {
    try {
        //console.log('[User] 开始获取用户信息...', { forceRefresh });
        
        // 获取当前窗口ID
        const windowId = await getCurrentWindowId();
        //console.log('[User] 当前窗口ID:', windowId);
        
        // 如果不强制刷新，先检查缓存
        if (!forceRefresh) {
            const cachedUserInfo = await getCachedUserInfo(windowId);
            if (cachedUserInfo) {
                //console.log('[User] ✅ 使用缓存的用户信息 (窗口:', windowId, ')');
                displayUserInfo(cachedUserInfo);
                //showToast('用户信息已加载（来自缓存）', 'success', 2000);
                return;
            }
        }
        
        //console.log('[User] 从页面获取最新用户信息...');
        
        const tab = await getCurrentTab();
        if (!tab || !tab.id) {
            //console.log('[User] 未找到活动标签页');
            return;
        }
        
        // 发送消息到content script获取用户信息
        const response = await sendToContentScript(tab.id, {
            action: MESSAGE_TYPES.GET_USER_INFO
        });
        
        if (response && response.success && response.data) {
            const userInfo = response.data;
            
            // 如果需要获取详细信息
            if (userInfo.needsDetailedInfo && userInfo.profileUrl) {
                //console.log('[User] 需要获取详细信息，打开个人主页...');
                await fetchDetailedUserInfo(userInfo, windowId);
            } else {
                // 验证授权并添加授权信息
                const userInfoWithLicense = await verifyAndAddLicenseInfo(userInfo);
                
                // 直接显示并缓存（按窗口ID隔离）
                displayUserInfo(userInfoWithLicense);
                await cacheUserInfo(userInfoWithLicense, windowId);
                showToast('用户信息加载完成', 'success');
            }
        } else {
            //console.log('[User] 获取用户信息失败');
        }
    } catch (error) {
        console.error('[User] 获取用户信息失败:', error);
    }
}

/**
 * 获取详细用户信息（打开个人主页）
 * @param {Object} basicInfo - 基本信息
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<void>}
 */
async function fetchDetailedUserInfo(basicInfo, windowId) {
    let profileTab = null;
    
    try {
        //console.log('[User] 打开个人主页获取详细信息...', { windowId });
        showToast('正在获取用户信息...', 'info');
        
        // 构建完整URL
        const profileUrl = `https://www.xiaohongshu.com${basicInfo.profileUrl}`;
        //console.log('[User] 个人主页URL:', profileUrl);
        
        // 打开个人主页（后台标签页，在当前窗口中打开）
        profileTab = await openNewTab(profileUrl, false);
        
        //console.log('[User] 等待页面加载...');
        
        // 等待页面加载完成
        await waitForTabLoad(profileTab.id);
        
        // 额外等待确保内容渲染
        await sleep(2000);
        
        //console.log('[User] 从个人主页提取详细信息...');
        
        // 从个人主页获取详细信息
        const detailedResponse = await sendToContentScript(profileTab.id, {
            action: MESSAGE_TYPES.GET_USER_INFO
        });
        
        if (detailedResponse && detailedResponse.success && detailedResponse.data) {
            //console.log('[User] ✅ 详细信息获取成功:', detailedResponse.data);
            
            // 关闭个人主页标签
            await chrome.tabs.remove(profileTab.id);
            //console.log('[User] 已关闭临时标签页');
            
            // 验证授权并添加授权信息
            const userInfoWithLicense = await verifyAndAddLicenseInfo(detailedResponse.data);
            
            // 显示详细信息并缓存（按窗口ID隔离）
            displayUserInfo(userInfoWithLicense);
            await cacheUserInfo(userInfoWithLicense, windowId);
            showToast('用户信息加载完成', 'success');
        } else {
            throw new Error('无法从个人主页提取信息');
        }
        
    } catch (error) {
        console.error('[User] 获取详细信息失败:', error);
        
        // 关闭标签页（如果存在）
        if (profileTab && profileTab.id) {
            try {
                await chrome.tabs.remove(profileTab.id);
            } catch (e) {
                //console.log('[User] 标签页已关闭或不存在');
            }
        }
        
        // 验证授权并添加授权信息
        const userInfoWithLicense = await verifyAndAddLicenseInfo(basicInfo);
        
        // 显示基本信息并缓存（按窗口ID隔离）
        displayUserInfo(userInfoWithLicense);
        await cacheUserInfo(userInfoWithLicense, windowId);
        showToast('获取详细信息失败，显示基本信息', 'warning');
    }
}

/**
 * 刷新用户信息（强制从页面获取）
 * @returns {Promise<void>}
 */
export async function refreshUserInfo() {
    //console.log('[User] 强制刷新用户信息...');
    showToast('正在刷新用户信息...', 'info');
    await getUserInfo(true);
}

