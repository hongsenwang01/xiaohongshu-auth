// 授权页面处理器
import { bindLicense } from '../services/license.js';
import { getCachedUserInfo, cacheUserInfo } from '../services/cache.js';
import { showToast } from '../ui/toast.js';
import { refreshUserInfo } from './user.js';
import { getAdminPanelUrl } from '../../shared/api.js';

/**
 * 显示授权页面
 */
export function showLicensePage() {
    const licensePage = document.getElementById('licensePage');
    const tabContainer = document.getElementById('tabContainer');
    const stageSelection = document.getElementById('stageSelection');
    
    if (licensePage) {
        licensePage.style.display = 'block';
        console.log('[License] 显示授权页面');
    }
    
    // 隐藏主内容区域（可能是 tabContainer 或 stageSelection）
    if (tabContainer) {
        tabContainer.style.display = 'none';
    }
    if (stageSelection) {
        stageSelection.style.display = 'none';
    }
}

/**
 * 隐藏授权页面
 */
export function hideLicensePage() {
    const licensePage = document.getElementById('licensePage');
    const tabContainer = document.getElementById('tabContainer');
    const stageSelection = document.getElementById('stageSelection');
    
    if (licensePage) {
        licensePage.style.display = 'none';
        console.log('[License] 隐藏授权页面');
    }
    
    // 显示主内容区域（可能是 tabContainer 或 stageSelection）
    if (tabContainer) {
        tabContainer.style.display = 'block';
    }
    if (stageSelection) {
        stageSelection.style.display = 'block';
    }
}

/**
 * 显示提示信息
 * @param {string} message - 提示消息
 * @param {string} type - 类型：success/error/info
 */
function showLicenseInfo(message, type = 'info') {
    const licenseInfo = document.getElementById('licenseInfo');
    const licenseInfoText = document.getElementById('licenseInfoText');
    
    if (!licenseInfo || !licenseInfoText) return;
    
    // 移除之前的状态类
    licenseInfo.classList.remove('success', 'error');
    
    // 添加新的状态类
    if (type === 'success') {
        licenseInfo.classList.add('success');
    } else if (type === 'error') {
        licenseInfo.classList.add('error');
    }
    
    licenseInfoText.textContent = message;
    licenseInfo.style.display = 'flex';
}

/**
 * 隐藏提示信息
 */
function hideLicenseInfo() {
    const licenseInfo = document.getElementById('licenseInfo');
    if (licenseInfo) {
        licenseInfo.style.display = 'none';
    }
}

/**
 * 设置绑定按钮加载状态
 * @param {boolean} loading - 是否加载中
 */
function setBindButtonLoading(loading) {
    const bindBtn = document.getElementById('licenseBindBtn');
    if (!bindBtn) return;
    
    if (loading) {
        bindBtn.classList.add('loading');
        bindBtn.disabled = true;
    } else {
        bindBtn.classList.remove('loading');
        bindBtn.disabled = false;
    }
}

/**
 * 处理授权码绑定
 */
export async function handleBindLicense() {
    try {
        const licenseCodeInput = document.getElementById('licenseCodeInput');
        
        if (!licenseCodeInput) {
            console.error('[License] 找不到授权码输入框');
            return;
        }
        
        const licenseCode = licenseCodeInput.value.trim();
        
        // 验证输入
        if (!licenseCode) {
            showLicenseInfo('请输入授权码', 'error');
            return;
        }
        
        // 获取当前账号信息
        const currentWindow = await chrome.windows.getCurrent();
        const windowId = currentWindow.id;
        const userInfo = await getCachedUserInfo(windowId);
        
        if (!userInfo || !userInfo.redId) {
            showLicenseInfo('无法获取账号信息，请刷新页面后重试', 'error');
            return;
        }
        
        console.log('[License] 开始绑定授权码...', { licenseCode, redId: userInfo.redId });
        
        // 显示加载状态
        setBindButtonLoading(true);
        hideLicenseInfo();
        
        // 调用绑定API
        const result = await bindLicense(licenseCode, userInfo.redId);
        
        // 恢复按钮状态
        setBindButtonLoading(false);
        
        if (result.success) {
            // 绑定成功
            console.log('[License] ✅ 绑定成功', result);
            
            // 显示成功信息
            const bindInfo = `绑定成功！已绑定 ${result.boundCount}/${result.maxBindings} 个账号`;
            showLicenseInfo(bindInfo, 'success');
            showToast('授权码绑定成功！', 'success');
            
            // 清空输入框
            licenseCodeInput.value = '';
            
            // 延迟2秒后刷新用户信息并关闭授权页面
            setTimeout(async () => {
                await refreshUserInfo();  // 刷新用户信息以更新授权状态
                hideLicensePage();
            }, 2000);
            
        } else {
            // 绑定失败
            showLicenseInfo(result.message, 'error');
            showToast(`绑定失败：${result.message}`, 'error');
        }
        
    } catch (error) {
        setBindButtonLoading(false);
        showLicenseInfo('绑定过程中出现异常，请稍后重试', 'error');
        showToast('绑定失败，请稍后重试', 'error');
    }
}

/**
 * 初始化授权页面事件
 */
export function initLicensePageEvents() {
    // 动态设置链接的href属性
    const adminUrl = getAdminPanelUrl();
    
    // 设置"获取授权码"链接
    const getLicenseLink = document.getElementById('getLicenseLink');
    if (getLicenseLink) {
        getLicenseLink.href = adminUrl;
    }
    
    // 设置"点击这里获取授权码"链接
    const contactAdminLink = document.getElementById('contactAdminLink');
    if (contactAdminLink) {
        contactAdminLink.href = adminUrl;
    }
    
    // 绑定按钮事件
    const bindBtn = document.getElementById('licenseBindBtn');
    if (bindBtn) {
        bindBtn.addEventListener('click', handleBindLicense);
    }
    
    // 返回按钮事件
    const backBtn = document.getElementById('licenseBackBtn');
    if (backBtn) {
        backBtn.addEventListener('click', hideLicensePage);
    }
    
    // 输入框回车事件
    const licenseCodeInput = document.getElementById('licenseCodeInput');
    if (licenseCodeInput) {
        licenseCodeInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                handleBindLicense();
            }
        });
    }
    
    // 用户头像tooltip中的"更换或绑定授权码"链接事件
    const bindLicenseLink = document.getElementById('bindLicenseLink');
    if (bindLicenseLink) {
        bindLicenseLink.addEventListener('click', async (e) => {
            e.preventDefault();
            
            // 获取当前用户信息
            const currentWindow = await chrome.windows.getCurrent();
            const windowId = currentWindow.id;
            const userInfo = await getCachedUserInfo(windowId);
            
            // 允许用户更换或绑定授权码
            showLicensePage();
            
            if (userInfo && userInfo.licenseValid && userInfo.licenseCode) {
                console.log('[License] 用户已有授权码，允许更换授权码');
            } else {
                console.log('[License] 用户无授权码，允许绑定授权码');
            }
        });
    }
    
    //console.log('[License] 授权页面事件已初始化');
}

