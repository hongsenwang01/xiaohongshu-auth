/**
 * 已关注用户列表控制器
 * 处理已关注用户列表的UI交互和管理
 * 按窗口ID隔离存储
 */

import { 
    getFollowedUsers, 
    clearFollowedUsers
} from '../services/followed-users.js';
import { showToast } from '../ui/toast.js';

// 存储当前窗口ID
let currentWindowId = null;

/**
 * 获取当前窗口ID
 * @returns {Promise<number|null>}
 */
async function getCurrentWindowId() {
    try {
        const window = await chrome.windows.getCurrent();
        return window.id;
    } catch (error) {
        console.error('[FollowedUsersController] 获取窗口ID失败:', error);
        return null;
    }
}

/**
 * 初始化已关注用户列表控制器（按窗口ID隔离）
 */
export async function initFollowedUsersController() {
    console.log('[FollowedUsersController] 初始化已关注用户列表控制器');
    
    // 获取当前窗口ID
    currentWindowId = await getCurrentWindowId();
    console.log('[FollowedUsersController] 当前窗口ID:', currentWindowId);
    
    // 绑定事件
    bindClearButton();
    
    // 加载并显示当前列表状态
    await loadFollowedUsersStatus();
}

/**
 * 绑定清除按钮事件
 */
function bindClearButton() {
    const clearBtn = document.getElementById('clearFollowedUsersBtn');
    if (!clearBtn) return;
    
    clearBtn.addEventListener('click', async () => {
        if (!confirm('确定要清除当前窗口的所有已关注用户吗？此操作不可恢复。')) {
            return;
        }
        
        try {
            console.log('[FollowedUsersController] 清除已关注用户列表', { windowId: currentWindowId });
            await clearFollowedUsers(currentWindowId);
            showToast('已关注用户列表已清除', 'success');
            
            // 刷新状态显示
            await loadFollowedUsersStatus();
        } catch (error) {
            console.error('[FollowedUsersController] 清除失败:', error);
            showToast(error.message || '清除失败', 'error');
        }
    });
}

/**
 * 加载并显示已关注用户列表状态（按窗口ID隔离）
 */
async function loadFollowedUsersStatus() {
    try {
        const users = await getFollowedUsers(currentWindowId);
        const count = users.length;
        
        console.log(`[FollowedUsersController] 当前已关注用户数: ${count}`, { windowId: currentWindowId });
        
        // 更新显示
        const infoDiv = document.getElementById('followedUsersInfo');
        const countSpan = document.getElementById('followedUsersCount');
        const clearBtn = document.getElementById('clearFollowedUsersBtn');
        
        if (count > 0) {
            if (infoDiv) infoDiv.style.display = 'flex';
            if (countSpan) countSpan.textContent = count;
            if (clearBtn) clearBtn.style.display = 'inline-block';
        } else {
            if (infoDiv) infoDiv.style.display = 'none';
            if (clearBtn) clearBtn.style.display = 'none';
        }
    } catch (error) {
        console.error('[FollowedUsersController] 加载状态失败:', error);
    }
}

/**
 * 刷新已关注用户列表状态（供外部调用）
 */
export async function refreshFollowedUsersStatus() {
    await loadFollowedUsersStatus();
}

