import { MESSAGE_TYPES } from '../../shared/constants.js';
import { showToast } from '../ui/toast.js';
import { getFilterConfig } from '../handlers/filter.js';

export const fetchController = {
    async handleStartFetchPosts() {
        try {
            const browseCountInput = document.getElementById('browseCount');
            const targetCount = parseInt(browseCountInput?.value, 10) || 50;

            console.log(`[Fetch] 📥 开始获取帖子，目标 ${targetCount} 个`);

            this.isFetchingPosts = true;
            // 缓存已检查过的用户是否在排除名单中
            this._excludedUserCache = new Map();
            this.fetchedPosts = [];

            await this.runFetchPosts(targetCount);
        } catch (error) {
            console.error('[Fetch] ❌ 获取失败:', error);
            this.isFetchingPosts = false;
            throw error;
        }
    },

    async runFetchPosts(targetCount) {
        try {
            const filterConfig = await getFilterConfig();
            
            // 改进日志输出，避免对象展开时的混乱
            console.log('[Fetch] 过滤配置详情:', {
                filterExclude: filterConfig.filterExclude,
                excludeListCount: filterConfig.excludeList?.length || 0,
                filterFocus: filterConfig.filterFocus,
                focusListCount: filterConfig.focusList?.length || 0,
                onlyFollowing: filterConfig.onlyFollowing
            });

            // 预处理重点关注名单
            let focusSet = null;
            if (filterConfig.filterFocus && Array.isArray(filterConfig.focusList) && filterConfig.focusList.length > 0) {
                focusSet = new Set(filterConfig.focusList.map(name => (name || '').toString().trim().toLowerCase()));
                console.log(`[Fetch] 已启用重点关注，名单 ${focusSet.size} 条`);
            }
            this._focusSet = focusSet; // 保存到实例，供后续使用

            if (filterConfig.onlyFollowing) {
                await this.runFetchPostsFromFollowedUsers(targetCount);
                return;
            }

            const tab = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tab[0] || !tab[0].url.includes('xiaohongshu.com')) {
                showToast('请在小红书页面使用此功能', 'error');
                this.handleStopFetchPosts();
                return;
            }

            const tabId = tab[0].id;
            let allPosts = [];
            let validCount = 0; // 有效帖子计数（满足过滤条件的）
            let scrollAttempts = 0;
            const maxScrollAttempts = 20;
            
            // 预处理排除名单（规范化）
            let excludeSet = null;
            if (filterConfig.filterExclude && Array.isArray(filterConfig.excludeList) && filterConfig.excludeList.length > 0) {
                excludeSet = new Set(filterConfig.excludeList.map(name => (name || '').toString().trim().toLowerCase()));
                console.log(`[Fetch] 已启用排除名单过滤，名单 ${excludeSet.size} 条`);
                // 输出排除名单详细内容（便于调试）
                console.log(`[Fetch] 排除名单详情:`, Array.from(excludeSet).slice(0, 10));
            }

            while (this.isFetchingPosts && validCount < targetCount && scrollAttempts < maxScrollAttempts) {
                let response;
                try {
                    response = await chrome.tabs.sendMessage(tabId, {
                        action: MESSAGE_TYPES.GET_POSTS
                    });
                } catch (error) {
                    console.error('[Fetch] 连接错误:', error);
                    if (
                        error.message.includes('Could not establish connection') ||
                        error.message.includes('Receiving end does not exist')
                    ) {
                        showToast('内容脚本未加载，正在刷新页面...', 'info');
                        await chrome.tabs.reload(tabId);
                        setTimeout(() => {
                            window.close();
                        }, 1000);
                        return;
                    }
                    throw error;
                }

                if (!response || !response.success) {
                    showToast('获取帖子失败', 'error');
                    break;
                }

                const currentPosts = response.data;
                const existingLinks = new Set(allPosts.map(p => p.link));
                const newPosts = currentPosts.filter(p => !existingLinks.has(p.link));

                if (newPosts.length > 0 || scrollAttempts === 0) {
                    const postsToCheck = newPosts.length > 0 ? newPosts : currentPosts;
                    
                    for (const post of postsToCheck) {
                        if (!this.isFetchingPosts || validCount >= targetCount) {
                            break;
                        }

                        // 检查是否已存在
                        if (allPosts.some(p => p.link === post.link)) {
                            continue;
                        }

                        const authorName = (post.author || '').toString().trim().toLowerCase();

                        // 情况4、7：如果开启了重点关注，只获取重点关注名单中的帖子
                        if (focusSet) {
                            if (!authorName || !focusSet.has(authorName)) {
                                // 不在重点关注名单中，跳过
                                continue;
                            }
                            // 在重点关注名单中，标记
                            post.isFocused = true;
                            console.log(`[Fetch] ⭐ 重点关注: ${post.title} (作者: ${post.author})`);
                        }

                        // 检查排除名单（优先级低于重点关注）
                        if (excludeSet) {
                            if (authorName && excludeSet.has(authorName)) {
                                console.log(`[Fetch] ⛔ 排除: ${post.title} (作者: ${post.author})`);
                                continue; // 跳过排除名单中的用户
                            }
                        }

                        // 通过所有过滤，添加到结果
                        allPosts.push(post);
                        validCount++;
                        console.log(`[Fetch] ✅ 第 ${validCount} 个有效帖子: ${post.title} (作者: ${post.author})`);
                    }
                } else {
                    console.log(`[Fetch] ⚠️ 第 ${scrollAttempts + 1} 次滚动后没有新增帖子`);
                }

                if (validCount >= targetCount) {
                    console.log(`[Fetch] 🎉 已达到目标数量 ${targetCount}`);
                    break;
                }

                if (newPosts.length === 0 && scrollAttempts > 0) {
                    if (scrollAttempts >= 3) {
                        console.log(`[Fetch] ⚠️ 连续多次没有新帖子，可能已到底部`);
                        showToast(`只获取到 ${validCount} 个有效帖子，可能已到底部`, 'warning');
                        break;
                    }
                }

                if (validCount < targetCount) {
                    scrollAttempts++;
                    console.log(`[Fetch] 📜 第 ${scrollAttempts} 次滚动加载更多...`);

                    try {
                        await chrome.tabs.sendMessage(tabId, {
                            action: 'scrollPage'
                        });
                    } catch (error) {
                        console.error('[Fetch] 滚动操作连接错误:', error);
                        if (
                            error.message.includes('Could not establish connection') ||
                            error.message.includes('Receiving end does not exist')
                        ) {
                            showToast('内容脚本未加载，正在刷新页面...', 'info');
                            await chrome.tabs.reload(tabId);
                            setTimeout(() => {
                                window.close();
                            }, 1000);
                            return;
                        }
                        throw error;
                    }

                    console.log(`[Fetch] ⏱️ 等待 3 秒让新帖子加载...`);
                    await this.sleep(3000);
                }
            }

            this.fetchedPosts = allPosts;

            console.log(`[Fetch] 🎉 获取完成！共获取 ${validCount} 个有效帖子，滚动 ${scrollAttempts} 次`);

            this.isFetchingPosts = false;
        } catch (error) {
            console.error('[Fetch] 获取帖子失败:', error);
            this.isFetchingPosts = false;
            throw error;
        }
    },

    async runFetchPostsFromFollowedUsers(targetCount) {
        try {
            console.log('[FetchFollowed] 🎯 开始从已关注用户获取帖子');
            showToast('开始检查已关注用户的帖子...', 'info');

            const [currentTab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!currentTab || !currentTab.url.includes('xiaohongshu.com')) {
                showToast('请在小红书页面使用此功能', 'error');
                this.handleStopFetchPosts();
                return;
            }

            const currentTabId = currentTab.id;
            let collectedPosts = [];
            let checkedCount = 0;
            let scrollAttempts = 0;
            const maxScrollAttempts = 20;

            // 如开启排除名单，准备集合（用户名/小红书号，均小写比较）
            let excludeSet = null;
            let focusSet = null;
            try {
                const fc = await getFilterConfig();
                if (fc && fc.filterExclude && Array.isArray(fc.excludeList) && fc.excludeList.length > 0) {
                    excludeSet = new Set(fc.excludeList.map(name => (name || '').toString().trim().toLowerCase()));
                    console.log(`[FetchFollowed] 排除名单启用，${excludeSet.size} 条`);
                }
                if (fc && fc.filterFocus && Array.isArray(fc.focusList) && fc.focusList.length > 0) {
                    focusSet = new Set(fc.focusList.map(name => (name || '').toString().trim().toLowerCase()));
                    console.log(`[FetchFollowed] 重点关注启用，${focusSet.size} 条`);
                }
            } catch {}

            while (this.isFetchingPosts && collectedPosts.length < targetCount && scrollAttempts < maxScrollAttempts) {
                let response;
                try {
                    response = await chrome.tabs.sendMessage(currentTabId, {
                        action: MESSAGE_TYPES.GET_POSTS
                    });
                } catch (error) {
                    console.error('[FetchFollowed] 连接错误:', error);
                    if (
                        error.message.includes('Could not establish connection') ||
                        error.message.includes('Receiving end does not exist')
                    ) {
                        showToast('内容脚本未加载，正在刷新页面...', 'info');
                        await chrome.tabs.reload(currentTabId);
                        setTimeout(() => window.close(), 1000);
                        return;
                    }
                    throw error;
                }

                if (!response || !response.success) {
                    showToast('获取帖子失败', 'error');
                    break;
                }

                const posts = response.data;
                console.log(`[FetchFollowed] 📖 当前页面共 ${posts.length} 个帖子`);

                for (const post of posts) {
                    if (!this.isFetchingPosts || collectedPosts.length >= targetCount) {
                        break;
                    }

                    const alreadyChecked = collectedPosts.some(p => p.link === post.link);
                    if (alreadyChecked) {
                        console.log(`[FetchFollowed] ⏭️ 跳过已检查的帖子: ${post.title}`);
                        continue;
                    }

                    checkedCount++;
                    console.log(`[FetchFollowed] 🔍 检查第 ${checkedCount} 个帖子: ${post.title} (作者: ${post.author})`);
                    showToast(`正在检查第 ${checkedCount} 个帖子 (${post.author})...`, 'info');

                    if (!post.userId) {
                        console.warn(`[FetchFollowed] ⚠️ 帖子没有用户ID: ${post.title}`);
                        continue;
                    }

                    const userProfileUrl = `https://www.xiaohongshu.com/user/profile/${post.userId}`;
                        console.log(`[FetchFollowed] 🔗 打开用户主页: ${userProfileUrl}`);

                        let userTab = null;
                        try {
                            userTab = await chrome.tabs.create({
                                url: userProfileUrl,
                                active: false
                            });

                            console.log(`[FetchFollowed] ⏱️ 等待页面加载...`);
                            await this.sleep(3000);

                            let followCheckResponse;
                            try {
                                followCheckResponse = await chrome.tabs.sendMessage(userTab.id, {
                                    action: MESSAGE_TYPES.CHECK_USER_FOLLOWED
                                });
                            } catch (error) {
                                console.error('[FetchFollowed] 检查关注状态失败:', error);
                                if (userTab) {
                                    await chrome.tabs.remove(userTab.id);
                                }
                                continue;
                            }

                            if (followCheckResponse && followCheckResponse.success) {
                                const { followed, buttonFound } = followCheckResponse.data;

                                if (!buttonFound) {
                                    console.warn('[FetchFollowed] ⚠️ 未找到关注按钮');
                            } else if (followed) {
                                // 如果启用排除名单或重点关注，在同一个标签页中同时获取用户信息并检查
                                let shouldCollect = true;
                                let isFocused = false;
                                
                                if ((excludeSet && excludeSet.size > 0) || (focusSet && focusSet.size > 0)) {
                                    try {
                                        // 直接在当前已打开的标签页获取用户信息
                                        const userInfoResp = await chrome.tabs.sendMessage(userTab.id, { 
                                            action: MESSAGE_TYPES.GET_USER_INFO 
                                        });
                                        
                                        if (userInfoResp && userInfoResp.success) {
                                            const { username, redId } = userInfoResp.data || {};
                                            const nameKey = (username || '').toString().trim().toLowerCase();
                                            const redIdKey = (redId || '').toString().trim().toLowerCase();
                                            
                                            // 情况6、8：如果开启了重点关注，只收集重点关注名单中的用户
                                            if (focusSet) {
                                                const inFocus = (!!nameKey && focusSet.has(nameKey)) || (!!redIdKey && focusSet.has(redIdKey));
                                                if (!inFocus) {
                                                    console.log(`[FetchFollowed] ⚠️ 已关注但不在重点关注名单: ${post.title} (作者: ${post.author})`);
                                                    shouldCollect = false;
                                                } else {
                                                    isFocused = true;
                                                    console.log(`[FetchFollowed] ⭐ 重点关注: ${post.title} (作者: ${post.author})`);
                                                }
                                            }
                                            
                                            // 检查排除名单（在重点关注检查之后）
                                            if (excludeSet && shouldCollect) {
                                                const inExcluded = (!!nameKey && excludeSet.has(nameKey)) || (!!redIdKey && excludeSet.has(redIdKey));
                                                if (inExcluded) {
                                                    console.log(`[FetchFollowed] ⛔ 已关注但在排除名单: ${post.title} (作者: ${post.author})`);
                                                    shouldCollect = false;
                                                }
                                            }
                                        }
                                    } catch (e) {
                                        console.warn('[FetchFollowed] 检查名单失败:', e);
                                    }
                                }
                                
                                if (shouldCollect) {
                                    if (isFocused) {
                                        post.isFocused = true;
                                    }
                                    console.log(`[FetchFollowed] ✅ 已关注，收集帖子: ${post.title}`);
                                    collectedPosts.push(post);
                                    showToast(`已收集 ${collectedPosts.length}/${targetCount} 个帖子`, 'success');
                                }
                            } else {
                                console.log(`[FetchFollowed] ❌ 未关注，跳过: ${post.title}`);
                            }
                            }
                    } catch (error) {
                        console.error('[FetchFollowed] 处理用户主页失败:', error);
                    } finally {
                        if (userTab) {
                            try {
                                await chrome.tabs.remove(userTab.id);
                                console.log('[FetchFollowed] 🚪 已关闭用户主页标签');
                            } catch (error) {
                                console.error('[FetchFollowed] 关闭标签页失败:', error);
                            }
                        }

                        console.log('[FetchFollowed] ⏱️ 等待2秒后继续...');
                        await this.sleep(2000);
                    }
                }

                if (this.isFetchingPosts && collectedPosts.length < targetCount) {
                    scrollAttempts++;
                    console.log(`[FetchFollowed] 📜 第 ${scrollAttempts} 次滚动加载更多...`);

                    try {
                        await chrome.tabs.sendMessage(currentTabId, { action: 'scrollPage' });
                    } catch (error) {
                        console.error('[FetchFollowed] 滚动失败:', error);
                        break;
                    }

                    console.log('[FetchFollowed] ⏱️ 等待3秒让新帖子加载...');
                    await this.sleep(3000);
                }

                if (scrollAttempts >= 5 && collectedPosts.length === 0) {
                    console.log('[FetchFollowed] ⚠️ 多次滚动后仍未找到已关注用户的帖子');
                    showToast('未找到已关注用户的帖子，可能已到底部', 'warning');
                    break;
                }
            }

            this.fetchedPosts = collectedPosts;

            console.log(`[FetchFollowed] 🎉 获取完成！共收集 ${this.fetchedPosts.length} 个已关注用户的帖子`);

            this.isFetchingPosts = false;
        } catch (error) {
            console.error('[FetchFollowed] 获取失败:', error);
            this.isFetchingPosts = false;
            throw error;
        }
    },

    handleStopFetchPosts() {
        console.log('[Fetch] 🛑 停止获取');
        this.isFetchingPosts = false;
    },

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
};

/**
 * 内部方法：根据用户ID检测是否在排除名单中
 * - 打开该用户主页，读取用户名/小红书号，与排除集合对比
 * - 结果缓存于 this._excludedUserCache 以减少重复访问
 */
fetchController._isUserExcludedById = async function(userId, excludeSet) {
    try {
        if (!userId || !excludeSet || excludeSet.size === 0) return false;

        if (!this._excludedUserCache) this._excludedUserCache = new Map();
        if (this._excludedUserCache.has(userId)) {
            return this._excludedUserCache.get(userId);
        }

        const userProfileUrl = `https://www.xiaohongshu.com/user/profile/${userId}`;
        let userTab = null;
        try {
            userTab = await chrome.tabs.create({ url: userProfileUrl, active: false });
            // 等待页面加载
            await this.sleep(3000);
            const infoResp = await chrome.tabs.sendMessage(userTab.id, { action: MESSAGE_TYPES.GET_USER_INFO });
            if (!infoResp || !infoResp.success) {
                this._excludedUserCache.set(userId, false);
                return false;
            }
            const { username, redId } = infoResp.data || {};
            const nameKey = (username || '').toString().trim().toLowerCase();
            const redIdKey = (redId || '').toString().trim().toLowerCase();
            const inExcluded = (!!nameKey && excludeSet.has(nameKey)) || (!!redIdKey && excludeSet.has(redIdKey));
            this._excludedUserCache.set(userId, inExcluded);
            return inExcluded;
        } catch (e) {
            console.warn('[Fetch] 检查排除名单失败:', e);
            this._excludedUserCache.set(userId, false);
            return false;
        } finally {
            if (userTab) {
                try { await chrome.tabs.remove(userTab.id); } catch {}
            }
        }
    } catch (err) {
        console.error('[Fetch] _isUserExcludedById 异常:', err);
        return false;
    }
};
