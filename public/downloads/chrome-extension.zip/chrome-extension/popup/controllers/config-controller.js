import { DEFAULT_CONFIG } from '../../shared/constants.js';
import { 
    saveDurationConfig, 
    getDurationConfig, 
    saveBrowseCountConfig, 
    getBrowseCountConfig, 
    saveToggleStates, 
    getToggleStates 
} from '../services/config.js';
import { 
    cacheCommentContents, 
    getCachedCommentContents 
} from '../services/cache.js';

export const configController = {
    async restoreDurationConfig() {
        try {
            const config = await getDurationConfig();
            if (!config) return;

            const durationMin = document.getElementById('durationMin');
            const durationMax = document.getElementById('durationMax');

            if (durationMin && config.min) {
                durationMin.value = config.min;
            }
            if (durationMax && config.max) {
                durationMax.value = config.max;
            }
            console.log('[Config] 已恢复浏览时长配置:', config);
        } catch (error) {
            console.error('[Config] 恢复浏览时长配置失败:', error);
        }
    },

    async restoreBrowseCountConfig() {
        try {
            const count = await getBrowseCountConfig();
            if (!count) return;

            const browseCount = document.getElementById('browseCount');
            if (browseCount) {
                browseCount.value = count;
            }
            console.log('[Config] 已恢复浏览数量配置:', count);
        } catch (error) {
            console.error('[Config] 恢复浏览数量配置失败:', error);
        }
    },

    bindDurationInputs() {
        const durationMin = document.getElementById('durationMin');
        const durationMax = document.getElementById('durationMax');

        if (durationMin) {
            durationMin.addEventListener('change', () => {
                let min = parseInt(durationMin.value, 10) || 10;
                let max = parseInt(durationMax?.value, 10) || 30;
                
                // 最小值不能低于5秒
                if (min < 5) {
                    min = 5;
                    durationMin.value = min;
                }
                
                // 限制最小值最大为60秒
                if (min > 60) {
                    min = 60;
                    durationMin.value = min;
                }
                
                // 确保最大值大于最小值
                if (max <= min) {
                    max = min + 5;
                    durationMax.value = max;
                }
                
                saveDurationConfig(min, max);
            });
        }

        if (durationMax) {
            durationMax.addEventListener('change', () => {
                let min = parseInt(durationMin?.value, 10) || 10;
                let max = parseInt(durationMax.value, 10) || 30;
                
                // 最小值不能低于5秒
                if (min < 5) {
                    min = 5;
                    durationMin.value = min;
                }
                
                // 限制最大值最大为60秒
                if (max > 60) {
                    max = 60;
                    durationMax.value = max;
                }
                
                // 确保最大值大于最小值
                if (max <= min) {
                    max = min + 5;
                    durationMax.value = max;
                }
                
                saveDurationConfig(min, max);
            });
        }

        const browseCount = document.getElementById('browseCount');
        if (!browseCount) return;

        browseCount.addEventListener('change', () => {
            const count = parseInt(browseCount.value, 10) || DEFAULT_CONFIG.DEFAULT_BROWSE_COUNT;
            const validCount = Math.max(
                DEFAULT_CONFIG.MIN_BROWSE_COUNT,
                Math.min(DEFAULT_CONFIG.MAX_BROWSE_COUNT, count)
            );
            browseCount.value = validCount;
            saveBrowseCountConfig(validCount);
        });
    },

    async restoreToggleStates() {
        try {
            const toggleStates = await getToggleStates();
            if (!toggleStates) return;

            const autoLikeToggle = document.getElementById('autoLikeToggle');
            const autoCollectToggle = document.getElementById('autoCollectToggle');
            const autoFollowToggle = document.getElementById('autoFollowToggle');
            const autoCommentToggle = document.getElementById('autoCommentToggle');
            const commentContentWrapper = document.getElementById('commentContentWrapper');

            if (autoLikeToggle && toggleStates.autoLike !== undefined) {
                autoLikeToggle.checked = toggleStates.autoLike;
            }
            if (autoCollectToggle && toggleStates.autoCollect !== undefined) {
                autoCollectToggle.checked = toggleStates.autoCollect;
            }
            if (autoFollowToggle && toggleStates.autoFollow !== undefined) {
                autoFollowToggle.checked = toggleStates.autoFollow;
            }
            if (autoCommentToggle && toggleStates.autoComment !== undefined) {
                autoCommentToggle.checked = toggleStates.autoComment;
                if (commentContentWrapper) {
                    commentContentWrapper.classList.toggle('expanded', toggleStates.autoComment);
                }
            }

            console.log('[Config] 已恢复开关状态:', toggleStates);
        } catch (error) {
            console.error('[Config] 恢复开关状态失败:', error);
        }
    },

    async saveToggleStatesInternal() {
        try {
            const autoLikeToggle = document.getElementById('autoLikeToggle');
            const autoCollectToggle = document.getElementById('autoCollectToggle');
            const autoFollowToggle = document.getElementById('autoFollowToggle');
            const autoCommentToggle = document.getElementById('autoCommentToggle');

            const toggleStates = {
                autoLike: autoLikeToggle ? autoLikeToggle.checked : false,
                autoCollect: autoCollectToggle ? autoCollectToggle.checked : false,
                autoFollow: autoFollowToggle ? autoFollowToggle.checked : false,
                autoComment: autoCommentToggle ? autoCommentToggle.checked : false
            };

            await saveToggleStates(toggleStates);
            console.log('[Config] 已保存开关状态:', toggleStates);
        } catch (error) {
            console.error('[Config] 保存开关状态失败:', error);
        }
    },

    bindToggleEvents() {
        const autoLikeToggle = document.getElementById('autoLikeToggle');
        const autoCollectToggle = document.getElementById('autoCollectToggle');
        const autoFollowToggle = document.getElementById('autoFollowToggle');
        const autoCommentToggle = document.getElementById('autoCommentToggle');
        const commentContentWrapper = document.getElementById('commentContentWrapper');

        if (autoLikeToggle) {
            autoLikeToggle.addEventListener('change', () => this.saveToggleStatesInternal());
        }
        if (autoCollectToggle) {
            autoCollectToggle.addEventListener('change', () => this.saveToggleStatesInternal());
        }
        if (autoFollowToggle) {
            autoFollowToggle.addEventListener('change', () => this.saveToggleStatesInternal());
        }
        if (autoCommentToggle) {
            autoCommentToggle.addEventListener('change', () => {
                if (commentContentWrapper) {
                    commentContentWrapper.classList.toggle('expanded', autoCommentToggle.checked);
                }
                this.saveToggleStatesInternal();
            });
        }

        this.bindCommentInputs();
    },

    bindCommentInputs() {
        const commentInput1 = document.getElementById('commentInput1');
        const commentInput2 = document.getElementById('commentInput2');
        const commentInput3 = document.getElementById('commentInput3');

        let saveTimeout;
        const saveComments = () => {
            clearTimeout(saveTimeout);
            saveTimeout = setTimeout(() => {
                this.saveCommentContents();
            }, 500);
        };

        if (commentInput1) {
            commentInput1.addEventListener('input', saveComments);
        }
        if (commentInput2) {
            commentInput2.addEventListener('input', saveComments);
        }
        if (commentInput3) {
            commentInput3.addEventListener('input', saveComments);
        }
    },

    async saveCommentContents() {
        try {
            const commentInput1 = document.getElementById('commentInput1');
            const commentInput2 = document.getElementById('commentInput2');
            const commentInput3 = document.getElementById('commentInput3');

            const comments = [
                commentInput1?.value?.trim() || '',
                commentInput2?.value?.trim() || '',
                commentInput3?.value?.trim() || ''
            ];

            const currentWindow = await chrome.windows.getCurrent();
            const windowId = currentWindow.id;

            await cacheCommentContents(comments, windowId);
            console.log('[Comment] ✅ 评论内容已保存', { windowId, comments });
        } catch (error) {
            console.error('[Comment] ❌ 保存评论内容失败:', error);
        }
    },

    async restoreCommentContents() {
        try {
            const currentWindow = await chrome.windows.getCurrent();
            const windowId = currentWindow.id;

            const comments = await getCachedCommentContents(windowId);
            const commentInput1 = document.getElementById('commentInput1');
            const commentInput2 = document.getElementById('commentInput2');
            const commentInput3 = document.getElementById('commentInput3');

            if (commentInput1 && comments[0]) {
                commentInput1.value = comments[0];
            }
            if (commentInput2 && comments[1]) {
                commentInput2.value = comments[1];
            }
            if (commentInput3 && comments[2]) {
                commentInput3.value = comments[2];
            }

            console.log('[Comment] ✅ 评论内容已恢复', { windowId, count: comments.length });
        } catch (error) {
            console.error('[Comment] ❌ 恢复评论内容失败:', error);
        }
    },

    getAutomationConfig() {
        const autoLikeToggle = document.getElementById('autoLikeToggle');
        const autoCollectToggle = document.getElementById('autoCollectToggle');
        const autoFollowToggle = document.getElementById('autoFollowToggle');
        const autoCommentToggle = document.getElementById('autoCommentToggle');
        const durationMin = document.getElementById('durationMin');
        const durationMax = document.getElementById('durationMax');

        const commentInput1 = document.getElementById('commentInput1');
        const commentInput2 = document.getElementById('commentInput2');
        const commentInput3 = document.getElementById('commentInput3');

        const commentContents = [
            commentInput1?.value?.trim() || '',
            commentInput2?.value?.trim() || '',
            commentInput3?.value?.trim() || ''
        ].filter(content => content.length > 0);

        let minDuration = parseInt(durationMin?.value, 10) || 10;
        let maxDuration = parseInt(durationMax?.value, 10) || 30;

        minDuration = Math.max(5, Math.min(60, minDuration));
        maxDuration = Math.max(5, Math.min(60, maxDuration));

        if (minDuration > maxDuration) {
            [minDuration, maxDuration] = [maxDuration, minDuration];
        }

        return {
            autoLike: autoLikeToggle ? autoLikeToggle.checked : false,
            autoCollect: autoCollectToggle ? autoCollectToggle.checked : false,
            autoFollow: autoFollowToggle ? autoFollowToggle.checked : false,
            autoComment: autoCommentToggle ? autoCommentToggle.checked : false,
            commentContents,
            durationMin: minDuration,
            durationMax: maxDuration
        };
    }
};
