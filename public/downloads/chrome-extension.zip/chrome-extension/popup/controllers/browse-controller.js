import { showToast } from '../ui/toast.js';
import { startBrowseTask, stopBrowseTask } from '../services/state.js';
import { getCachedUserInfo } from '../services/cache.js';
import { showLicensePage } from '../handlers/license.js';
import { refreshUserInfo } from '../handlers/user.js';

export const browseController = {
    async handleStartBrowse() {
        try {
            if (!Array.isArray(this.fetchedPosts) || this.fetchedPosts.length === 0) {
                showToast('请先在"数量设置"页签获取帖子', 'error');
                this.switchTab('count');
                return;
            }

            console.log(`[Start Browse] 开始执行，共 ${this.fetchedPosts.length} 个帖子`);

            const currentWindow = await chrome.windows.getCurrent();
            const windowId = currentWindow.id;
            const userInfo = await getCachedUserInfo(windowId);

            if (!userInfo) {
                showToast('无法获取账号信息，请刷新后重试', 'error');
                return;
            }

            if (!userInfo.licenseValid) {
                console.error('[License] 授权验证失败: 该账号未授权或授权已过期');
                showToast('该账号未授权，请绑定授权码', 'error');
                showLicensePage();
                return;
            }

            const config = this.getAutomationConfig();
            console.log('当前自动化配置:', config);

            if (!config.autoLike && !config.autoCollect && !config.autoFollow && !config.autoComment) {
                showToast('请至少开启一个自动化功能', 'error');
                return;
            }

            if (config.autoComment && (!config.commentContents || config.commentContents.length === 0)) {
                showToast('请至少输入一条评论内容', 'error');
                this.switchTab('automation');
                return;
            }

            this.posts = this.fetchedPosts;

            try {
                const tab = await chrome.tabs.query({ active: true, currentWindow: true });
                if (tab[0]) {
                    await chrome.tabs.sendMessage(tab[0].id, { action: 'ping' });
                }
            } catch (error) {
                console.error('[Start Browse] 页面连接检查失败:', error);
                if (
                    error.message.includes('Could not establish connection') ||
                    error.message.includes('Receiving end does not exist')
                ) {
                    showToast('内容脚本未加载，正在刷新页面...', 'info');
                    const tab = await chrome.tabs.query({ active: true, currentWindow: true });
                    if (tab[0]) {
                        await chrome.tabs.reload(tab[0].id);
                        setTimeout(() => window.close(), 1000);
                    }
                    return;
                }
                throw error;
            }

            const result = await startBrowseTask(this.posts, config);

            if (result.success) {
                this.setButtonState('browsing');

                const enabledFeatures = [];
                if (config.autoLike) enabledFeatures.push('点赞');
                if (config.autoCollect) enabledFeatures.push('收藏');
                if (config.autoComment) enabledFeatures.push('评论');
                showToast(`开始自动执行 ${this.posts.length} 个帖子（${enabledFeatures.join('、')}）`, 'success');
            } else {
                this.setButtonState('idle');
            }
        } catch (error) {
            console.error('开始执行失败:', error);
            showToast('开始执行失败', 'error');
            this.setButtonState('idle');
        }
    },

    async handleStopBrowse() {
        try {
            const success = await stopBrowseTask();
            if (success) {
                this.setButtonState('idle');
                console.log('已发送停止命令');
            }
        } catch (error) {
            console.error('停止浏览失败:', error);
        }
    },

    setButtonState(state) {
        const startBtn = document.getElementById('startBrowseBtn');
        const stopBrowseBtn = document.getElementById('stopBrowseBtn');

        if (!startBtn || !stopBrowseBtn) {
            console.warn('⚠️ 按钮元素未找到');
            return;
        }

        startBtn.style.display = 'none';
        stopBrowseBtn.style.display = 'none';

        switch (state) {
            case 'idle':
                startBtn.style.display = 'flex';
                break;
            case 'browsing':
                stopBrowseBtn.style.display = 'flex';
                break;
            default:
                startBtn.style.display = 'flex';
                console.warn('⚠️ 未知状态，显示默认按钮');
        }
    },

    toggleBrowseButtons(isRunning) {
        this.setButtonState(isRunning ? 'browsing' : 'idle');
    },

    async handleRefreshUser() {
        await refreshUserInfo();
    }
};
