import { showToast } from '../ui/toast.js';
import { startBrowseTask, stopBrowseTask } from '../services/state.js';
import { getCachedUserInfo } from '../services/cache.js';
import { showLicensePage } from '../handlers/license.js';
import { refreshUserInfo } from '../handlers/user.js';

export const browseController = {
    async handleStartBrowse() {
        try {
            // 重置停止标志
            this.shouldStopExecution = false;
            
            // 第一步：检查授权
            console.log('[Start Execute] 步骤1: 检查授权');
            const currentWindow = await chrome.windows.getCurrent();
            const windowId = currentWindow.id;
            const userInfo = await getCachedUserInfo(windowId);

            if (!userInfo) {
                showToast('无法获取账号信息，请刷新后重试', 'error');
                return;
            }

            if (!userInfo.licenseValid) {
                console.error('[License] 授权验证失败: 该账号未授权或授权已过期');
                showToast('该账号未授权，请绑定授权码', 'error');
                showLicensePage();
                return;
            }

            // 第二步：验证自动化配置
            console.log('[Start Execute] 步骤2: 验证自动化配置');
            const config = this.getAutomationConfig();
            console.log('当前自动化配置:', config);

            if (!config.autoLike && !config.autoCollect && !config.autoFollow && !config.autoComment) {
                showToast('请至少开启一个自动化功能', 'error');
                return;
            }

            if (config.autoComment && (!config.commentContents || config.commentContents.length === 0)) {
                showToast('请至少输入一条评论内容', 'error');
                return;
            }

            // 第三步：获取帖子
            console.log('[Start Execute] 步骤3: 开始获取帖子');
            showToast('正在获取帖子...', 'info');
            
            // 设置按钮为获取中状态
            this.setButtonState('browsing');
            
            // 调用获取帖子的逻辑
            await this.handleStartFetchPosts();
            
            // 检查是否在获取过程中被停止
            if (this.shouldStopExecution) {
                console.log('[Start Execute] 用户在获取阶段停止了执行');
                showToast('已停止执行', 'info');
                this.setButtonState('idle');
                return;
            }
            
            // 检查是否成功获取到帖子
            if (!Array.isArray(this.fetchedPosts) || this.fetchedPosts.length === 0) {
                console.error('[Start Execute] 获取帖子失败或没有帖子');
                showToast('获取帖子失败', 'error');
                this.setButtonState('idle');
                return;
            }

            console.log(`[Start Execute] 步骤4: 开始执行，共 ${this.fetchedPosts.length} 个帖子`);
            
            this.posts = this.fetchedPosts;

            try {
                const tab = await chrome.tabs.query({ active: true, currentWindow: true });
                if (tab[0]) {
                    await chrome.tabs.sendMessage(tab[0].id, { action: 'ping' });
                }
            } catch (error) {
                console.error('[Start Browse] 页面连接检查失败:', error);
                if (
                    error.message.includes('Could not establish connection') ||
                    error.message.includes('Receiving end does not exist')
                ) {
                    showToast('内容脚本未加载，正在刷新页面...', 'info');
                    const tab = await chrome.tabs.query({ active: true, currentWindow: true });
                    if (tab[0]) {
                        await chrome.tabs.reload(tab[0].id);
                        setTimeout(() => window.close(), 1000);
                    }
                    return;
                }
                throw error;
            }

            const result = await startBrowseTask(this.posts, config);

            if (result.success) {
                this.setButtonState('browsing');
                // 打开执行预览页面，展示配置与实时进度
                try {
                    const url = chrome.runtime.getURL('execution-preview.html');
                    window.location.href = url + (result.taskId ? `?taskId=${encodeURIComponent(result.taskId)}` : '');
                } catch (e) {
                    console.warn('打开执行预览页面失败:', e);
                }

                const enabledFeatures = [];
                if (config.autoLike) enabledFeatures.push('点赞');
                if (config.autoCollect) enabledFeatures.push('收藏');
                if (config.autoFollow) enabledFeatures.push('关注');
                if (config.autoComment) enabledFeatures.push('评论');
                showToast(`开始自动执行 ${this.posts.length} 个帖子（${enabledFeatures.join('、')}）`, 'success');
            } else {
                this.setButtonState('idle');
            }
        } catch (error) {
            console.error('开始执行失败:', error);
            showToast('开始执行失败', 'error');
            this.setButtonState('idle');
        }
    },

    async handleStopBrowse() {
        try {
            // 设置停止标志，阻止后续所有操作
            this.shouldStopExecution = true;
            
            // 如果正在获取帖子，先停止获取
            if (this.isFetchingPosts) {
                this.handleStopFetchPosts();
            }
            
            const success = await stopBrowseTask();
            if (success) {
                this.setButtonState('idle');
                showToast('已停止执行', 'info');
                console.log('已发送停止命令');
            }
        } catch (error) {
            console.error('停止浏览失败:', error);
            this.setButtonState('idle');
        }
    },

    setButtonState(state) {
        const startBtn = document.getElementById('startBrowseBtn');
        const stopBrowseBtn = document.getElementById('stopBrowseBtn');

        if (!startBtn || !stopBrowseBtn) {
            console.warn('⚠️ 按钮元素未找到');
            return;
        }

        startBtn.style.display = 'none';
        stopBrowseBtn.style.display = 'none';

        switch (state) {
            case 'idle':
                startBtn.style.display = 'flex';
                break;
            case 'browsing':
                stopBrowseBtn.style.display = 'flex';
                break;
            default:
                startBtn.style.display = 'flex';
                console.warn('⚠️ 未知状态，显示默认按钮');
        }
    },

    toggleBrowseButtons(isRunning) {
        this.setButtonState(isRunning ? 'browsing' : 'idle');
    },

    async handleRefreshUser() {
        await refreshUserInfo();
    }
};
