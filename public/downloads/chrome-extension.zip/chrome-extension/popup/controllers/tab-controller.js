import { saveCollapseStates, getCollapseStates } from '../services/config.js';

export const tabController = {
    initTabState() {
        this.switchTab('count');
    },

    bindTabEvents() {
        const tabBtns = document.querySelectorAll('.tab-btn');
        tabBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const targetTab = btn.getAttribute('data-tab');
                this.switchTab(targetTab);
            });
        });
    },

    switchTab(tabName) {
        const tabBtns = document.querySelectorAll('.tab-btn');
        tabBtns.forEach(btn => {
            btn.classList.toggle('active', btn.getAttribute('data-tab') === tabName);
        });

        const tabPanels = document.querySelectorAll('.tab-panel');
        tabPanels.forEach(panel => {
            panel.classList.toggle('active', panel.id === `${tabName}Panel`);
        });
    },

    bindHelpTooltip() {
        const helpIcon = document.getElementById('durationHelpIcon');
        if (helpIcon) {
            const tooltip = helpIcon.querySelector('.help-tooltip');
            if (tooltip) {
                helpIcon.addEventListener('mouseenter', () => {
                    const rect = helpIcon.getBoundingClientRect();
                    tooltip.style.left = `${rect.right + 5}px`;
                    tooltip.style.top = `${rect.top - 10}px`;
                });
            }
        }

        const countHelpIcon = document.getElementById('countHelpIcon');
        if (!countHelpIcon) return;

        const countTooltip = countHelpIcon.querySelector('.help-tooltip');
        if (!countTooltip) return;

        countHelpIcon.addEventListener('mouseenter', () => {
            const rect = countHelpIcon.getBoundingClientRect();
            countTooltip.style.left = `${rect.right + 5}px`;
            countTooltip.style.top = `${rect.top - 10}px`;
        });
    },

    bindCollapsibleHeaders() {
        const headers = document.querySelectorAll('.collapsible-header');
        headers.forEach(header => {
            header.addEventListener('click', () => {
                const section = header.parentElement;
                section.classList.toggle('collapsed');
                
                // 保存折叠状态
                this.saveCurrentCollapseStates();
            });
        });
    },

    async saveCurrentCollapseStates() {
        try {
            const collapseStates = {
                excel: document.querySelector('.excel-upload-section')?.classList.contains('collapsed') || false,
                filter: document.querySelector('.filter-options-section')?.classList.contains('collapsed') || false,
                automation: document.querySelector('.automation-options-section')?.classList.contains('collapsed') || false
            };
            
            await saveCollapseStates(collapseStates);
        } catch (error) {
            console.error('[TabController] 保存折叠状态失败:', error);
        }
    },

    async restoreCollapseStates() {
        try {
            const collapseStates = await getCollapseStates();
            
            if (!collapseStates) {
                console.log('[TabController] 没有保存的折叠状态');
                return;
            }

            if (collapseStates.excel) {
                const excelSection = document.querySelector('.excel-upload-section');
                if (excelSection) {
                    excelSection.classList.add('collapsed');
                }
            }

            if (collapseStates.filter) {
                const filterSection = document.querySelector('.filter-options-section');
                if (filterSection) {
                    filterSection.classList.add('collapsed');
                }
            }

            if (collapseStates.automation) {
                const automationSection = document.querySelector('.automation-options-section');
                if (automationSection) {
                    automationSection.classList.add('collapsed');
                }
            }

            console.log('[TabController] ✅ 已恢复折叠状态:', collapseStates);
        } catch (error) {
            console.error('[TabController] 恢复折叠状态失败:', error);
        }
    }
};
