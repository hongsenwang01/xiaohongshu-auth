import { showToast } from '../ui/toast.js';

export const tabController = {
    initTabState() {
        this.switchTab('count');
        this.updateAutomationTabState();
    },

    updateAutomationTabState() {
        const automationTab = document.getElementById('automationTab');
        if (!automationTab) return;

        const hasPosts = Array.isArray(this.fetchedPosts) && this.fetchedPosts.length > 0;
        automationTab.disabled = !hasPosts;
    },

    bindTabEvents() {
        const tabBtns = document.querySelectorAll('.tab-btn');
        tabBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                if (btn.disabled) {
                    if (btn.getAttribute('data-tab') === 'automation') {
                        showToast('请先在"数量设置"页签获取帖子', 'info');
                    }
                    return;
                }
                const targetTab = btn.getAttribute('data-tab');
                this.switchTab(targetTab);
            });
        });
    },

    switchTab(tabName) {
        const tabBtns = document.querySelectorAll('.tab-btn');
        tabBtns.forEach(btn => {
            btn.classList.toggle('active', btn.getAttribute('data-tab') === tabName);
        });

        const tabPanels = document.querySelectorAll('.tab-panel');
        tabPanels.forEach(panel => {
            panel.classList.toggle('active', panel.id === `${tabName}Panel`);
        });

        if (tabName === 'automation') {
            this.updatePostsReadyStatus();
        }
    },

    bindHelpTooltip() {
        const helpIcon = document.getElementById('durationHelpIcon');
        if (helpIcon) {
            const tooltip = helpIcon.querySelector('.help-tooltip');
            if (tooltip) {
                helpIcon.addEventListener('mouseenter', () => {
                    const rect = helpIcon.getBoundingClientRect();
                    tooltip.style.left = `${rect.right + 5}px`;
                    tooltip.style.top = `${rect.top - 10}px`;
                });
            }
        }

        const countHelpIcon = document.getElementById('countHelpIcon');
        if (!countHelpIcon) return;

        const countTooltip = countHelpIcon.querySelector('.help-tooltip');
        if (!countTooltip) return;

        countHelpIcon.addEventListener('mouseenter', () => {
            const rect = countHelpIcon.getBoundingClientRect();
            countTooltip.style.left = `${rect.right + 5}px`;
            countTooltip.style.top = `${rect.top - 10}px`;
        });
    },

    updatePostsReadyStatus() {
        const postsReadyStatus = document.getElementById('postsReadyStatus');
        const postsReadyText = document.getElementById('postsReadyText');
        if (!postsReadyStatus || !postsReadyText) return;

        if (Array.isArray(this.fetchedPosts) && this.fetchedPosts.length > 0) {
            postsReadyStatus.style.display = 'block';
            postsReadyText.textContent = `已准备 ${this.fetchedPosts.length} 个帖子，可以开始执行`;
        } else {
            postsReadyStatus.style.display = 'none';
        }
    }
};
