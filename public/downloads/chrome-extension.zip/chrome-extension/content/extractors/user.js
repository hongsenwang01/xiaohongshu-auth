// 用户信息提取模块
import { SELECTORS } from '../../shared/constants.js';

/**
 * 提取用户信息（根据当前页面类型）
 * @returns {Object}
 */
export function extractUserInfo() {
    //console.log('开始提取用户信息...');
    
    try {
        // 检查是否在个人主页
        const isUserPage = window.location.pathname.startsWith('/user/profile/');
        
        if (isUserPage) {
            //console.log('当前在个人主页，提取详细信息...');
            return extractUserInfoFromProfilePage();
        } else {
            //console.log('不在个人主页，从侧边栏获取基本信息...');
            return extractUserInfoFromSidebar();
        }
        
    } catch (error) {
        console.error('❌ 提取用户信息失败:', error);
        return getDefaultUserInfo();
    }
}

/**
 * 从侧边栏获取基本用户信息
 * @returns {Object}
 */
export function extractUserInfoFromSidebar() {
    //console.log('从侧边栏提取用户信息...');
    
    try {
        // 查找侧边栏的用户组件
        const userSidebarComponent = document.querySelector(SELECTORS.USER_SIDEBAR);
        
        if (!userSidebarComponent) {
            return {
                userId: '未知',
                username: '未登录',
                avatar: getDefaultAvatar(),
                profileUrl: ''
            };
        }
        
        //console.log('找到侧边栏用户组件');
        
        // 获取个人主页链接
        const profileLink = userSidebarComponent.querySelector(SELECTORS.USER_PROFILE_LINK);
        const profileUrl = profileLink ? profileLink.getAttribute('href') : '';
        
        // 从href中提取userId
        let userId = '';
        if (profileUrl) {
            const match = profileUrl.match(/\/user\/profile\/([^?]+)/);
            if (match) {
                userId = match[1];
            }
        }
        
        // 获取头像
        const avatarImg = userSidebarComponent.querySelector('img');
        const avatar = avatarImg ? avatarImg.src : '';
        
        //console.log('侧边栏提取结果:', { userId, avatar, profileUrl });
        
        return {
            userId: userId || '未知',
            username: '点击查看详情',
            avatar: avatar || getDefaultAvatar(),
            profileUrl: profileUrl,
            needsDetailedInfo: true
        };
        
    } catch (error) {
        console.error('从侧边栏提取用户信息失败:', error);
        return getDefaultUserInfo();
    }
}

/**
 * 从个人主页提取详细用户信息
 * @returns {Object}
 */
export function extractUserInfoFromProfilePage() {
    //console.log('从个人主页提取详细信息...');
    
    try {
        let avatar = '';
        let username = '';
        let userId = '';
        let redId = '';
        let ip = '';
        let desc = '';
        let follows = '0';
        let fans = '0';
        let liked = '0';
        
        // 1. 获取头像
        const avatarImg = document.querySelector(SELECTORS.USER_AVATAR);
        if (avatarImg) {
            avatar = avatarImg.src;
            //console.log('✓ 头像:', avatar);
        }
        
        // 2. 获取用户名
        const usernameElement = document.querySelector(SELECTORS.USER_NAME);
        if (usernameElement) {
            username = usernameElement.textContent.trim();
            //console.log('✓ 用户名:', username);
        }
        
        // 3. 获取小红书号
        const redIdElement = document.querySelector(SELECTORS.USER_RED_ID);
        if (redIdElement) {
            const text = redIdElement.textContent.trim();
            redId = text.replace('小红书号:', '').replace('小红书号：', '').trim();
            //console.log('✓ 小红书号:', redId);
        }
        
        // 4. 获取IP地址
        const ipElement = document.querySelector(SELECTORS.USER_IP);
        if (ipElement) {
            const text = ipElement.textContent.trim();
            ip = text.replace('IP属地:', '').replace('IP属地：', '').replace('IP属地', '').trim();
            //console.log('✓ IP地址:', ip);
        }
        
        // 5. 获取个性签名
        const descElement = document.querySelector(SELECTORS.USER_DESC);
        if (descElement) {
            desc = descElement.textContent.trim();
            //console.log('✓ 个性签名:', desc);
        }
        
        // 6. 获取用户ID（从URL）
        const urlMatch = window.location.pathname.match(/\/user\/profile\/([^?]+)/);
        if (urlMatch) {
            userId = urlMatch[1];
            //console.log('✓ 用户ID:', userId);
        }
        
        // 7. 获取互动数据（关注、粉丝、获赞与收藏）
        const userInteractionsContainer = document.querySelector(SELECTORS.USER_INTERACTIONS);
        
        if (userInteractionsContainer) {
            //console.log('找到 user-interactions 容器');
            
            const interactionDivs = userInteractionsContainer.querySelectorAll(':scope > div');
            //console.log(`找到 ${interactionDivs.length} 个互动数据项`);
            
            if (interactionDivs && interactionDivs.length >= 3) {
                // 第一个：关注
                const followsCountElement = interactionDivs[0].querySelector('.count');
                if (followsCountElement) {
                    follows = followsCountElement.textContent.trim();
                    // console.log('✓ 关注:', follows);
                }
                
                // 第二个：粉丝
                const fansCountElement = interactionDivs[1].querySelector('.count');
                if (fansCountElement) {
                    fans = fansCountElement.textContent.trim();
                    // console.log('✓ 粉丝:', fans);
                }
                
                // 第三个：获赞与收藏
                const likedCountElement = interactionDivs[2].querySelector('.count');
                if (likedCountElement) {
                    liked = likedCountElement.textContent.trim();
                    //console.log('✓ 获赞与收藏:', liked);
                }
            } else {
                console.warn('互动数据项数量不足:', interactionDivs ? interactionDivs.length : 0);
            }
        } else {
            console.warn('未找到 user-interactions 容器');
        }
        
        const result = {
            userId: userId || '未知',
            username: username || '未知用户',
            avatar: avatar || getDefaultAvatar(),
            redId: redId || '未知',
            ip: ip || '未知',
            desc: desc || '这个人很懒，什么都没有留下',
            follows: follows,
            fans: fans,
            liked: liked
        };
        
        //console.log('✅ 个人主页信息提取完成:', result);
        return result;
        
    } catch (error) {
        console.error('❌ 从个人主页提取信息失败:', error);
        return getDefaultUserInfo();
    }
}

/**
 * 获取默认头像
 * @returns {string}
 */
function getDefaultAvatar() {
    return 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32"><circle cx="16" cy="16" r="16" fill="%23ccc"/></svg>';
}

/**
 * 获取默认用户信息
 * @returns {Object}
 */
function getDefaultUserInfo() {
    return {
        userId: '未知',
        username: '提取失败',
        avatar: getDefaultAvatar(),
        redId: '',
        ip: '',
        desc: '',
        follows: '0',
        fans: '0',
        liked: '0'
    };
}

