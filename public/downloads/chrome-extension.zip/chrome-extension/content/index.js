// 小红书助手 - 内容脚本主入口
import { MESSAGE_TYPES } from '../shared/constants.js';
import { performLike } from './actions/like.js';
import { performCollect } from './actions/collect.js';
import { performFollow } from './actions/follow.js';
import { performComment } from './actions/comment.js';
import { extractPostsFromPage } from './extractors/posts.js';
import { extractUserInfo } from './extractors/user.js';
import { createResponse } from '../shared/utils.js';
import { checkUserProfileFollowStatus } from './selectors/buttons.js';

// 监听来自popup和background的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    //console.log('Content Script 收到消息:', request);
    
    const { action } = request;
    
    switch (action) {
        case MESSAGE_TYPES.GET_POSTS:
            handleGetPosts(sendResponse);
            break;
            
        case MESSAGE_TYPES.LIKE_POST:
            handleLikePost(request, sendResponse);
            return true; // 异步响应
            
        case MESSAGE_TYPES.COLLECT_POST:
            handleCollectPost(request, sendResponse);
            return true; // 异步响应

        case MESSAGE_TYPES.FOLLOW_USER:
            handleFollowUser(request, sendResponse);
            return true; // 异步响应

        case MESSAGE_TYPES.COMMENT_POST:
            handleCommentPost(request, sendResponse);
            return true; // 异步响应
            
        case MESSAGE_TYPES.GET_USER_INFO:
            handleGetUserInfo(sendResponse);
            break;
            
        case MESSAGE_TYPES.CHECK_USER_FOLLOWED:
            handleCheckUserFollowed(sendResponse);
            break;
            
        case MESSAGE_TYPES.CHECK_SECURITY_CAPTCHA:
            handleCheckSecurityCaptcha(sendResponse);
            break;
            
        case MESSAGE_TYPES.SEARCH_KEYWORD:
            handleSearchKeyword(request, sendResponse);
            return true; // 异步响应
            
        case MESSAGE_TYPES.OPEN_FIRST_POST:
            handleOpenFirstPost(sendResponse);
            break;
            
        case MESSAGE_TYPES.OPEN_POST_BY_INDEX:
            handleOpenPostByIndex(request, sendResponse);
            break;
            
        case MESSAGE_TYPES.CLOSE_POST_DETAIL:
            handleClosePostDetail(sendResponse);
            break;
            
        case MESSAGE_TYPES.GET_RECENT_COMMENTER:
            handleGetRecentCommenter(request, sendResponse);
            break;
            
        case MESSAGE_TYPES.GET_ALL_RECENT_COMMENTERS:
            handleGetAllRecentCommenters(request, sendResponse);
            return true; // 异步响应
            
        case MESSAGE_TYPES.SCROLL_COMMENTS:
            handleScrollComments(sendResponse);
            break;
            
        case MESSAGE_TYPES.CHECK_END_OF_COMMENTS:
            handleCheckEndOfComments(sendResponse);
            break;
            
        case MESSAGE_TYPES.EXPAND_SUB_COMMENTS:
            handleExpandSubComments(sendResponse);
            return true; // 异步响应
            
        case MESSAGE_TYPES.REPLY_TO_COMMENT:
            handleReplyToComment(request, sendResponse);
            return true; // 异步响应
            
        case 'scrollPage':
            handleScrollPage(sendResponse);
            break;
            
        default:
            sendResponse(createResponse(false, '未知的消息类型'));
    }
    
    return true; // 保持消息通道开启
});

/**
 * 处理获取帖子请求
 * @param {Function} sendResponse - 响应函数
 */
function handleGetPosts(sendResponse) {
    try {
        const posts = extractPostsFromPage();
        sendResponse(createResponse(true, posts));
    } catch (error) {
        console.error('获取帖子失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理点赞请求
 * @param {Object} request - 请求对象
 * @param {Function} sendResponse - 响应函数
 */
async function handleLikePost(request, sendResponse) {
    try {
        const result = await performLike(request.delay);
        sendResponse(result);
    } catch (error) {
        console.error('点赞操作失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理收藏请求
 * @param {Object} request - 请求对象
 * @param {Function} sendResponse - 响应函数
 */
async function handleCollectPost(request, sendResponse) {
    try {
        const result = await performCollect(request.delay);
        sendResponse(result);
    } catch (error) {
        console.error('收藏操作失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理关注请求
 * @param {Object} request - 请求对象
 * @param {Function} sendResponse - 响应函数
 */
async function handleFollowUser(request, sendResponse) {
    try {
        const result = await performFollow(request.delay);
        sendResponse(result);
    } catch (error) {
        console.error('关注操作失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理评论请求
 * @param {Object} request - 请求对象
 * @param {Function} sendResponse - 响应函数
 */
async function handleCommentPost(request, sendResponse) {
    try {
        const result = await performComment(request.delay, request.content);
        sendResponse(result);
    } catch (error) {
        console.error('评论操作失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理获取用户信息请求
 * @param {Function} sendResponse - 响应函数
 */
function handleGetUserInfo(sendResponse) {
    try {
        const userInfo = extractUserInfo();
        sendResponse(createResponse(true, userInfo));
    } catch (error) {
        console.error('获取用户信息失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理检查用户主页关注状态请求
 * @param {Function} sendResponse - 响应函数
 */
function handleCheckUserFollowed(sendResponse) {
    try {
        const result = checkUserProfileFollowStatus();
        sendResponse(createResponse(true, result));
    } catch (error) {
        console.error('检查关注状态失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理检查安全验证请求
 * @param {Function} sendResponse - 响应函数
 */
function handleCheckSecurityCaptcha(sendResponse) {
    try {
        const captchaHeader = document.querySelector('.red-captcha-header');
        const captchaTitle = document.querySelector('.red-captcha-title');
        
        const hasCaptcha = !!(captchaHeader || captchaTitle);
        
        if (hasCaptcha) {
            console.log('[SecurityCheck] 🚨 检测到安全验证页面');
        }
        
        sendResponse(createResponse(true, { hasCaptcha }));
    } catch (error) {
        console.error('检查安全验证失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理搜索关键词请求
 * @param {Object} request - 请求对象
 * @param {Function} sendResponse - 响应函数
 */
async function handleSearchKeyword(request, sendResponse) {
    try {
        const { keyword } = request;
        console.log(`[Search] 🔍 开始搜索关键词: ${keyword}`);
        
        // 查找搜索输入框
        const searchInput = document.querySelector('#search-input');
        if (!searchInput) {
            throw new Error('未找到搜索输入框');
        }
        
        // 清空并输入关键词
        searchInput.value = '';
        searchInput.focus();
        
        // 模拟真实输入
        await new Promise(resolve => setTimeout(resolve, 200));
        searchInput.value = keyword;
        
        // 触发 input 事件
        const inputEvent = new Event('input', { bubbles: true });
        searchInput.dispatchEvent(inputEvent);
        
        // 等待一下让页面响应
        await new Promise(resolve => setTimeout(resolve, 300));
        
        // 触发回车事件
        const keydownEvent = new KeyboardEvent('keydown', {
            key: 'Enter',
            code: 'Enter',
            keyCode: 13,
            which: 13,
            bubbles: true
        });
        searchInput.dispatchEvent(keydownEvent);
        
        const keypressEvent = new KeyboardEvent('keypress', {
            key: 'Enter',
            code: 'Enter',
            keyCode: 13,
            which: 13,
            bubbles: true
        });
        searchInput.dispatchEvent(keypressEvent);
        
        const keyupEvent = new KeyboardEvent('keyup', {
            key: 'Enter',
            code: 'Enter',
            keyCode: 13,
            which: 13,
            bubbles: true
        });
        searchInput.dispatchEvent(keyupEvent);
        
        console.log('[Search] ✅ 搜索关键词成功');
        sendResponse(createResponse(true, '搜索成功'));
    } catch (error) {
        console.error('[Search] ❌ 搜索失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理打开第一个帖子请求
 * @param {Function} sendResponse - 响应函数
 */
function handleOpenFirstPost(sendResponse) {
    try {
        console.log('[OpenPost] 🔍 查找第一个帖子');
        
        // 查找第一个帖子链接
        const firstPost = document.querySelector('section.note-item a.cover');
        if (!firstPost) {
            throw new Error('未找到帖子');
        }
        
        const postUrl = firstPost.href;
        console.log('[OpenPost] 📝 找到帖子:', postUrl);
        
        // 点击打开帖子
        firstPost.click();
        
        console.log('[OpenPost] ✅ 已打开第一个帖子');
        sendResponse(createResponse(true, { url: postUrl }));
    } catch (error) {
        console.error('[OpenPost] ❌ 打开帖子失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理按索引打开帖子请求
 * @param {Object} request - 请求对象
 * @param {Function} sendResponse - 响应函数
 */
function handleOpenPostByIndex(request, sendResponse) {
    try {
        const { index } = request;
        console.log(`[OpenPost] 🔍 查找第 ${index + 1} 个帖子`);
        
        // 查找所有帖子
        const posts = document.querySelectorAll('section.note-item a.cover');
        if (posts.length === 0) {
            throw new Error('未找到帖子');
        }
        
        if (index >= posts.length) {
            throw new Error(`只有 ${posts.length} 个帖子，无法打开第 ${index + 1} 个`);
        }
        
        const post = posts[index];
        const postUrl = post.href;
        console.log(`[OpenPost] 📝 找到第 ${index + 1} 个帖子:`, postUrl);
        
        // 点击打开帖子
        post.click();
        
        console.log(`[OpenPost] ✅ 已打开第 ${index + 1} 个帖子`);
        sendResponse(createResponse(true, { url: postUrl, index }));
    } catch (error) {
        console.error('[OpenPost] ❌ 打开帖子失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理关闭帖子详情请求
 * @param {Function} sendResponse - 响应函数
 */
function handleClosePostDetail(sendResponse) {
    try {
        console.log('[ClosePost] 🔍 查找关闭按钮');
        
        // 方法1: 查找帖子详情页的关闭按钮（优先使用）
        const closeCircle = document.querySelector('.close-circle .close');
        if (closeCircle) {
            console.log('[ClosePost] ✅ 找到关闭圆圈按钮，点击');
            closeCircle.click();
            sendResponse(createResponse(true, '已关闭帖子详情'));
            return;
        }
        
        // 方法2: 查找其他关闭按钮
        const closeButton = document.querySelector('.close-mask-dark, .close');
        if (closeButton && closeButton.closest('.close-circle')) {
            console.log('[ClosePost] ✅ 找到关闭按钮，点击');
            closeButton.click();
            sendResponse(createResponse(true, '已关闭帖子详情'));
            return;
        }
        
        // 方法3: 按 ESC 键
        console.log('[ClosePost] 使用 ESC 键关闭');
        const escEvent = new KeyboardEvent('keydown', {
            key: 'Escape',
            code: 'Escape',
            keyCode: 27,
            which: 27,
            bubbles: true
        });
        document.dispatchEvent(escEvent);
        
        console.log('[ClosePost] ✅ 已尝试关闭帖子详情');
        sendResponse(createResponse(true, '已尝试关闭帖子详情'));
    } catch (error) {
        console.error('[ClosePost] ❌ 关闭失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 判断时间是否在指定时间范围内
 * @param {string} timeText - 时间文本，如"刚刚"、"4分钟前"、"2小时前"、"1天前"
 * @param {number} maxMinutes - 最大分钟数，例如：1440（24小时）、720（12小时）、360（6小时）、60（1小时）、30、15、5
 * @returns {boolean}
 */
function isWithinTimeRange(timeText, maxMinutes = 1440) {
    if (!timeText) return false;
    
    timeText = timeText.trim();
    console.log(`[TimeCheck] 检查时间: ${timeText}，最大允许: ${maxMinutes}分钟`);
    
    // "刚刚" 肯定在时间范围内
    if (timeText === '刚刚' || timeText === '刚才') {
        console.log('[TimeCheck] ✅ 时间: 刚刚');
        return true;
    }
    
    // 匹配 "X分钟前"
    const minuteMatch = timeText.match(/^(\d+)分钟前$/);
    if (minuteMatch) {
        const minutes = parseInt(minuteMatch[1], 10);
        const result = minutes <= maxMinutes;
        console.log(`[TimeCheck] ${result ? '✅' : '❌'} 时间: ${minutes}分钟前，限制: ${maxMinutes}分钟`);
        return result;
    }
    
    // 匹配 "X小时前"
    const hourMatch = timeText.match(/^(\d+)小时前$/);
    if (hourMatch) {
        const hours = parseInt(hourMatch[1], 10);
        const hoursInMinutes = hours * 60;
        const result = hoursInMinutes <= maxMinutes;
        console.log(`[TimeCheck] ${result ? '✅' : '❌'} 时间: ${hours}小时前（${hoursInMinutes}分钟），限制: ${maxMinutes}分钟`);
        return result;
    }
    
    // 匹配 "X天前"
    const dayMatch = timeText.match(/^(\d+)天前$/);
    if (dayMatch) {
        const days = parseInt(dayMatch[1], 10);
        const daysInMinutes = days * 24 * 60;
        const result = daysInMinutes <= maxMinutes;
        console.log(`[TimeCheck] ${result ? '✅' : '❌'} 时间: ${days}天前（${daysInMinutes}分钟），限制: ${maxMinutes}分钟`);
        return result;
    }
    
    // 其他情况（周、月等）都不在时间范围内
    console.log(`[TimeCheck] ❌ 时间超过 ${maxMinutes} 分钟:`, timeText);
    return false;
}

/**
 * 判断时间是否在1天内（兼容旧函数）
 * @param {string} timeText - 时间文本，如"刚刚"、"4分钟前"、"2小时前"、"1天前"
 * @returns {boolean}
 */
function isWithin1Day(timeText) {
    return isWithinTimeRange(timeText, 1440); // 1440分钟 = 24小时
}

/**
 * 处理获取最近评论者请求
 * @param {Object} request - 请求对象，包含 collectedUrls（已收集的用户URL数组）和 maxMinutes（最大分钟数）
 * @param {Function} sendResponse - 响应函数
 */
function handleGetRecentCommenter(request, sendResponse) {
    try {
        const collectedUrls = request.collectedUrls || [];
        const maxMinutes = request.maxMinutes || 1440; // 默认24小时（1440分钟）
        console.log(`[GetCommenter] 🔍 查找${maxMinutes}分钟内（${maxMinutes / 60}小时）的评论者`);
        console.log(`[GetCommenter] 已收集的用户数: ${collectedUrls.length}`);
        
        // 查找所有一级评论（parent-comment）
        const parentComments = document.querySelectorAll('.parent-comment');
        console.log(`[GetCommenter] 找到 ${parentComments.length} 条一级评论`);
        console.log('[GetCommenter] ========== 开始检查每条评论 ==========');
        
        if (parentComments.length === 0) {
            throw new Error('未找到评论');
        }
        
        let checkCount = 0;
        // 遍历评论，找到指定时间内且未收集过的第一个
        for (const comment of parentComments) {
            checkCount++;
            
            // 获取时间
            const dateSpan = comment.querySelector('.date span');
            if (!dateSpan) {
                console.log(`[GetCommenter] [${checkCount}] ⚠️ 未找到时间元素，跳过`);
                continue;
            }
            
            const timeText = dateSpan.textContent.trim();
            
            // 获取用户信息（先获取，用于日志输出）
            const authorLink = comment.querySelector('.author .name');
            const userName = authorLink ? authorLink.textContent.trim() : '未知用户';
            const userUrl = authorLink ? authorLink.href : '';
            
            // 输出每条评论的详细信息
            console.log(`[GetCommenter] [${checkCount}] 👤 用户: ${userName}`);
            console.log(`[GetCommenter] [${checkCount}] ⏰ 时间: ${timeText}`);
            
            // 判断是否在指定时间范围内
            const isWithinTime = isWithinTimeRange(timeText, maxMinutes);
            console.log(`[GetCommenter] [${checkCount}] ${isWithinTime ? '✅' : '❌'} 时间判断: ${isWithinTime ? '符合' : '不符合'}${maxMinutes}分钟内`);
            
            if (!isWithinTime) {
                continue;
            }
            
            if (!authorLink) {
                console.log(`[GetCommenter] [${checkCount}] ⚠️ 未找到用户链接，跳过`);
                continue;
            }
            
            // 检查是否已收集过
            const isCollected = collectedUrls.includes(userUrl);
            console.log(`[GetCommenter] [${checkCount}] ${isCollected ? '⚠️ 已收集过' : '🎯 未收集'}: ${userUrl}`);
            
            if (isCollected) {
                continue;
            }
            
            // 找到符合条件的评论者
            console.log(`[GetCommenter] [${checkCount}] ✅✅✅ 找到新的${maxMinutes}分钟内评论者: ${userName}`);
            console.log(`[GetCommenter] 用户链接: ${userUrl}`);
            console.log(`[GetCommenter] 评论时间: ${timeText}`);
            console.log('[GetCommenter] ========== 检查完成 ==========');
            
            sendResponse(createResponse(true, {
                userName,
                userUrl,
                timeText
            }));
            return;
        }
        
        console.log('[GetCommenter] ========== 检查完成 ==========');
        console.log(`[GetCommenter] 共检查了 ${checkCount} 条评论，未找到新的符合条件的评论者`);
        
        // 没有找到指定时间内的评论
        throw new Error(`未找到${maxMinutes}分钟内的新评论者`);
        
    } catch (error) {
        console.error('[GetCommenter] ❌ 获取评论者失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理获取所有最近评论者请求（返回所有符合条件的用户，而不是只返回第一个）
 * @param {Object} request - 请求对象，包含 collectedUrls（已收集的用户ID数组）、followedUserNames（已关注用户昵称数组）、maxMinutes（最大分钟数）和 includeSubComments（是否包含二级评论）
 * @param {Function} sendResponse - 响应函数
 */
async function handleGetAllRecentCommenters(request, sendResponse) {
    try {
        const collectedUrls = request.collectedUrls || [];
        const followedUserNames = request.followedUserNames || [];
        const maxMinutes = request.maxMinutes || 1440; // 默认24小时（1440分钟）
        const includeSubComments = request.includeSubComments !== undefined ? request.includeSubComments : true; // 默认包含二级评论
        console.log(`[GetAllCommenters] 🔍 查找所有${maxMinutes}分钟内（${maxMinutes / 60}小时）的评论者`);
        console.log(`[GetAllCommenters] 已收集的用户数: ${collectedUrls.length}`);
        console.log(`[GetAllCommenters] 已关注用户昵称数: ${followedUserNames.length}`);
        console.log(`[GetAllCommenters] 是否包含二级评论: ${includeSubComments}`);
        
        // 查找所有一级评论（parent-comment）
        const parentComments = document.querySelectorAll('.parent-comment');
        console.log(`[GetAllCommenters] 找到 ${parentComments.length} 条一级评论`);
        console.log('[GetAllCommenters] ========== 开始检查每条评论 ==========');
        
        if (parentComments.length === 0) {
            throw new Error('未找到评论');
        }
        
        const newUsers = [];
        const collectedUserIds = new Set(collectedUrls); // 使用 Set 提高查询性能
        const processedUserIds = new Set(); // 本次已处理的用户ID（防止同一帖子内重复）
        let checkCount = 0;
        let subCommentCount = 0;
        let expandedParentCount = 0; // 展开的一级评论数
        
        /**
         * 处理单条评论，提取用户信息
         * @param {Element} commentElement - 评论元素
         * @param {string} commentType - 评论类型（一级/二级）
         * @returns {Object|null} 用户信息或null
         */
        const processComment = (commentElement, commentType) => {
            checkCount++;
            
            // 获取时间
            const dateSpan = commentElement.querySelector('.date span');
            if (!dateSpan) {
                console.log(`[GetAllCommenters] [${checkCount}] [${commentType}] ⚠️ 未找到时间元素，跳过`);
                return null;
            }
            
            const timeText = dateSpan.textContent.trim();
            
            // 获取用户信息
            const authorLink = commentElement.querySelector('.author .name');
            const userName = authorLink ? authorLink.textContent.trim() : '未知用户';
            const userUrl = authorLink ? authorLink.href : '';
            
            // 提取用户ID（从URL中提取，避免参数不同导致重复）
            let userId = '';
            if (userUrl) {
                const userIdMatch = userUrl.match(/\/user\/profile\/([a-zA-Z0-9]+)/);
                userId = userIdMatch ? userIdMatch[1] : userUrl;
            }
            
            // 输出每条评论的详细信息
            console.log(`[GetAllCommenters] [${checkCount}] [${commentType}] 👤 用户: ${userName}`);
            console.log(`[GetAllCommenters] [${checkCount}] [${commentType}] 🆔 用户ID: ${userId}`);
            console.log(`[GetAllCommenters] [${checkCount}] [${commentType}] ⏰ 时间: ${timeText}`);
            
            // 判断是否在指定时间范围内
            const isWithinTime = isWithinTimeRange(timeText, maxMinutes);
            console.log(`[GetAllCommenters] [${checkCount}] [${commentType}] ${isWithinTime ? '✅' : '❌'} 时间判断: ${isWithinTime ? '符合' : '不符合'}${maxMinutes}分钟内`);
            
            if (!isWithinTime) {
                return null;
            }
            
            if (!authorLink || !userId) {
                console.log(`[GetAllCommenters] [${checkCount}] [${commentType}] ⚠️ 未找到用户链接或ID，跳过`);
                return null;
            }
            
            // 检查是否已收集过
            const isCollected = collectedUserIds.has(userId);
            console.log(`[GetAllCommenters] [${checkCount}] [${commentType}] ${isCollected ? '⚠️ 已收集过' : '🎯 未收集'}: ${userId}`);
            
            if (isCollected) {
                return null;
            }
            
            // 检查是否在本次已处理
            if (processedUserIds.has(userId)) {
                console.log(`[GetAllCommenters] [${checkCount}] [${commentType}] ⚠️ 本次已处理过: ${userId}`);
                return null;
            }
            
            // 检查是否已在关注列表中
            const isFollowed = followedUserNames.includes(userName);
            console.log(`[GetAllCommenters] [${checkCount}] [${commentType}] ${isFollowed ? '⚠️ 已在关注列表' : '✅ 不在关注列表'}: ${userName}`);
            
            if (isFollowed) {
                console.log(`[GetAllCommenters] [${checkCount}] [${commentType}] ⏭️ 跳过已关注用户: ${userName}`);
                return null;
            }
            
            // 标记为已处理
            processedUserIds.add(userId);
            collectedUserIds.add(userId); // 也加入已收集集合
            
            console.log(`[GetAllCommenters] [${checkCount}] [${commentType}] ✅✅✅ 添加新用户: ${userName}`);
            return {
                userName,
                userUrl,
                userId,
                timeText
            };
        };
        
        // 遍历所有一级评论
        for (let i = 0; i < parentComments.length; i++) {
            const parentComment = parentComments[i];
            
            // 先检查一级评论的时间
            const dateSpan = parentComment.querySelector('.date span');
            if (!dateSpan) {
                console.log(`[GetAllCommenters] [一级评论${i + 1}] ⚠️ 未找到时间元素，跳过`);
                continue;
            }
            
            const timeText = dateSpan.textContent.trim();
            const isWithinTime = isWithinTimeRange(timeText, maxMinutes);
            
            console.log(`[GetAllCommenters] [一级评论${i + 1}] ⏰ 时间: ${timeText} ${isWithinTime ? '✅符合' : '❌不符合'}`);
            
            // 只有一级评论符合时间条件，才处理它
            if (!isWithinTime) {
                console.log(`[GetAllCommenters] [一级评论${i + 1}] ⏭️ 时间不符合，跳过此评论及其回复`);
                continue;
            }
            
            // 一级评论符合条件，处理它
            const parentUser = processComment(parentComment, '一级评论');
            if (parentUser) {
                newUsers.push(parentUser);
            }
            
            // 如果启用了二级评论查询，展开并处理二级评论
            if (includeSubComments) {
                console.log(`[GetAllCommenters] [一级评论${i + 1}] 🔄 开始处理二级评论...`);
                
                let localExpandCount = 0;
                let hasExpanded = false;
                let consecutiveNoNewUsers = 0; // 连续没有新用户的次数
                const maxConsecutiveNoNew = 2; // 最多连续2次没有新用户就停止
                
                // 持续展开，直到没有新用户或没有展开按钮
                while (true) {
                    // 尝试展开一次
                    const expanded = await expandSubCommentsOnce(parentComment);
                    
                    if (expanded) {
                        localExpandCount++;
                        hasExpanded = true;
                        console.log(`[GetAllCommenters] [一级评论${i + 1}] 第${localExpandCount}次展开成功`);
                    } else {
                        // 没有展开按钮了
                        if (!hasExpanded) {
                            console.log(`[GetAllCommenters] [一级评论${i + 1}] ℹ️ 没有二级回复可展开`);
                        } else {
                            console.log(`[GetAllCommenters] [一级评论${i + 1}] ✅ 展开完成，共展开 ${localExpandCount} 次`);
                        }
                        break;
                    }
                    
                    // 展开后，收集当前的二级评论
                    const replyContainer = parentComment.querySelector('.reply-container');
                    if (replyContainer) {
                        const subComments = replyContainer.querySelectorAll('.comment-item.comment-item-sub');
                        const beforeCount = newUsers.length;
                        
                        // 处理新加载的二级评论
                        for (const subComment of subComments) {
                            const subUser = processComment(subComment, '二级评论');
                            if (subUser) {
                                newUsers.push(subUser);
                            }
                        }
                        
                        const newUsersInThisRound = newUsers.length - beforeCount;
                        console.log(`[GetAllCommenters] [一级评论${i + 1}] 本轮收集到 ${newUsersInThisRound} 个新用户`);
                        
                        if (newUsersInThisRound === 0) {
                            consecutiveNoNewUsers++;
                            console.log(`[GetAllCommenters] [一级评论${i + 1}] ⚠️ 连续 ${consecutiveNoNewUsers} 次没有新用户`);
                            
                            if (consecutiveNoNewUsers >= maxConsecutiveNoNew) {
                                console.log(`[GetAllCommenters] [一级评论${i + 1}] ⏹️ 连续${maxConsecutiveNoNew}次没有新用户，停止展开`);
                                break;
                            }
                        } else {
                            consecutiveNoNewUsers = 0; // 重置计数
                        }
                        
                        subCommentCount += subComments.length;
                    }
                }
                
                if (hasExpanded) {
                    expandedParentCount++;
                }
            }
            
        }
        
        console.log('[GetAllCommenters] ========== 检查完成 ==========');
        console.log(`[GetAllCommenters] 共检查了 ${checkCount} 条评论（一级: ${parentComments.length}, 二级: ${subCommentCount}）`);
        console.log(`[GetAllCommenters] 展开了 ${expandedParentCount} 个一级评论的回复`);
        console.log(`[GetAllCommenters] 找到 ${newUsers.length} 个新的符合条件的用户`);
        
        sendResponse(createResponse(true, {
            users: newUsers,
            totalChecked: checkCount,
            subCommentCount: subCommentCount,
            expandedParentCount: expandedParentCount
        }));
        
    } catch (error) {
        console.error('[GetAllCommenters] ❌ 获取评论者失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理滚动评论区请求
 * @param {Function} sendResponse - 响应函数
 */
function handleScrollComments(sendResponse) {
    try {
        console.log('[ScrollComments] 📜 滚动评论区');
        
        // 查找 note-scroller 容器（帖子详情页的滚动容器）
        const noteScroller = document.querySelector('.note-scroller');
        if (!noteScroller) {
            console.error('[ScrollComments] ❌ 未找到 .note-scroller 容器');
            sendResponse(createResponse(false, '未找到评论区滚动容器'));
            return;
        }
        
        console.log('[ScrollComments] ✅ 找到 .note-scroller 容器');
        
        // 记录滚动前的评论数量
        const commentsBefore = document.querySelectorAll('.parent-comment').length;
        console.log(`[ScrollComments] 滚动前评论数: ${commentsBefore}`);
        
        // 滚动 note-scroller 容器到底部
        const scrollHeight = noteScroller.scrollHeight;
        const currentScroll = noteScroller.scrollTop;
        console.log(`[ScrollComments] 当前滚动位置: ${currentScroll}, 总高度: ${scrollHeight}`);
        
        noteScroller.scrollTo({
            top: scrollHeight,
            behavior: 'smooth'
        });
        
        console.log(`[ScrollComments] ✅ 已滚动到底部`);
        
        sendResponse(createResponse(true, { commentsBefore }));
    } catch (error) {
        console.error('[ScrollComments] ❌ 滚动失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理滚动页面请求
 * @param {Function} sendResponse - 响应函数
 */
function handleScrollPage(sendResponse) {
    try {
        console.log('[Content] 📜 执行页面滚动');
        
        // 滚动到页面底部
        window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: 'smooth'
        });
        
        // 备用方案
        setTimeout(() => {
            document.documentElement.scrollTop = document.documentElement.scrollHeight;
        }, 100);
        
        sendResponse(createResponse(true, '滚动完成'));
    } catch (error) {
        console.error('滚动页面失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 检测评论是否到达底部（出现 "- THE END -"）
 * @param {Function} sendResponse - 响应函数
 */
function handleCheckEndOfComments(sendResponse) {
    try {
        console.log('[CheckEndOfComments] 🔍 检测是否到达评论底部');
        
        // 查找带有 end-container 类的元素
        const endContainer = document.querySelector('.end-container');
        
        if (endContainer) {
            // 检查元素文本内容是否包含 "- THE END -"
            const textContent = endContainer.textContent.trim();
            const isEnd = textContent.includes('- THE END -') || textContent.includes('THE END');
            
            if (isEnd) {
                console.log('[CheckEndOfComments] ✅ 检测到评论已到达底部');
                sendResponse(createResponse(true, { isEnd: true }));
            } else {
                console.log('[CheckEndOfComments] ℹ️ 找到 end-container 但内容不匹配:', textContent);
                sendResponse(createResponse(true, { isEnd: false }));
            }
        } else {
            console.log('[CheckEndOfComments] ℹ️ 未找到 end-container 元素，评论未到底部');
            sendResponse(createResponse(true, { isEnd: false }));
        }
    } catch (error) {
        console.error('[CheckEndOfComments] ❌ 检测失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 展开指定一级评论的二级回复（一次）
 * @param {Element} parentComment - 一级评论元素
 * @returns {Promise<boolean>} 是否成功展开
 */
async function expandSubCommentsOnce(parentComment) {
    // 查找该一级评论下的展开按钮
    const replyContainer = parentComment.querySelector('.reply-container');
    if (!replyContainer) {
        return false;
    }
    
    // 查找展开按钮
    const showMoreBtn = replyContainer.querySelector('.show-more');
    if (!showMoreBtn) {
        return false;
    }
    
    const btnText = showMoreBtn.textContent.trim();
    console.log(`[ExpandSub] 点击展开: ${btnText}`);
    
    showMoreBtn.click();
    
    // 等待内容加载（增加延迟，避免触发限制）
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    return true;
}

/**
 * 展开所有二级评论（点击"展开更多回复"按钮）- 保留用于向后兼容
 * @param {Function} sendResponse - 响应函数
 */
async function handleExpandSubComments(sendResponse) {
    try {
        console.log('[ExpandSubComments] 🔍 查找所有"展开更多回复"按钮');
        
        // 查找所有的展开按钮
        const expandButtons = document.querySelectorAll('.show-more');
        console.log(`[ExpandSubComments] 找到 ${expandButtons.length} 个展开按钮`);
        
        if (expandButtons.length === 0) {
            console.log('[ExpandSubComments] ℹ️ 没有需要展开的回复');
            sendResponse(createResponse(true, { expandedCount: 0 }));
            return;
        }
        
        let expandedCount = 0;
        
        // 点击所有展开按钮
        for (const button of expandButtons) {
            try {
                const buttonText = button.textContent.trim();
                console.log(`[ExpandSubComments] 点击展开按钮: ${buttonText}`);
                
                button.click();
                expandedCount++;
                
                // 等待一下，让内容加载
                await new Promise(resolve => setTimeout(resolve, 500));
            } catch (error) {
                console.error('[ExpandSubComments] ⚠️ 点击展开按钮失败:', error);
            }
        }
        
        console.log(`[ExpandSubComments] ✅ 成功展开 ${expandedCount} 个回复`);
        sendResponse(createResponse(true, { expandedCount }));
        
    } catch (error) {
        console.error('[ExpandSubComments] ❌ 展开失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理回复评论请求
 * @param {Object} request - 请求对象，包含 userId 和 commentContent
 * @param {Function} sendResponse - 响应函数
 */
async function handleReplyToComment(request, sendResponse) {
    try {
        const { userId, commentContent } = request;
        console.log(`[ReplyToComment] 🔍 查找用户 ${userId} 的评论并回复`);
        
        if (!commentContent || !commentContent.trim()) {
            console.log('[ReplyToComment] ⚠️ 评论内容为空，跳过回复');
            sendResponse(createResponse(true, { replied: false, reason: '评论内容为空' }));
            return;
        }
        
        // 查找所有一级评论和二级评论
        const allComments = document.querySelectorAll('.comment-item');
        console.log(`[ReplyToComment] 找到 ${allComments.length} 条评论`);
        
        let targetComment = null;
        
        // 遍历所有评论，查找匹配的用户ID
        for (const comment of allComments) {
            const authorLink = comment.querySelector('.author .name');
            if (authorLink && authorLink.href) {
                const userIdMatch = authorLink.href.match(/\/user\/profile\/([a-zA-Z0-9]+)/);
                if (userIdMatch && userIdMatch[1] === userId) {
                    targetComment = comment;
                    console.log(`[ReplyToComment] ✅ 找到目标评论，用户ID: ${userId}`);
                    break;
                }
            }
        }
        
        if (!targetComment) {
            console.log(`[ReplyToComment] ❌ 未找到用户 ${userId} 的评论`);
            sendResponse(createResponse(false, '未找到该用户的评论'));
            return;
        }
        
        // 查找回复按钮
        const replyButton = targetComment.querySelector('.reply.icon-container');
        if (!replyButton) {
            console.log('[ReplyToComment] ❌ 未找到回复按钮');
            sendResponse(createResponse(false, '未找到回复按钮'));
            return;
        }
        
        console.log('[ReplyToComment] 📝 点击回复按钮...');
        replyButton.click();
        
        // 等待评论框出现
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // 查找评论输入框
        const commentInput = document.querySelector('#content-textarea');
        if (!commentInput) {
            console.log('[ReplyToComment] ❌ 未找到评论输入框');
            sendResponse(createResponse(false, '未找到评论输入框'));
            return;
        }
        
        console.log('[ReplyToComment] ✍️ 输入评论内容...');
        // 设置评论内容
        commentInput.textContent = commentContent;
        commentInput.innerText = commentContent;
        
        // 触发input事件，让页面知道内容已更改
        const inputEvent = new Event('input', { bubbles: true });
        commentInput.dispatchEvent(inputEvent);
        
        // 等待一下让页面响应
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // 查找发送按钮（不是disabled的）
        const sendButton = document.querySelector('.btn.submit:not(.gray):not([disabled])');
        if (!sendButton) {
            console.log('[ReplyToComment] ⚠️ 发送按钮未激活，尝试再次触发输入');
            
            // 再次尝试触发输入
            commentInput.focus();
            await new Promise(resolve => setTimeout(resolve, 300));
            
            const sendButtonRetry = document.querySelector('.btn.submit:not(.gray):not([disabled])');
            if (!sendButtonRetry) {
                console.log('[ReplyToComment] ❌ 发送按钮仍未激活');
                sendResponse(createResponse(false, '发送按钮未激活'));
                return;
            }
            
            console.log('[ReplyToComment] 📤 点击发送按钮...');
            sendButtonRetry.click();
        } else {
            console.log('[ReplyToComment] 📤 点击发送按钮...');
            sendButton.click();
        }
        
        // 等待发送完成
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        console.log('[ReplyToComment] ✅ 回复评论成功');
        sendResponse(createResponse(true, { replied: true }));
        
    } catch (error) {
        console.error('[ReplyToComment] ❌ 回复评论失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', () => {
    console.log('小红书助手 Content Script 已加载');
    console.log('当前页面:', window.location.href);
});

//console.log('小红书助手 Content Script 初始化完成');

