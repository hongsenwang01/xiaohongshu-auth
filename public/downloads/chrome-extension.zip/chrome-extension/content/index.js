// 小红书助手 - 内容脚本主入口
import { MESSAGE_TYPES } from '../shared/constants.js';
import { performLike } from './actions/like.js';
import { performCollect } from './actions/collect.js';
import { performFollow } from './actions/follow.js';
import { performComment } from './actions/comment.js';
import { extractPostsFromPage } from './extractors/posts.js';
import { extractUserInfo } from './extractors/user.js';
import { createResponse } from '../shared/utils.js';
import { checkUserProfileFollowStatus } from './selectors/buttons.js';

// 监听来自popup和background的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    //console.log('Content Script 收到消息:', request);
    
    const { action } = request;
    
    switch (action) {
        case MESSAGE_TYPES.GET_POSTS:
            handleGetPosts(sendResponse);
            break;
            
        case MESSAGE_TYPES.LIKE_POST:
            handleLikePost(request, sendResponse);
            return true; // 异步响应
            
        case MESSAGE_TYPES.COLLECT_POST:
            handleCollectPost(request, sendResponse);
            return true; // 异步响应

        case MESSAGE_TYPES.FOLLOW_USER:
            handleFollowUser(request, sendResponse);
            return true; // 异步响应

        case MESSAGE_TYPES.COMMENT_POST:
            handleCommentPost(request, sendResponse);
            return true; // 异步响应
            
        case MESSAGE_TYPES.GET_USER_INFO:
            handleGetUserInfo(sendResponse);
            break;
            
        case MESSAGE_TYPES.CHECK_USER_FOLLOWED:
            handleCheckUserFollowed(sendResponse);
            break;
            
        case 'scrollPage':
            handleScrollPage(sendResponse);
            break;
            
        default:
            sendResponse(createResponse(false, '未知的消息类型'));
    }
    
    return true; // 保持消息通道开启
});

/**
 * 处理获取帖子请求
 * @param {Function} sendResponse - 响应函数
 */
function handleGetPosts(sendResponse) {
    try {
        const posts = extractPostsFromPage();
        sendResponse(createResponse(true, posts));
    } catch (error) {
        console.error('获取帖子失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理点赞请求
 * @param {Object} request - 请求对象
 * @param {Function} sendResponse - 响应函数
 */
async function handleLikePost(request, sendResponse) {
    try {
        const result = await performLike(request.delay);
        sendResponse(result);
    } catch (error) {
        console.error('点赞操作失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理收藏请求
 * @param {Object} request - 请求对象
 * @param {Function} sendResponse - 响应函数
 */
async function handleCollectPost(request, sendResponse) {
    try {
        const result = await performCollect(request.delay);
        sendResponse(result);
    } catch (error) {
        console.error('收藏操作失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理关注请求
 * @param {Object} request - 请求对象
 * @param {Function} sendResponse - 响应函数
 */
async function handleFollowUser(request, sendResponse) {
    try {
        const result = await performFollow(request.delay);
        sendResponse(result);
    } catch (error) {
        console.error('关注操作失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理评论请求
 * @param {Object} request - 请求对象
 * @param {Function} sendResponse - 响应函数
 */
async function handleCommentPost(request, sendResponse) {
    try {
        const result = await performComment(request.delay, request.content);
        sendResponse(result);
    } catch (error) {
        console.error('评论操作失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理获取用户信息请求
 * @param {Function} sendResponse - 响应函数
 */
function handleGetUserInfo(sendResponse) {
    try {
        const userInfo = extractUserInfo();
        sendResponse(createResponse(true, userInfo));
    } catch (error) {
        console.error('获取用户信息失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理检查用户主页关注状态请求
 * @param {Function} sendResponse - 响应函数
 */
function handleCheckUserFollowed(sendResponse) {
    try {
        const result = checkUserProfileFollowStatus();
        sendResponse(createResponse(true, result));
    } catch (error) {
        console.error('检查关注状态失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理滚动页面请求
 * @param {Function} sendResponse - 响应函数
 */
function handleScrollPage(sendResponse) {
    try {
        console.log('[Content] 📜 执行页面滚动');
        
        // 滚动到页面底部
        window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: 'smooth'
        });
        
        // 备用方案
        setTimeout(() => {
            document.documentElement.scrollTop = document.documentElement.scrollHeight;
        }, 100);
        
        sendResponse(createResponse(true, '滚动完成'));
    } catch (error) {
        console.error('滚动页面失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', () => {
    console.log('小红书助手 Content Script 已加载');
    console.log('当前页面:', window.location.href);
});

//console.log('小红书助手 Content Script 初始化完成');

