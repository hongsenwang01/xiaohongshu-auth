// 按钮查找相关函数
import { SELECTORS, STATUS_ICONS } from '../../shared/constants.js';
import { isInCommentArea } from '../../shared/utils.js';

/**
 * 查找主帖点赞按钮（排除评论区）
 * @returns {Element|null}
 */
export function findLikeButton() {
    console.log('[FindLike] 开始查找主帖点赞按钮...');
    
    // 方法1: 先找到主帖的互动区域 engage-bar
    const engageBar = document.querySelector(SELECTORS.ENGAGE_BAR);
    if (engageBar) {
        console.log('[FindLike] 找到 engage-bar 互动区域');
        
        // 在 engage-bar 内查找点赞按钮
        const likeWrapper = engageBar.querySelector(SELECTORS.LIKE_WRAPPER);
        if (likeWrapper) {
            console.log('[FindLike] ✅ 在 engage-bar 内找到点赞按钮');
            return likeWrapper;
        }
        
        // 尝试通过SVG查找
        const svgUse = engageBar.querySelector(SELECTORS.LIKE_ICON);
        if (svgUse) {
            const likeButton = svgUse.closest(SELECTORS.LIKE_WRAPPER) || 
                              svgUse.closest('span') ||
                              svgUse.parentElement;
            if (likeButton) {
                console.log('[FindLike] ✅ 在 engage-bar 内通过SVG找到点赞按钮');
                return likeButton;
            }
        }
    } else {
        console.warn('[FindLike] ⚠️ 未找到 engage-bar 区域');
    }
    
    // 方法2: 查找 interactions engage-bar 
    const interactionsBar = document.querySelector(SELECTORS.INTERACTIONS_BAR);
    if (interactionsBar) {
        console.log('[FindLike] 找到 interactions.engage-bar 互动区域');
        const likeWrapper = interactionsBar.querySelector(SELECTORS.LIKE_WRAPPER);
        if (likeWrapper) {
            console.log('[FindLike] ✅ 在 interactions.engage-bar 内找到点赞按钮');
            return likeWrapper;
        }
    }
    
    // 方法3: 排除评论区，查找主帖区域的点赞按钮
    const allLikeWrappers = document.querySelectorAll(SELECTORS.LIKE_WRAPPER);
    console.log('[FindLike] 找到 ' + allLikeWrappers.length + ' 个 like-wrapper 元素');
    
    for (const wrapper of allLikeWrappers) {
        if (!isInCommentArea(wrapper)) {
            console.log('[FindLike] ✅ 找到主帖区域的点赞按钮（已排除评论区）');
            return wrapper;
        } else {
            console.log('[FindLike] ⏭️ 跳过评论区的点赞按钮');
        }
    }
    
    console.warn('[FindLike] ❌ 未找到主帖点赞按钮');
    return null;
}

/**
 * 检查是否已经点赞
 * @param {Element} likeButton - 点赞按钮元素
 * @returns {boolean}
 */
export function isAlreadyLiked(likeButton) {
    // 方法1: 直接查询所有 use 元素（这是最可靠的方法）
    const allUseElements = likeButton.querySelectorAll('use');
    
    for (let i = 0; i < allUseElements.length; i++) {
        const use = allUseElements[i];
        const href = use.getAttribute('xlink:href');
        
        if (href === STATUS_ICONS.LIKED) {
            //console.log('[isAlreadyLiked] ✅ 检测到已点赞状态');
            return true;
        }
        if (href === STATUS_ICONS.LIKE) {
            //console.log('[isAlreadyLiked] ❌ 检测到未点赞状态');
            return false;
        }
    }
    
    // 方法2: 检查 class 名称中是否包含 'liked' 或 'active'
    const className = likeButton.className || '';
    if (className.includes('liked') || className.includes('like-active')) {
        //console.log('[isAlreadyLiked] ✅ 通过className检测到已点赞');
        return true;
    }
    
    //console.log('[isAlreadyLiked] ❌ 未检测到已点赞状态');
    return false;
}

/**
 * 查找主帖收藏按钮（排除评论区）
 * @returns {Element|null}
 */
export function findCollectButton() {
    //console.log('开始查找主帖收藏按钮...');
    
    // 方法1: 先找到主帖的互动区域 engage-bar
    const engageBar = document.querySelector(SELECTORS.ENGAGE_BAR);
    if (engageBar) {
        //console.log('找到 engage-bar 互动区域');
        
        // 在 engage-bar 内查找收藏按钮
        const collectWrapper = engageBar.querySelector(SELECTORS.COLLECT_WRAPPER);
        if (collectWrapper) {
            //console.log('✅ 在 engage-bar 内找到收藏按钮');
            return collectWrapper;
        }
        
        // 尝试通过SVG查找
        const svgUse = engageBar.querySelector(SELECTORS.COLLECT_ICON);
        if (svgUse) {
            const collectButton = svgUse.closest(SELECTORS.COLLECT_WRAPPER) || 
                                  svgUse.closest('span') ||
                                  svgUse.parentElement;
            if (collectButton) {
                //console.log('✅ 在 engage-bar 内通过SVG找到收藏按钮');
                return collectButton;
            }
        }
    } else {
        console.warn('⚠️ 未找到 engage-bar 区域');
    }
    
    // 方法2: 查找 interactions engage-bar 
    const interactionsBar = document.querySelector(SELECTORS.INTERACTIONS_BAR);
    if (interactionsBar) {
        //console.log('找到 interactions.engage-bar 互动区域');
        const collectWrapper = interactionsBar.querySelector(SELECTORS.COLLECT_WRAPPER);
        if (collectWrapper) {
            //console.log('✅ 在 interactions.engage-bar 内找到收藏按钮');
            return collectWrapper;
        }
    }
    
    // 方法3: 排除评论区，查找主帖区域的收藏按钮
    const allCollectWrappers = document.querySelectorAll(SELECTORS.COLLECT_WRAPPER);
    //console.log(`找到 ${allCollectWrappers.length} 个 collect-wrapper 元素`);
    
    for (const wrapper of allCollectWrappers) {
        if (!isInCommentArea(wrapper)) {
            //console.log('✅ 找到主帖区域的收藏按钮（已排除评论区）');
            return wrapper;
        } else {
            //console.log('⏭️ 跳过评论区的收藏按钮');
        }
    }
    
    console.warn('❌ 未找到主帖收藏按钮');
    return null;
}

/**
 * 检查是否已经收藏
 * @param {Element} collectButton - 收藏按钮元素
 * @returns {boolean}
 */
export function isAlreadyCollected(collectButton) {
    // 方法1: 直接查询所有 use 元素
    const allUseElements = collectButton.querySelectorAll('use');
    
    for (let i = 0; i < allUseElements.length; i++) {
        const use = allUseElements[i];
        const href = use.getAttribute('xlink:href');
        
        if (href === STATUS_ICONS.COLLECTED) {
            //console.log('[isAlreadyCollected] ✅ 检测到已收藏状态');
            return true;
        }
        if (href === STATUS_ICONS.COLLECT) {
            //console.log('[isAlreadyCollected] ❌ 检测到未收藏状态');
            return false;
        }
    }
    
    // 方法2: 检查 class 名称中是否包含 'collected'
    const className = collectButton.className || '';
    if (className.includes('collected') || className.includes('collect-active')) {
        //console.log('[isAlreadyCollected] ✅ 通过className检测到已收藏');
        return true;
    }
    
    //console.log('[isAlreadyCollected] ❌ 未检测到已收藏状态');
    return false;
}

/**
 * 查找关注按钮
 * @returns {Element|null}
 */
export function findFollowButton() {
    //console.log('开始查找关注按钮...');

    // 方法1: 通过你提供的HTML结构查找
    let followButton = document.querySelector(SELECTORS.FOLLOW_BUTTON);
    if (followButton) {
        //console.log('✅ 找到关注按钮（直接选择器）');
        return followButton;
    }

    // 方法2: 在详情页的关注区域查找
    const followDetailContainer = document.querySelector(SELECTORS.FOLLOW_DETAIL_CONTAINER);
    if (followDetailContainer) {
        //console.log('找到详情页关注容器');
        followButton = followDetailContainer.querySelector('button.follow-button, button[class*="follow"]');
        if (followButton) {
            //console.log('✅ 在详情页关注容器内找到关注按钮');
            return followButton;
        }
    }

    // 方法3: 查找包含"关注"文本的按钮
    const allButtons = document.querySelectorAll('button');
    for (const button of allButtons) {
        const buttonText = button.textContent.trim();
        if (buttonText === '关注' || buttonText === 'Follow') {
            // 确保不是取消关注按钮
            if (!button.classList.contains('followed') &&
                !buttonText.includes('取消') &&
                !buttonText.includes('取消关注') &&
                !buttonText.includes('Unfollow')) {
                //console.log('✅ 通过文本找到关注按钮');
                return button;
            }
        }
    }

    console.warn('❌ 未找到关注按钮');
    return null;
}

/**
 * 检查是否已经关注
 * @param {Element} followButton - 关注按钮元素
 * @returns {boolean}
 */
export function isAlreadyFollowed(followButton) {
    // 检查按钮文本
    const buttonText = followButton.textContent.trim();
    if (buttonText === '已关注' || buttonText === 'Following' || buttonText.includes('已关注')) {
        //console.log('已经关注（按钮文本显示已关注）');
        return true;
    }

    // 检查按钮的class状态
    if (followButton.classList.contains('followed') ||
        followButton.classList.contains('following') ||
        followButton.classList.contains('already-follow')) {
        //console.log('已经关注（按钮class状态）');
        return true;
    }

    //console.log('未关注');
    return false;
}

