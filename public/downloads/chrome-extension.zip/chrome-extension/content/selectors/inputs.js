// 输入框查找相关函数
import { SELECTORS } from '../../shared/constants.js';

/**
 * 查找评论输入区域（初始状态）
 * @returns {Element|null}
 */
export function findCommentInputArea() {
    console.log('查找评论输入区域...');
    
    // 方法1: 通过 class="content-edit" 查找
    const contentEdit = document.querySelector(SELECTORS.CONTENT_EDIT);
    if (contentEdit) {
        console.log('✅ 通过 .content-edit 找到输入区域');
        return contentEdit;
    }
    
    // 方法2: 通过 id="content-textarea" 查找
    const textarea = document.querySelector(SELECTORS.CONTENT_TEXTAREA);
    if (textarea) {
        console.log('✅ 通过 #content-textarea 找到输入区域');
        return textarea.parentElement || textarea;
    }
    
    // 方法3: 在 engage-bar 下方查找
    const engageBar = document.querySelector(SELECTORS.ENGAGE_BAR);
    if (engageBar) {
        const parent = engageBar.parentElement;
        if (parent) {
            const contentEdit = parent.querySelector(SELECTORS.CONTENT_EDIT);
            if (contentEdit) {
                console.log('✅ 在 engage-bar 附近找到输入区域');
                return contentEdit;
            }
        }
    }
    
    console.warn('❌ 未找到评论输入区域');
    return null;
}

/**
 * 查找实际的评论输入框
 * @returns {Element|null}
 */
export function findCommentTextarea() {
    console.log('查找评论输入框...');
    
    // 方法1: 通过 id 查找
    const textarea = document.querySelector(SELECTORS.CONTENT_TEXTAREA);
    if (textarea) {
        console.log('✅ 通过 #content-textarea 找到输入框');
        return textarea;
    }
    
    // 方法2: 通过 contenteditable 属性查找
    const editableP = document.querySelector(SELECTORS.EDITABLE_P);
    if (editableP) {
        console.log('✅ 通过 contenteditable 找到输入框');
        return editableP;
    }
    
    // 方法3: 在 content-edit 内查找 p 标签
    const contentEdit = document.querySelector(SELECTORS.CONTENT_EDIT);
    if (contentEdit) {
        const p = contentEdit.querySelector('p');
        if (p) {
            console.log('✅ 在 .content-edit 内找到 p 标签');
            return p;
        }
    }
    
    console.warn('❌ 未找到评论输入框');
    return null;
}

