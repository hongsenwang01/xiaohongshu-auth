// 等待相关工具函数
import { sleep } from '../../shared/utils.js';
import { TIMING } from '../../shared/constants.js';

/**
 * 等待页面准备就绪
 * @returns {Promise<void>}
 */
export function waitForPageReady() {
    return new Promise((resolve) => {
        if (document.readyState === 'complete') {
            // 额外等待一段时间确保内容加载
            setTimeout(resolve, TIMING.PAGE_LOAD_WAIT);
        } else {
            window.addEventListener('load', () => {
                setTimeout(resolve, TIMING.PAGE_LOAD_WAIT);
            });
        }
    });
}

/**
 * 等待发送按钮出现
 * @param {number} timeout - 超时时间
 * @returns {Promise<Element|null>}
 */
export function waitForSubmitButton(timeout = TIMING.SUBMIT_BUTTON_WAIT) {
    return new Promise((resolve) => {
        const startTime = Date.now();
        
        const checkButton = () => {
            // 查找发送按钮
            const submitButton = document.querySelector('button.btn.submit') || 
                                 document.querySelector('button.submit') ||
                                 document.querySelector('button[class*="submit"]');
            
            if (submitButton) {
                console.log('✅ 发送按钮已出现');
                resolve(submitButton);
                return;
            }
            
            // 检查超时
            if (Date.now() - startTime > timeout) {
                console.warn('⚠️ 等待发送按钮超时');
                resolve(null);
                return;
            }
            
            // 继续检查
            setTimeout(checkButton, 100);
        };
        
        checkButton();
    });
}

export { sleep };

