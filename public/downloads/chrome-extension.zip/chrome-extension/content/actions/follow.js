// 关注操作模块
import { findFollowButton, isAlreadyFollowed } from '../selectors/buttons.js';
import { waitForPageReady, sleep } from '../utils/wait.js';
import { TIMING, ERROR_MESSAGES } from '../../shared/constants.js';

/**
 * 执行关注操作
 * @param {number} delay - 延迟时间（毫秒）
 * @returns {Promise<Object>}
 */
export async function performFollow(delay = 0) {
    try {
        console.log(`等待 ${delay}ms 后执行关注...`);

        // 等待指定的延迟时间
        if (delay > 0) {
            await sleep(delay);
        }

        // 等待页面加载完成
        await waitForPageReady();

        // 查找关注按钮
        const followButton = findFollowButton();

        if (!followButton) {
            throw new Error(ERROR_MESSAGES.FOLLOW_BUTTON_NOT_FOUND);
        }

        // 检查是否已经关注
        if (isAlreadyFollowed(followButton)) {
            console.log('已经关注过了，跳过');
            return {
                success: true,
                alreadyFollowed: true,
                message: '已经关注过了'
            };
        }

        // 执行点击
        console.log('执行点击关注...');
        followButton.click();

        // 等待一小段时间确保关注完成
        await sleep(TIMING.ACTION_WAIT);

        console.log('✅ 关注成功！');
        return {
            success: true,
            alreadyFollowed: false,
            message: '关注成功'
        };

    } catch (error) {
        console.error('❌ 关注失败:', error);
        return {
            success: false,
            error: error.message
        };
    }
}