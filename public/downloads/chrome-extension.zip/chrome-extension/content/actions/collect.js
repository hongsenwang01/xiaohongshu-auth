// 收藏操作模块
import { findCollectButton, isAlreadyCollected } from '../selectors/buttons.js';
import { waitForPageReady, sleep } from '../utils/wait.js';
import { TIMING, ERROR_MESSAGES } from '../../shared/constants.js';

/**
 * 执行收藏操作
 * @param {number} delay - 延迟时间（毫秒）
 * @returns {Promise<Object>}
 */
export async function performCollect(delay = 0) {
    try {
        //console.log(`等待 ${delay}ms 后执行收藏...`);
        
        // 等待指定的延迟时间
        if (delay > 0) {
            await sleep(delay);
        }
        
        // 等待页面加载完成
        await waitForPageReady();
        
        // 查找收藏按钮
        const collectButton = findCollectButton();
        
        if (!collectButton) {
            throw new Error(ERROR_MESSAGES.COLLECT_BUTTON_NOT_FOUND);
        }
        
        // 检查是否已经收藏
        const alreadyCollected = isAlreadyCollected(collectButton);
        
        if (alreadyCollected) {
            console.log('[Collect] ⏭️ 检测到已经收藏过了，跳过本次收藏操作');
            return {
                success: true,
                alreadyCollected: true,
                message: '帖子已经收藏过了，跳过本次操作'
            };
        }
        
        // 执行点击
        console.log('[Collect] 🖱️ 执行点击收藏...');
        collectButton.click();
        
        // 等待一小段时间确保收藏完成
        await sleep(TIMING.ACTION_WAIT);
        
        console.log('[Collect] ✅ 收藏成功！');
        return {
            success: true,
            alreadyCollected: false,
            message: '收藏成功'
        };

    } catch (error) {
        console.error('❌ 收藏失败:', error);
        return {
            success: false,
            error: error.message
        };
    }
}

