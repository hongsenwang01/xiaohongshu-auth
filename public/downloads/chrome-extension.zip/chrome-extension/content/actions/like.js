// 点赞操作模块
import { findLikeButton, isAlreadyLiked } from '../selectors/buttons.js';
import { waitForPageReady, sleep } from '../utils/wait.js';
import { TIMING, ERROR_MESSAGES } from '../../shared/constants.js';

/**
 * 执行点赞操作
 * @param {number} delay - 延迟时间（毫秒）
 * @returns {Promise<Object>}
 */
export async function performLike(delay = 0) {
    try {
        // console.log(`等待 ${delay}ms 后执行点赞...`);
        
        // 等待指定的延迟时间
        if (delay > 0) {
            await sleep(delay);
        }

        // 等待页面加载完成
        await waitForPageReady();
        
        // 查找点赞按钮
        const likeButton = findLikeButton();
        
        if (!likeButton) {
            throw new Error(ERROR_MESSAGES.LIKE_BUTTON_NOT_FOUND);
        }
        
        // 检查是否已经点赞
        if (isAlreadyLiked(likeButton)) {
            // console.log('已经点赞过了，跳过');
            return {
                success: true,
                alreadyLiked: true,
                message: '已经点赞过了'
            };
        }
        
        // 执行点击
        // console.log('执行点击点赞...');
        likeButton.click();
        
        // 等待一小段时间确保点赞完成
        await sleep(TIMING.ACTION_WAIT);
        
        // console.log('✅ 点赞成功！');
        return {
            success: true,
            alreadyLiked: false,
            message: '点赞成功'
        };
        
    } catch (error) {
        console.error('❌ 点赞失败:', error);
        return {
            success: false,
            error: error.message
        };
    }
}

