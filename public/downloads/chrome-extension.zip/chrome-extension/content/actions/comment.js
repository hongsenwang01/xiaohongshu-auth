// 评论操作模块
import { findCommentInputArea, findCommentTextarea } from '../selectors/inputs.js';
import { waitForPageReady, waitForSubmitButton, sleep } from '../utils/wait.js';
import { TIMING, ERROR_MESSAGES, DEFAULT_CONFIG } from '../../shared/constants.js';

/**
 * 执行评论操作
 * @param {number} delay - 延迟时间（毫秒）
 * @param {string} content - 评论内容
 * @returns {Promise<Object>}
 */
export async function performComment(delay = 0, content = DEFAULT_CONFIG.COMMENT_CONTENT) {
    try {
        //console.log(`等待 ${delay}ms 后执行评论...`);
        
        // 等待指定的延迟时间
        if (delay > 0) {
            await sleep(delay);
        }
        
        // 等待页面加载完成
        await waitForPageReady();
        
        //console.log('开始评论流程...');
        
        // 步骤1: 查找评论输入框区域
        const contentEdit = findCommentInputArea();
        if (!contentEdit) {
            throw new Error(ERROR_MESSAGES.COMMENT_AREA_NOT_FOUND);
        }
        
        //console.log('找到评论输入区域，准备点击激活...');
        
        // 步骤2: 点击输入框激活编辑模式
        contentEdit.click();
        await sleep(TIMING.ACTION_WAIT);
        
        // 步骤3: 等待发送按钮出现
        //console.log('等待发送按钮出现...');
        const submitButton = await waitForSubmitButton();
        if (!submitButton) {
            throw new Error(ERROR_MESSAGES.SUBMIT_BUTTON_NOT_FOUND);
        }
        
        //console.log('发送按钮已出现，准备输入内容...');
        
        // 步骤4: 查找实际的输入框并输入内容
        const textarea = findCommentTextarea();
        if (!textarea) {
            throw new Error(ERROR_MESSAGES.COMMENT_INPUT_NOT_FOUND);
        }
        
        // 输入内容
        //console.log(`输入评论内容: ${content}`);
        textarea.textContent = content;
        
        // 触发input事件，确保页面检测到输入
        const inputEvent = new Event('input', { bubbles: true });
        textarea.dispatchEvent(inputEvent);
        
        await sleep(TIMING.INPUT_WAIT);
        
        // 步骤5: 点击发送按钮
        //console.log('点击发送按钮...');
        submitButton.click();
        
        await sleep(TIMING.ACTION_WAIT);
        
        //console.log('✅ 评论成功！');
        return {
            success: true,
            message: '评论成功'
        };
        
    } catch (error) {
        console.error('❌ 评论失败:', error);
        return {
            success: false,
            error: error.message
        };
    }
}

