// 等待工具函数
import { TIMING } from '../../shared/constants.js';

/**
 * 延迟函数
 * @param {number} ms - 延迟时间（毫秒）
 * @returns {Promise<void>}
 */
export function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * 等待标签页加载完成
 * @param {number} tabId - 标签页ID
 * @returns {Promise<void>}
 */
export function waitForTabLoad(tabId) {
    return new Promise((resolve) => {
        chrome.tabs.get(tabId, (tab) => {
            if (tab.status === 'complete') {
                // 页面已加载，额外等待一段时间确保内容渲染
                setTimeout(resolve, TIMING.TAB_LOAD_EXTRA);
            } else {
                // 监听加载完成事件
                const listener = (updatedTabId, changeInfo) => {
                    if (updatedTabId === tabId && changeInfo.status === 'complete') {
                        chrome.tabs.onUpdated.removeListener(listener);
                        // 额外等待一段时间确保内容渲染
                        setTimeout(resolve, TIMING.TAB_LOAD_EXTRA);
                    }
                };
                chrome.tabs.onUpdated.addListener(listener);
                
                // 设置超时，避免永久等待
                setTimeout(() => {
                    chrome.tabs.onUpdated.removeListener(listener);
                    resolve();
                }, TIMING.TAB_LOAD_TIMEOUT);
            }
        });
    });
}

