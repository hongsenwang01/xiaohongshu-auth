// 小红书助手 - 后台脚本主入口
import { MESSAGE_TYPES } from '../shared/constants.js';
import { BrowseManager } from './services/browse.js';
import { loadBrowseState, saveBrowseState } from './services/storage.js';

// 创建浏览任务管理器
const browseManager = new BrowseManager();

// 监听插件安装事件
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        //console.log('小红书助手插件已安装');
        // 初始化存储
        saveBrowseState({});
    }
});

// 监听消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    //console.log('后台收到消息:', request);
    
    const { action } = request;
    
    switch (action) {
        case MESSAGE_TYPES.START_BROWSE:
            handleStartBrowse(request, sendResponse);
            break;
        
        case MESSAGE_TYPES.STOP_BROWSE:
            handleStopBrowse(request, sendResponse);
            break;
            
        case MESSAGE_TYPES.GET_BROWSE_STATE:
            handleGetBrowseState(request, sendResponse);
            break;
            
        default:
            sendResponse({ success: false, error: '未知的消息类型' });
    }
    
    return true; // 保持消息通道开启以支持异步响应
});

/**
 * 处理开始浏览请求
 * @param {Object} request - 请求对象
 * @param {Function} sendResponse - 响应函数
 */
async function handleStartBrowse(request, sendResponse) {
    try {
        const windowId = request.windowId || null;
        //console.log('收到启动请求，窗口ID:', windowId);
        const taskId = await browseManager.start(request.posts, request.config, windowId);
        sendResponse({ success: true, taskId: taskId });
    } catch (error) {
        console.error('开始浏览失败:', error);
        sendResponse({ success: false, error: error.message });
    }
}

/**
 * 处理停止浏览请求
 * @param {Object} request - 请求对象
 * @param {Function} sendResponse - 响应函数
 */
async function handleStopBrowse(request, sendResponse) {
    try {
        const taskId = request.taskId;
        if (!taskId) {
            sendResponse({ success: false, error: '缺少任务ID' });
            return;
        }
        await browseManager.stop(taskId);
        sendResponse({ success: true });
    } catch (error) {
        console.error('停止浏览失败:', error);
        sendResponse({ success: false, error: error.message });
    }
}

/**
 * 处理获取浏览状态请求
 * @param {Object} request - 请求对象
 * @param {Function} sendResponse - 响应函数
 */
function handleGetBrowseState(request, sendResponse) {
    try {
        const taskId = request.taskId;
        let state;
        
        if (taskId) {
            // 获取指定任务的状态
            state = browseManager.getTaskState(taskId);
        } else {
            // 获取所有任务状态
            state = browseManager.getAllTasksState();
        }
        
        sendResponse({ success: true, state: state });
    } catch (error) {
        console.error('获取浏览状态失败:', error);
        sendResponse({ success: false, error: error.message });
    }
}

// 启动时恢复状态
async function restoreState() {
    try {
        const savedState = await loadBrowseState();
        if (savedState) {
            browseManager.restoreTasks(savedState);
            //console.log('恢复浏览状态完成');
        }
    } catch (error) {
        console.error('恢复状态失败:', error);
    }
}

// 初始化
restoreState();

//console.log('小红书助手后台脚本已启动 - 支持多任务并发');

