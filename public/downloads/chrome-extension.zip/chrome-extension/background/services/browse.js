// 浏览任务管理服务
import { MESSAGE_TYPES, BROWSE_EVENT_TYPES, TIMING } from '../../shared/constants.js';
import { randomDelay } from '../../shared/utils.js';
import { saveBrowseState } from './storage.js';
import { sleep, waitForTabLoad } from '../utils/wait.js';
import { addHistoryRecord } from '../../shared/history.js';

// 生成唯一任务ID
function generateTaskId() {
    return `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// 浏览任务状态
class BrowseTask {
    constructor(taskId, windowId = null) {
        this.taskId = taskId;
        this.windowId = windowId; // 任务所属的窗口ID
        this.isRunning = false;
        this.posts = [];
        this.currentIndex = 0;
        this.currentTabId = null;
        this.totalPosts = 0;
        this.createdAt = Date.now();
        // 自动化配置
        this.config = {
            autoLike: false,
            autoCollect: false,
            autoComment: false,
            commentContents: [], // 评论内容数组
            durationMin: 10,
            durationMax: 30
        };
    }

    toJSON() {
        return {
            taskId: this.taskId,
            windowId: this.windowId,
            isRunning: this.isRunning,
            posts: this.posts,
            currentIndex: this.currentIndex,
            currentTabId: this.currentTabId,
            totalPosts: this.totalPosts,
            createdAt: this.createdAt,
            config: this.config
        };
    }
}

// 浏览任务管理器（支持多任务并发）
export class BrowseManager {
    constructor() {
        // 使用 Map 管理多个任务
        this.tasks = new Map();
    }

    /**
     * 创建新任务并返回任务ID
     * @param {Array} posts - 帖子列表
     * @param {Object} config - 自动化配置
     * @param {number} windowId - 窗口ID
     * @returns {string} 任务ID
     */
    async start(posts, config = {}, windowId = null) {
        const taskId = generateTaskId();
        const task = new BrowseTask(taskId, windowId);
        
        task.isRunning = true;
        task.posts = posts;
        task.currentIndex = 0;
        task.totalPosts = posts.length;
        task.config = {
            autoLike: config.autoLike || false,
            autoCollect: config.autoCollect || false,
            autoFollow: config.autoFollow || false,
            autoComment: config.autoComment || false,
            commentContents: config.commentContents || [], // 评论内容数组
            durationMin: config.durationMin || 10,
            durationMax: config.durationMax || 30
        };
        
        this.tasks.set(taskId, task);
        await this.saveState();
        
        // 发送开始消息（包含任务ID）
        this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.STARTED, {
            totalPosts: posts.length,
            config: task.config
        });
        
        //console.log(`[${taskId}] 开始浏览 ${posts.length} 个帖子 (窗口ID: ${windowId})`);
        //console.log(`[${taskId}] 自动化配置:`, task.config);
        
        // 开始浏览
        this.browseNextPost(taskId);
        
        return taskId;
    }

    /**
     * 停止指定任务
     * @param {string} taskId - 任务ID
     */
    async stop(taskId) {
        const task = this.tasks.get(taskId);
        if (!task) {
            console.warn(`[${taskId}] 任务不存在`);
            return;
        }
        
        task.isRunning = false;
        
        // 关闭当前标签页
        await this.closeCurrentTab(taskId);
        
        // 从任务列表中移除
        this.tasks.delete(taskId);
        await this.saveState();
        
        this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.STOPPED, {});
        
        //console.log(`[${taskId}] 浏览任务已停止`);
    }

    /**
     * 完成指定任务
     * @param {string} taskId - 任务ID
     */
    async complete(taskId) {
        const task = this.tasks.get(taskId);
        if (!task) {
            console.warn(`[${taskId}] 任务不存在`);
            return;
        }
        
        task.isRunning = false;
        
        this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.COMPLETED, {
            totalPosts: task.totalPosts
        });
        
        // 从任务列表中移除
        this.tasks.delete(taskId);
        await this.saveState();
        
        //console.log(`[${taskId}] 浏览任务已完成`);
    }

    /**
     * 获取指定任务状态
     * @param {string} taskId - 任务ID
     * @returns {Object|null}
     */
    getTaskState(taskId) {
        const task = this.tasks.get(taskId);
        return task ? task.toJSON() : null;
    }

    /**
     * 获取所有任务状态
     * @returns {Object}
     */
    getAllTasksState() {
        const tasksState = {};
        for (const [taskId, task] of this.tasks.entries()) {
            tasksState[taskId] = task.toJSON();
        }
        return tasksState;
    }

    /**
     * 浏览下一个帖子
     * @param {string} taskId - 任务ID
     */
    async browseNextPost(taskId) {
        const task = this.tasks.get(taskId);
        if (!task) {
            console.warn(`[${taskId}] 任务不存在`);
            return;
        }
        
        if (!task.isRunning) {
            //console.log(`[${taskId}] 任务已停止`);
            return;
        }
        
        if (task.currentIndex >= task.totalPosts) {
            //console.log(`[${taskId}] 所有帖子浏览完成`);
            await this.complete(taskId);
            return;
        }
        
        const post = task.posts[task.currentIndex];
        const currentNum = task.currentIndex + 1;
        
        try {
            // 发送进度更新
            this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.PROGRESS, {
                currentIndex: currentNum,
                totalPosts: task.totalPosts,
                currentPost: post
            });
            
            //console.log(`[${taskId}] [${currentNum}/${task.totalPosts}] 浏览: ${post.title}`);
            
            // 打开新标签页 - 指定窗口ID确保在正确的窗口中打开
            const tabCreateOptions = {
                url: post.fullUrl,
                active: false
            };
            
            // 如果有指定窗口ID，则在该窗口中创建标签页
            if (task.windowId) {
                tabCreateOptions.windowId = task.windowId;
                //console.log(`[${taskId}] 在窗口 ${task.windowId} 中创建标签页`);
            }
            
            let tab;
            try {
                tab = await chrome.tabs.create(tabCreateOptions);
                //console.log(`[${taskId}] 标签页已创建: ${tab.id} (窗口: ${tab.windowId})`);
            } catch (error) {
                // 窗口可能已关闭，尝试不指定窗口创建
                if (task.windowId && error.message && error.message.includes('No window with id')) {
                    console.warn(`[${taskId}] 窗口 ${task.windowId} 不存在，任务终止`);
                    await this.stop(taskId);
                    return;
                }
                throw error;
            }
            
            task.currentTabId = tab.id;
            await this.saveState();
            
            this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.TAB_OPENED, {
                tabId: tab.id,
                post: post
            });
            
            // 等待页面加载完成
            await waitForTabLoad(tab.id);
            
            // 记录开始时间
            const startTime = Date.now();
            
            // 根据配置执行相应操作（串行执行，等待每个操作完成）
            let likeResult = { success: false, skipped: true, message: '未开启', status: 'disabled' };
            let collectResult = { success: false, skipped: true, message: '未开启', status: 'disabled' };
            let followResult = { success: false, skipped: true, message: '未开启', status: 'disabled' };
            let commentResult = { success: false, skipped: true, message: '未开启', status: 'disabled' };

            if (task.config.autoLike) {
                //console.log(`[${taskId}] ✓ 自动点赞已开启，执行点赞操作`);
                likeResult = await this.performLike(taskId, tab.id);
            } else {
                console.log(`[${taskId}] ✗ 自动点赞未开启，跳过`);
            }

            if (task.config.autoCollect) {
                //console.log(`[${taskId}] ✓ 自动收藏已开启，执行收藏操作`);
                collectResult = await this.performCollect(taskId, tab.id);
            } else {
                console.log(`[${taskId}] ✗ 自动收藏未开启，跳过`);
            }

            if (task.config.autoFollow) {
                //console.log(`[${taskId}] ✓ 自动关注已开启，执行关注操作`);
                followResult = await this.performFollow(taskId, tab.id);
            } else {
                console.log(`[${taskId}] ✗ 自动关注未开启，跳过`);
            }

            if (task.config.autoComment) {
                //console.log(`[${taskId}] ✓ 自动评论已开启，执行评论操作`);
                commentResult = await this.performComment(taskId, tab.id);
            } else {
                console.log(`[${taskId}] ✗ 自动评论未开启，跳过`);
            }
            
            // 计算已用时间
            const elapsedTime = Date.now() - startTime;
            //console.log(`[${taskId}] 操作完成，总耗时: ${elapsedTime}ms`);
            
            // 记录到历史（传递任务ID以获取窗口ID）
            await this.recordHistory(taskId, post, likeResult, collectResult, followResult, commentResult);
            
            // 计算本次浏览的目标时长（在配置范围内随机）
            const minDuration = (task.config.durationMin || 10) * 1000;
            const maxDuration = (task.config.durationMax || 30) * 1000;
            const targetDuration = randomDelay(minDuration, maxDuration);
            
            //console.log(`[${taskId}] 目标浏览时长: ${targetDuration / 1000}秒 (${task.config.durationMin}-${task.config.durationMax}秒范围内)`);
            
            // 等待剩余时间
            const remainingTime = targetDuration - elapsedTime;
            if (remainingTime > 0) {
                //console.log(`[${taskId}] 等待剩余时间: ${remainingTime}ms (${(remainingTime / 1000).toFixed(1)}秒)`);
                await sleep(remainingTime);
            }
            
            // 关闭标签页
            await this.closeCurrentTab(taskId);
            
            this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.TAB_CLOSED, {
                postIndex: task.currentIndex
            });
            
            // 继续下一个
            task.currentIndex++;
            await this.saveState();
            
            // 短暂延迟
            await sleep(TIMING.NEXT_POST_DELAY);
            await this.browseNextPost(taskId);
            
        } catch (error) {
            console.error(`[${taskId}] 浏览帖子失败:`, error);
            
            this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.ERROR, {
                error: error.message
            });
            
            // 继续下一个
            task.currentIndex++;
            await this.saveState();
            await sleep(TIMING.NEXT_POST_DELAY);
            await this.browseNextPost(taskId);
        }
    }

    /**
     * 执行点赞
     * @param {string} taskId - 任务ID
     * @param {number} tabId - 标签页ID
     * @returns {Promise<Object>} 返回操作结果
     */
    async performLike(taskId, tabId) {
        const delay = randomDelay(TIMING.LIKE_DELAY_MIN, TIMING.LIKE_DELAY_MAX);
        console.log(`[${taskId}] 将在 ${delay}ms 后执行点赞`);
        
        this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.LIKING, {
            delay: Math.round(delay / 1000)
        });
        
        let actionResult = {
            success: false,
            alreadyLiked: false,
            status: 'unknown'
        };
        
        try {
            const result = await chrome.tabs.sendMessage(tabId, {
                action: MESSAGE_TYPES.LIKE_POST,
                delay: delay
            });
            
            console.log(`[${taskId}] Content Script 返回结果:`, result);
            
            if (result.success) {
                console.log(`[${taskId}] 点赞操作完成:`, result.message);
                console.log(`[${taskId}] alreadyLiked状态:`, result.alreadyLiked);
                actionResult = {
                    success: true,
                    alreadyLiked: result.alreadyLiked,
                    status: result.alreadyLiked ? 'skipped' : 'success'
                };
                this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.LIKE_SUCCESS, {
                    message: result.message,
                    alreadyLiked: result.alreadyLiked
                });
            } else {
                console.warn(`[${taskId}] 点赞失败:`, result.error);
                actionResult.status = 'failed';
                this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.LIKE_ERROR, {
                    error: result.error
                });
            }
        } catch (error) {
            console.error(`[${taskId}] 发送点赞消息失败:`, error);
            actionResult.status = 'failed';
            this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.LIKE_ERROR, {
                error: '无法与页面通信'
            });
        }
        
        console.log(`[${taskId}] performLike 最终返回结果:`, actionResult);
        return actionResult;
    }

    /**
     * 执行收藏
     * @param {string} taskId - 任务ID
     * @param {number} tabId - 标签页ID
     * @returns {Promise<Object>} 返回操作结果
     */
    async performCollect(taskId, tabId) {
        const delay = randomDelay(TIMING.COLLECT_DELAY_MIN, TIMING.COLLECT_DELAY_MAX);
        //console.log(`[${taskId}] 将在 ${delay}ms 后执行收藏`);
        
        this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.COLLECTING, {
            delay: Math.round(delay / 1000)
        });
        
        let actionResult = {
            success: false,
            alreadyCollected: false,
            status: 'unknown'
        };
        
        try {
            const result = await chrome.tabs.sendMessage(tabId, {
                action: MESSAGE_TYPES.COLLECT_POST,
                delay: delay
            });
            
            if (result.success) {
                //console.log(`[${taskId}] 收藏操作完成:`, result.message);
                actionResult = {
                    success: true,
                    alreadyCollected: result.alreadyCollected,
                    status: result.alreadyCollected ? 'skipped' : 'success'
                };
                this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.COLLECT_SUCCESS, {
                    message: result.message,
                    alreadyCollected: result.alreadyCollected
                });
            } else {
                console.warn(`[${taskId}] 收藏失败:`, result.error);
                actionResult.status = 'failed';
                this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.COLLECT_ERROR, {
                    error: result.error
                });
            }
        } catch (error) {
            console.error(`[${taskId}] 发送收藏消息失败:`, error);
            actionResult.status = 'failed';
            this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.COLLECT_ERROR, {
                error: '无法与页面通信'
            });
        }
        
        return actionResult;
    }

    /**
     * 执行关注
     * @param {string} taskId - 任务ID
     * @param {number} tabId - 标签页ID
     * @returns {Promise<Object>} 返回操作结果
     */
    async performFollow(taskId, tabId) {
        const delay = randomDelay(TIMING.FOLLOW_DELAY_MIN, TIMING.FOLLOW_DELAY_MAX);
        //console.log(`[${taskId}] 将在 ${delay}ms 后执行关注`);

        this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.FOLLOWING, {
            delay: Math.round(delay / 1000)
        });

        let actionResult = {
            success: false,
            alreadyFollowed: false,
            status: 'unknown'
        };

        try {
            const result = await chrome.tabs.sendMessage(tabId, {
                action: MESSAGE_TYPES.FOLLOW_USER,
                delay: delay
            });

            if (result.success) {
                //console.log(`[${taskId}] 关注操作完成:`, result.message);
                actionResult = {
                    success: true,
                    alreadyFollowed: result.alreadyFollowed,
                    status: result.alreadyFollowed ? 'skipped' : 'success'
                };
                this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.FOLLOW_SUCCESS, {
                    message: result.message,
                    alreadyFollowed: result.alreadyFollowed
                });
            } else {
                console.warn(`[${taskId}] 关注失败:`, result.error);
                actionResult.status = 'failed';
                this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.FOLLOW_ERROR, {
                    error: result.error
                });
            }
        } catch (error) {
            console.error(`[${taskId}] 发送关注消息失败:`, error);
            actionResult.status = 'failed';
            this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.FOLLOW_ERROR, {
                error: '无法与页面通信'
            });
        }

        return actionResult;
    }

    /**
     * 执行评论
     * @param {string} taskId - 任务ID
     * @param {number} tabId - 标签页ID
     * @returns {Promise<Object>} 返回操作结果
     */
    async performComment(taskId, tabId) {
        const task = this.tasks.get(taskId);
        if (!task) {
            console.error(`[${taskId}] 任务不存在`);
            return { success: false, content: '', status: 'failed' };
        }
        
        // 从配置的评论内容中随机选择一条
        const commentContents = task.config.commentContents || [];
        if (commentContents.length === 0) {
            console.error(`[${taskId}] 没有可用的评论内容`);
            return { success: false, content: '', status: 'failed' };
        }
        
        // 随机选择一条评论
        const randomIndex = Math.floor(Math.random() * commentContents.length);
        const commentContent = commentContents[randomIndex];
        
        const delay = randomDelay(TIMING.COMMENT_DELAY_MIN, TIMING.COMMENT_DELAY_MAX);
        
        //console.log(`[${taskId}] 将在 ${delay}ms 后执行评论 (从 ${commentContents.length} 条中选择): "${commentContent}"`);
        
        this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.COMMENTING, {
            delay: Math.round(delay / 1000),
            content: commentContent
        });
        
        let actionResult = {
            success: false,
            content: commentContent,
            status: 'unknown'
        };
        
        try {
            const result = await chrome.tabs.sendMessage(tabId, {
                action: MESSAGE_TYPES.COMMENT_POST,
                delay: delay,
                content: commentContent
            });
            
            if (result.success) {
                //console.log(`[${taskId}] 评论操作完成:`, result.message);
                actionResult = {
                    success: true,
                    content: commentContent,
                    status: 'success'
                };
                this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.COMMENT_SUCCESS, {
                    message: result.message
                });
            } else {
                console.warn(`[${taskId}] 评论失败:`, result.error);
                actionResult.status = 'failed';
                this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.COMMENT_ERROR, {
                    error: result.error
                });
            }
        } catch (error) {
            console.error(`[${taskId}] 发送评论消息失败:`, error);
            actionResult.status = 'failed';
            this.broadcastMessage(taskId, BROWSE_EVENT_TYPES.COMMENT_ERROR, {
                error: '无法与页面通信'
            });
        }
        
        return actionResult;
    }
    
    /**
     * 记录到历史（按窗口ID隔离）
     * @param {string} taskId - 任务ID
     * @param {Object} post - 帖子信息
     * @param {Object} likeResult - 点赞结果
     * @param {Object} collectResult - 收藏结果
     * @param {Object} followResult - 关注结果
     * @param {Object} commentResult - 评论结果
     */
    async recordHistory(taskId, post, likeResult, collectResult, followResult, commentResult) {
        try {
            const task = this.tasks.get(taskId);
            const windowId = task ? task.windowId : null;

            await addHistoryRecord(post, {
                liked: likeResult.success && !likeResult.alreadyLiked,
                collected: collectResult.success && !collectResult.alreadyCollected,
                followed: followResult.success && !followResult.alreadyFollowed,
                commented: commentResult.success,
                commentContent: commentResult.content || '',
                likeStatus: likeResult.status,
                collectStatus: collectResult.status,
                followStatus: followResult.status,
                commentStatus: commentResult.status,
            }, windowId);
            
            //console.log(`[${taskId}] ✅ 已记录到历史:`, post.title, { windowId });
        } catch (error) {
            console.error(`[${taskId}] ❌ 记录历史失败:`, error);
        }
    }

    /**
     * 关闭当前标签页
     * @param {string} taskId - 任务ID
     */
    async closeCurrentTab(taskId) {
        const task = this.tasks.get(taskId);
        if (!task) return;
        
        if (task.currentTabId) {
            try {
                await chrome.tabs.remove(task.currentTabId);
                //console.log(`[${taskId}] 标签页 ${task.currentTabId} 已关闭`);
            } catch (error) {
                console.warn(`[${taskId}] 关闭标签页失败:`, error);
            }
            task.currentTabId = null;
        }
    }

    /**
     * 保存所有任务状态
     */
    async saveState() {
        await saveBrowseState(this.getAllTasksState());
    }

    /**
     * 广播消息
     * @param {string} taskId - 任务ID
     * @param {string} type - 消息类型
     * @param {Object} data - 数据
     */
    broadcastMessage(taskId, type, data) {
        chrome.runtime.sendMessage({
            action: MESSAGE_TYPES.BROWSE_UPDATE,
            taskId: taskId,
            type: type,
            data: data
        }).catch(err => {
            // popup可能未打开，忽略错误
            console.log(`[${taskId}] 发送消息失败（popup可能未打开）:`, err.message);
        });
    }
    
    /**
     * 恢复任务状态（从存储中）
     * @param {Object} tasksState - 任务状态对象
     */
    restoreTasks(tasksState) {
        if (!tasksState || typeof tasksState !== 'object') {
            return;
        }
        
        for (const [taskId, taskData] of Object.entries(tasksState)) {
            // 不恢复正在运行的任务，避免状态不一致
            if (taskData.isRunning) {
                //console.log(`[${taskId}] 跳过恢复正在运行的任务`);
                continue;
            }
            
            const task = new BrowseTask(taskId, taskData.windowId);
            task.posts = taskData.posts || [];
            task.currentIndex = taskData.currentIndex || 0;
            task.totalPosts = taskData.totalPosts || 0;
            task.createdAt = taskData.createdAt || Date.now();
            task.config = taskData.config || {
                autoLike: false,
                autoCollect: false,
                autoComment: false,
                durationMin: 10,
                durationMax: 30
            };
            // 不恢复 currentTabId 和 isRunning
            task.currentTabId = null;
            task.isRunning = false;
            
            this.tasks.set(taskId, task);
        }
        
        //console.log(`恢复了 ${this.tasks.size} 个任务状态`);
    }
}

