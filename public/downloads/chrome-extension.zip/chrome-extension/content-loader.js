// Content Script 加载器
// 由于 Manifest V3 的 content_scripts 不支持直接使用 ES 模块
// 我们使用动态 import() 来加载模块化的 content script

(async () => {
    try {
        //console.log('[Content Loader] 开始加载 Content Script 模块...');
        
        // 动态导入 content/index.js 模块
        const module = await import(chrome.runtime.getURL('content/index.js'));
        
        //console.log('[Content Loader] ✅ Content Script 模块加载成功');
    } catch (error) {
        console.error('[Content Loader] ❌ 加载 Content Script 失败:', error);
    }
})();

