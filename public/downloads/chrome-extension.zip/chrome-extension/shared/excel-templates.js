/**
 * Excel 模板处理工具
 * 用于生成和处理过滤名单的Excel模板
 */

/**
 * 生成排除名单 Excel 模板
 * @returns {Blob} Excel 文件 Blob
 */
export function generateExcludeListTemplate() {
    return generateExcelTemplate('排除名单', '请在下方填写要排除的用户名称，每行一个');
}

/**
 * 生成重点关注 Excel 模板
 * @returns {Blob} Excel 文件 Blob
 */
export function generateFocusListTemplate() {
    return generateExcelTemplate('重点关注', '请在下方填写要重点关注的用户名称，每行一个');
}

/**
 * 核心：生成 Excel 模板
 * @param {string} sheetName - 工作表名称
 * @param {string} instruction - 说明文本
 * @returns {Blob} Excel 文件 Blob
 */
function generateExcelTemplate(sheetName, instruction) {
    // 创建 CSV 格式的内容（兼容Excel）
    const csvContent = [
        ['用户名称'],
        ['# ' + instruction],
        ['# 示例用户1'],
        ['# 示例用户2'],
        ['# 示例用户3'],
        [''],
        ['用户1'],
        ['用户2'],
        ['用户3'],
    ].map(row => row.join(',')).join('\n');

    // 创建 Blob
    const bom = new Uint8Array([0xEF, 0xBB, 0xBF]); // UTF-8 BOM
    const blob = new Blob([bom, csvContent], { type: 'text/csv;charset=utf-8;' });
    return blob;
}

/**
 * 生成可下载链接并触发下载
 * @param {Blob} blob - 文件 Blob
 * @param {string} filename - 文件名
 */
export function downloadTemplate(blob, filename) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename || 'template.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
}

/**
 * 解析上传的 Excel/CSV 文件
 * @param {File} file - 上传的文件
 * @returns {Promise<string[]>} 用户名称列表
 */
export async function parseExcelFile(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        
        reader.onload = (event) => {
            try {
                const csv = event.target.result;
                const lines = csv.split('\n').map(line => line.trim());
                
                // 过滤：去掉注释行、空行和标题行
                const usernames = lines.filter(line => {
                    return line && 
                           !line.startsWith('#') && 
                           line !== '用户名称' &&
                           line.length > 0;
                });
                
                resolve(usernames);
            } catch (error) {
                reject(new Error('文件解析失败: ' + error.message));
            }
        };
        
        reader.onerror = () => {
            reject(new Error('文件读取失败'));
        };
        
        reader.readAsText(file, 'utf-8');
    });
}

/**
 * 验证用户名列表
 * @param {string[]} usernames - 用户名列表
 * @returns {Object} 验证结果
 */
export function validateUsernames(usernames) {
    if (!usernames || usernames.length === 0) {
        return { valid: false, message: '列表为空' };
    }
    
    if (usernames.length > 1000) {
        return { valid: false, message: '用户数量不能超过1000' };
    }
    
    const invalidNames = usernames.filter(name => {
        return name.length > 100 || name.length < 1;
    });
    
    if (invalidNames.length > 0) {
        return { valid: false, message: `发现 ${invalidNames.length} 个无效用户名` };
    }
    
    return { valid: true, message: `成功加载 ${usernames.length} 个用户`, count: usernames.length };
}

/**
 * 保存用户列表到存储
 * @param {string} key - 存储键名
 * @param {string[]} usernames - 用户名列表
 */
export async function saveUsernamesToStorage(key, usernames) {
    return new Promise((resolve, reject) => {
        const data = {
            usernames: usernames,
            timestamp: new Date().toISOString(),
            count: usernames.length
        };
        
        chrome.storage.local.set({ [key]: data }, () => {
            if (chrome.runtime.lastError) {
                reject(new Error('保存失败: ' + chrome.runtime.lastError.message));
            } else {
                resolve(data);
            }
        });
    });
}

/**
 * 从存储中读取用户列表
 * @param {string} key - 存储键名
 */
export async function getUsernamesFromStorage(key) {
    return new Promise((resolve, reject) => {
        chrome.storage.local.get([key], (result) => {
            if (chrome.runtime.lastError) {
                reject(new Error('读取失败: ' + chrome.runtime.lastError.message));
            } else {
                resolve(result[key] || null);
            }
        });
    });
}

/**
 * 清除存储中的用户列表
 * @param {string} key - 存储键名
 */
export async function clearUsernamesFromStorage(key) {
    return new Promise((resolve, reject) => {
        chrome.storage.local.remove(key, () => {
            if (chrome.runtime.lastError) {
                reject(new Error('清除失败: ' + chrome.runtime.lastError.message));
            } else {
                resolve();
            }
        });
    });
}
