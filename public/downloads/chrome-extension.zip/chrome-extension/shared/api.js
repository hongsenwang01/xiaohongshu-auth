// API 配置管理
// 用于管理不同环境的API地址

/**
 * API 环境配置
 */
export const API_ENDPOINTS = {
    // 前端开发环境
    DEVELOPMENT: {
        BASE_URL: 'https://tlbaslmldaqz.sealoshzh.site',
        ADMIN_PANEL: 'https://tlbaslmldaqz.sealoshzh.site/',
    },
    
    // 前端生产环境
    PRODUCTION: {
        BASE_URL: 'https://jikxqzcxtdxn.sealoshzh.site',
        ADMIN_PANEL: 'https://jikxqzcxtdxn.sealoshzh.site/',
    },
};

/**
 * 获取当前环境配置
 * @returns {object} 当前环境的API配置
 */
export function getEnvironmentConfig() {
    // 可以通过环境变量或其他方式来判断当前环境
    // 默认使用生产环境
    const isDevelopment = false; // 可根据需要修改为 true 使用开发环境， false 为生产环境
    
    return isDevelopment ? API_ENDPOINTS.DEVELOPMENT : API_ENDPOINTS.PRODUCTION;
}

/**
 * 获取管理员面板地址
 * @returns {string} 管理员面板URL
 */
export function getAdminPanelUrl() {
    const config = getEnvironmentConfig();
    return config.ADMIN_PANEL;
}

/**
 * 获取API基础地址
 * @returns {string} API基础URL
 */
export function getApiBaseUrl() {
    const config = getEnvironmentConfig();
    return config.BASE_URL;
}
