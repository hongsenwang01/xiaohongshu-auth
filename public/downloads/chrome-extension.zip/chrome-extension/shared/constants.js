// 共享常量定义

// 消息类型
export const MESSAGE_TYPES = {
    // Content Script 相关
    GET_POSTS: 'getPosts',
    LIKE_POST: 'likePost',
    COLLECT_POST: 'collectPost',
    FOLLOW_USER: 'followUser',
    COMMENT_POST: 'commentPost',
    GET_USER_INFO: 'getUserInfo',
    CHECK_USER_FOLLOWED: 'checkUserFollowed',
    
    // Background 相关
    START_BROWSE: 'startBrowse',
    STOP_BROWSE: 'stopBrowse',
    GET_BROWSE_STATE: 'getBrowseState',
    BROWSE_UPDATE: 'browseUpdate',
};

// 浏览更新事件类型
export const BROWSE_EVENT_TYPES = {
    STARTED: 'started',
    PROGRESS: 'progress',
    TAB_OPENED: 'tabOpened',
    TAB_CLOSED: 'tabClosed',
    LIKING: 'liking',
    LIKE_SUCCESS: 'likeSuccess',
    LIKE_ERROR: 'likeError',
    COLLECTING: 'collecting',
    COLLECT_SUCCESS: 'collectSuccess',
    COLLECT_ERROR: 'collectError',
    FOLLOWING: 'following',
    FOLLOW_SUCCESS: 'followSuccess',
    FOLLOW_ERROR: 'followError',
    COMMENTING: 'commenting',
    COMMENT_SUCCESS: 'commentSuccess',
    COMMENT_ERROR: 'commentError',
    ERROR: 'error',
    STOPPED: 'stopped',
    COMPLETED: 'completed',
};

// 时间常量（毫秒）
export const TIMING = {
    PAGE_LOAD_WAIT: 1000,        // 页面加载等待时间
    ACTION_WAIT: 500,             // 操作后等待时间
    INPUT_WAIT: 300,              // 输入后等待时间
    TAB_LOAD_EXTRA: 2000,         // 标签页加载额外等待
    TAB_LOAD_TIMEOUT: 10000,      // 标签页加载超时
    POST_BROWSE_TIME: 10000,      // 每个帖子浏览时间
    NEXT_POST_DELAY: 2000,        // 下一个帖子的延迟
    LIKE_DELAY_MIN: 1000,         // 点赞最小延迟
    LIKE_DELAY_MAX: 5000,         // 点赞最大延迟
    COLLECT_DELAY_MIN: 1000,      // 收藏最小延迟
    COLLECT_DELAY_MAX: 3000,      // 收藏最大延迟
    FOLLOW_DELAY_MIN: 1000,      // 关注最小延迟
    FOLLOW_DELAY_MAX: 3000,      // 关注最大延迟
    COMMENT_DELAY_MIN: 1000,      // 评论最小延迟
    COMMENT_DELAY_MAX: 2000,      // 评论最大延迟
    SUBMIT_BUTTON_WAIT: 5000,     // 等待发送按钮超时
};

// CSS选择器
export const SELECTORS = {
    // 帖子相关
    POST_ITEM: 'section.note-item',
    POST_LINK: 'a.cover.mask.ld',
    POST_TITLE: '.title span',
    POST_AUTHOR: '.author .name',
    POST_IMAGE: '.cover img',
    POST_LIKES: '.like-wrapper .count',
    
    // 互动区域
    ENGAGE_BAR: '.engage-bar',
    INTERACTIONS_BAR: '.interactions.engage-bar',
    
    // 按钮
    LIKE_WRAPPER: '.like-wrapper',
    COLLECT_WRAPPER: '.collect-wrapper',
    FOLLOW_BUTTON: '.note-detail-follow-btn button.follow-button',
    FOLLOW_DETAIL_CONTAINER: '.note-detail-follow-btn',
    LIKE_ICON: 'svg use[xlink\\:href="#like"], svg use[xlink\\:href="#liked"]',
    COLLECT_ICON: 'svg use[xlink\\:href="#collect"], svg use[xlink\\:href="#collected"]',
    USE_ELEMENT: 'use[xlink\\:href]',
    SUBMIT_BUTTON: 'button.btn.submit, button.submit, button[class*="submit"]',
    
    // 评论相关
    CONTENT_EDIT: '.content-edit',
    CONTENT_TEXTAREA: '#content-textarea',
    EDITABLE_P: 'p[contenteditable="true"]',
    COMMENT_AREA: '.comments-el, .comment-item, [class*="comment"]',
    
    // 用户信息
    USER_SIDEBAR: 'li.user.side-bar-component',
    USER_PROFILE_LINK: 'a[href^="/user/profile/"]',
    USER_AVATAR: '.avatar-wrapper img.user-image, .avatar img, img[class*="avatar"]',
    USER_NAME: '.user-name, [class*="user-name"]',
    USER_RED_ID: '.user-redId, [class*="redId"]',
    USER_IP: '.user-IP, .user-ip, [class*="user-IP"], [class*="user-ip"]',
    USER_DESC: '.user-desc, [class*="user-desc"]',
    USER_INTERACTIONS: '.user-interactions',
};

// 默认配置
export const DEFAULT_CONFIG = {
    COMMENT_CONTENT: '111',       // 默认评论内容
    MAX_LOGS: 50,                 // 最大日志条数
    TOAST_DURATION: 3000,         // 消息提示持续时间
    DEFAULT_BROWSE_COUNT: 10,     // 默认浏览数量
    MAX_BROWSE_COUNT: 100,        // 最大浏览数量
    MIN_BROWSE_COUNT: 1,          // 最小浏览数量
};

// 状态码
export const STATUS_ICONS = {
    LIKED: '#liked',
    LIKE: '#like',
    COLLECTED: '#collected',
    COLLECT: '#collect',
};

// 错误消息
export const ERROR_MESSAGES = {
    LIKE_BUTTON_NOT_FOUND: '未找到点赞按钮',
    COLLECT_BUTTON_NOT_FOUND: '未找到收藏按钮',
    FOLLOW_BUTTON_NOT_FOUND: '未找到关注按钮',
    COMMENT_INPUT_NOT_FOUND: '未找到评论输入框',
    COMMENT_AREA_NOT_FOUND: '未找到评论输入框区域',
    SUBMIT_BUTTON_NOT_FOUND: '发送按钮未出现',
    NOT_XHS_PAGE: '请在小红书页面使用此功能',
    NO_POSTS_FOUND: '没有找到帖子，请确保在小红书页面',
};

