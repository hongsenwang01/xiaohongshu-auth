// 浏览历史管理服务

/**
 * 历史记录配置
 */
const HISTORY_CONFIG = {
    RETENTION_DAYS: 1,                      // 保留天数
    STORAGE_KEY: 'browse_history',          // 存储键名
    MAX_RECORDS: 1000,                      // 最大记录数
};

/**
 * 生成窗口特定的历史记录键
 * @param {number|null} windowId - 窗口ID
 * @returns {string}
 */
function getWindowHistoryKey(windowId) {
    if (windowId) {
        return `${HISTORY_CONFIG.STORAGE_KEY}_window_${windowId}`;
    }
    return HISTORY_CONFIG.STORAGE_KEY; // 兼容旧版本
}

/**
 * 历史记录数据结构
 * @typedef {Object} HistoryRecord
 * @property {string} id - 记录ID
 * @property {string} postId - 帖子ID
 * @property {string} title - 帖子标题
 * @property {string} author - 作者
 * @property {string} link - 帖子链接
 * @property {string} fullUrl - 完整URL
 * @property {number} timestamp - 浏览时间戳
 * @property {string} date - 浏览日期（YYYY-MM-DD）
 * @property {string} time - 浏览时间（HH:mm:ss）
 * @property {boolean} liked - 是否点赞
 * @property {boolean} collected - 是否收藏
 * @property {boolean} followed - 是否关注
 * @property {boolean} commented - 是否评论
 * @property {string} commentContent - 评论内容
 * @property {string} likeStatus - 点赞状态（success/failed/skipped）
 * @property {string} collectStatus - 收藏状态
 * @property {string} followStatus - 关注状态
 * @property {string} commentStatus - 评论状态
 */

/**
 * 添加历史记录（按窗口ID隔离）
 * @param {Object} postInfo - 帖子信息
 * @param {Object} actions - 操作结果
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<void>}
 */
export async function addHistoryRecord(postInfo, actions, windowId = null) {
    try {
        const history = await getHistory(windowId);
        
        const record = {
            id: generateId(),
            postId: extractPostId(postInfo.link),
            title: postInfo.title,
            author: postInfo.author,
            link: postInfo.link,
            fullUrl: postInfo.fullUrl,
            image: postInfo.image || '',
            likes: postInfo.likes || '0',
            timestamp: Date.now(),
            date: formatDate(new Date()),
            time: formatTime(new Date()),
            liked: actions.liked || false,
            collected: actions.collected || false,
            followed: actions.followed || false,
            commented: actions.commented || false,
            commentContent: actions.commentContent || '',
            likeStatus: actions.likeStatus || 'unknown',
            collectStatus: actions.collectStatus || 'unknown',
            followStatus: actions.followStatus || 'unknown',
            commentStatus: actions.commentStatus || 'unknown',
        };
        
        // 添加到历史记录开头
        history.unshift(record);
        
        // 限制记录数量
        if (history.length > HISTORY_CONFIG.MAX_RECORDS) {
            history.splice(HISTORY_CONFIG.MAX_RECORDS);
        }
        
        await saveHistory(history, windowId);
        
        console.log('[History] ✅ 添加历史记录:', record.title, { windowId });
    } catch (error) {
        console.error('[History] ❌ 添加历史记录失败:', error);
    }
}

/**
 * 获取历史记录（按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<Array<HistoryRecord>>}
 */
export async function getHistory(windowId = null) {
    try {
        const storageKey = getWindowHistoryKey(windowId);
        const result = await chrome.storage.local.get([storageKey]);
        const history = result[storageKey] || [];
        
        // 清理过期记录
        const cleaned = cleanExpiredRecords(history);
        
        if (cleaned.length !== history.length) {
            await saveHistory(cleaned, windowId);
        }
        
        return cleaned;
    } catch (error) {
        console.error('[History] ❌ 获取历史记录失败:', error);
        return [];
    }
}

/**
 * 保存历史记录（按窗口ID隔离）
 * @param {Array<HistoryRecord>} history - 历史记录数组
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<void>}
 */
async function saveHistory(history, windowId = null) {
    try {
        const storageKey = getWindowHistoryKey(windowId);
        await chrome.storage.local.set({
            [storageKey]: history
        });
    } catch (error) {
        console.error('[History] ❌ 保存历史记录失败:', error);
    }
}

/**
 * 清理过期记录
 * @param {Array<HistoryRecord>} history - 历史记录数组
 * @returns {Array<HistoryRecord>}
 */
function cleanExpiredRecords(history) {
    const now = Date.now();
    const retentionMs = HISTORY_CONFIG.RETENTION_DAYS * 24 * 60 * 60 * 1000;
    
    return history.filter(record => {
        const age = now - record.timestamp;
        return age < retentionMs;
    });
}

/**
 * 清空历史记录（按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID，如果为null则清除所有窗口的历史
 * @returns {Promise<void>}
 */
export async function clearHistory(windowId = null) {
    try {
        if (windowId) {
            // 清除指定窗口的历史
            const storageKey = getWindowHistoryKey(windowId);
            await chrome.storage.local.remove([storageKey]);
            console.log('[History] 🗑️ 历史记录已清空', { windowId });
        } else {
            // 清除所有窗口的历史
            const allData = await chrome.storage.local.get(null);
            const keysToRemove = Object.keys(allData).filter(key => 
                key.startsWith(HISTORY_CONFIG.STORAGE_KEY)
            );
            
            if (keysToRemove.length > 0) {
                await chrome.storage.local.remove(keysToRemove);
                console.log('[History] 🗑️ 所有窗口的历史记录已清空', { count: keysToRemove.length });
            }
        }
    } catch (error) {
        console.error('[History] ❌ 清空历史记录失败:', error);
    }
}

/**
 * 获取历史统计（按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<Object>}
 */
export async function getHistoryStats(windowId = null) {
    try {
        const history = await getHistory(windowId);
        
        const stats = {
            total: history.length,
            liked: history.filter(r => r.liked).length,
            collected: history.filter(r => r.collected).length,
            commented: history.filter(r => r.commented).length,
            today: history.filter(r => r.date === formatDate(new Date())).length,
        };
        
        return stats;
    } catch (error) {
        console.error('[History] ❌ 获取统计失败:', error);
        return {
            total: 0,
            liked: 0,
            collected: 0,
            commented: 0,
            today: 0,
        };
    }
}

/**
 * 导出为CSV格式（按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<string>}
 */
export async function exportToCSV(windowId = null) {
    try {
        const history = await getHistory(windowId);
        
        // CSV表头
        const headers = [
            '序号',
            '帖子标题',
            '作者',
            '浏览日期',
            '浏览时间',
            '是否点赞',
            '点赞状态',
            '是否收藏',
            '收藏状态',
            '是否关注',
            '关注状态',
            '是否评论',
            '评论状态',
            '评论内容',
            '帖子链接'
        ];
        
        // 转换数据
        const rows = history.map((record, index) => [
            index + 1,
            `"${record.title.replace(/"/g, '""')}"`,
            `"${record.author.replace(/"/g, '""')}"`,
            record.date,
            record.time,
            record.liked ? '是' : '否',
            getStatusText(record.likeStatus),
            record.collected ? '是' : '否',
            getStatusText(record.collectStatus),
            record.followed ? '是' : '否',
            getStatusText(record.followStatus),
            record.commented ? '是' : '否',
            getStatusText(record.commentStatus),
            `"${(record.commentContent || '').replace(/"/g, '""')}"`,
            record.fullUrl
        ]);
        
        // 组装CSV
        const csv = [
            headers.join(','),
            ...rows.map(row => row.join(','))
        ].join('\n');
        
        // 添加BOM以支持中文
        return '\uFEFF' + csv;
    } catch (error) {
        console.error('[History] ❌ 导出CSV失败:', error);
        throw error;
    }
}

/**
 * 下载文件
 * @param {string} content - 文件内容
 * @param {string} filename - 文件名
 * @param {string} mimeType - MIME类型
 */
export function downloadFile(content, filename, mimeType = 'text/csv') {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
}

/**
 * 导出历史记录（触发下载）
 * @param {string} format - 格式（csv/excel）
 * @param {number|null} windowId - 窗口ID
 * @param {string} accountName - 账号名称（用于文件名）
 * @returns {Promise<void>}
 */
export async function exportHistory(format = 'csv', windowId = null, accountName = '') {
    try {
        const timestamp = formatDateTime(new Date());
        
        // 构建文件名，包含账号信息
        let filename;
        if (accountName) {
            // 清理账号名中的特殊字符
            const cleanAccountName = accountName.replace(/[<>:"/\\|?*]/g, '_');
            filename = `小红书浏览历史_${cleanAccountName}_${timestamp}.csv`;
        } else {
            filename = `小红书浏览历史_${timestamp}.csv`;
        }
        
        if (format === 'csv') {
            const csv = await exportToCSV(windowId);
            downloadFile(csv, filename, 'text/csv;charset=utf-8;');
        } else {
            throw new Error('暂不支持此格式');
        }
        
        console.log('[History] ✅ 导出成功:', filename, { windowId, accountName });
    } catch (error) {
        console.error('[History] ❌ 导出失败:', error);
        throw error;
    }
}

// ===== 工具函数 =====

/**
 * 生成唯一ID
 * @returns {string}
 */
function generateId() {
    return `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * 从链接提取帖子ID
 * @param {string} link - 帖子链接
 * @returns {string}
 */
function extractPostId(link) {
    const match = link.match(/\/explore\/([^?]+)/);
    return match ? match[1] : '';
}

/**
 * 格式化日期
 * @param {Date} date - 日期对象
 * @returns {string} YYYY-MM-DD
 */
function formatDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

/**
 * 格式化时间
 * @param {Date} date - 日期对象
 * @returns {string} HH:mm:ss
 */
function formatTime(date) {
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
}

/**
 * 格式化日期时间（用于文件名）
 * @param {Date} date - 日期对象
 * @returns {string} YYYYMMDD_HHmmss
 */
function formatDateTime(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${year}${month}${day}_${hours}${minutes}${seconds}`;
}

/**
 * 获取状态文本
 * @param {string} status - 状态码
 * @returns {string}
 */
function getStatusText(status) {
    const statusMap = {
        'success': '成功',
        'failed': '失败',
        'skipped': '已有',
        'disabled': '跳过',
        'unknown': '未知',
    };
    return statusMap[status] || '未知';
}

