// 浏览历史管理服务

/**
 * 历史记录配置
 */
const HISTORY_CONFIG = {
    RETENTION_DAYS: 1,                      // 保留天数
    STORAGE_KEY: 'browse_history',          // 存储键名
    MAX_RECORDS: 1000,                      // 最大记录数
};

/**
 * 生成窗口特定的历史记录键
 * @param {number|null} windowId - 窗口ID
 * @returns {string}
 */
function getWindowHistoryKey(windowId) {
    if (windowId) {
        return `${HISTORY_CONFIG.STORAGE_KEY}_window_${windowId}`;
    }
    return HISTORY_CONFIG.STORAGE_KEY; // 兼容旧版本
}

/**
 * 历史记录数据结构
 * @typedef {Object} HistoryRecord
 * @property {string} id - 记录ID
 * @property {string} postId - 帖子ID
 * @property {string} title - 帖子标题
 * @property {string} author - 作者
 * @property {string} link - 帖子链接
 * @property {string} fullUrl - 完整URL
 * @property {number} timestamp - 浏览时间戳
 * @property {string} date - 浏览日期（YYYY-MM-DD）
 * @property {string} time - 浏览时间（HH:mm:ss）
 * @property {boolean} liked - 是否点赞
 * @property {boolean} collected - 是否收藏
 * @property {boolean} followed - 是否关注
 * @property {boolean} commented - 是否评论
 * @property {string} commentContent - 评论内容
 * @property {string} likeStatus - 点赞状态（success/failed/skipped）
 * @property {string} collectStatus - 收藏状态
 * @property {string} followStatus - 关注状态
 * @property {string} commentStatus - 评论状态
 */

/**
 * 添加历史记录（按窗口ID隔离）
 * @param {Object} postInfo - 帖子信息
 * @param {Object} actions - 操作结果
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<void>}
 */
export async function addHistoryRecord(postInfo, actions, windowId = null) {
    try {
        const history = await getHistory(windowId);
        
        const record = {
            id: generateId(),
            postId: extractPostId(postInfo.link),
            title: postInfo.title,
            author: postInfo.author,
            link: postInfo.link,
            fullUrl: postInfo.fullUrl,
            image: postInfo.image || '',
            likes: postInfo.likes || '0',
            timestamp: Date.now(),
            date: formatDate(new Date()),
            time: formatTime(new Date()),
            liked: actions.liked || false,
            collected: actions.collected || false,
            followed: actions.followed || false,
            commented: actions.commented || false,
            commentContent: actions.commentContent || '',
            likeStatus: actions.likeStatus || 'unknown',
            collectStatus: actions.collectStatus || 'unknown',
            followStatus: actions.followStatus || 'unknown',
            commentStatus: actions.commentStatus || 'unknown',
            isFocused: postInfo.isFocused || false,  // 是否重点关注
        };
        
        // 添加到历史记录开头
        history.unshift(record);
        
        // 限制记录数量
        if (history.length > HISTORY_CONFIG.MAX_RECORDS) {
            history.splice(HISTORY_CONFIG.MAX_RECORDS);
        }
        
        await saveHistory(history, windowId);
        
        console.log('[History] ✅ 添加历史记录:', record.title, { windowId });
    } catch (error) {
        console.error('[History] ❌ 添加历史记录失败:', error);
    }
}

/**
 * 获取历史记录（按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<Array<HistoryRecord>>}
 */
export async function getHistory(windowId = null) {
    try {
        const storageKey = getWindowHistoryKey(windowId);
        const result = await chrome.storage.local.get([storageKey]);
        const history = result[storageKey] || [];
        
        // 清理过期记录
        const cleaned = cleanExpiredRecords(history);
        
        if (cleaned.length !== history.length) {
            await saveHistory(cleaned, windowId);
        }
        
        return cleaned;
    } catch (error) {
        console.error('[History] ❌ 获取历史记录失败:', error);
        return [];
    }
}

/**
 * 保存历史记录（按窗口ID隔离）
 * @param {Array<HistoryRecord>} history - 历史记录数组
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<void>}
 */
async function saveHistory(history, windowId = null) {
    try {
        const storageKey = getWindowHistoryKey(windowId);
        await chrome.storage.local.set({
            [storageKey]: history
        });
    } catch (error) {
        console.error('[History] ❌ 保存历史记录失败:', error);
    }
}

/**
 * 清理过期记录
 * @param {Array<HistoryRecord>} history - 历史记录数组
 * @returns {Array<HistoryRecord>}
 */
function cleanExpiredRecords(history) {
    const now = Date.now();
    const retentionMs = HISTORY_CONFIG.RETENTION_DAYS * 24 * 60 * 60 * 1000;
    
    return history.filter(record => {
        const age = now - record.timestamp;
        return age < retentionMs;
    });
}

/**
 * 清空历史记录（按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID，如果为null则清除所有窗口的历史
 * @returns {Promise<void>}
 */
export async function clearHistory(windowId = null) {
    try {
        if (windowId) {
            // 清除指定窗口的历史
            const storageKey = getWindowHistoryKey(windowId);
            await chrome.storage.local.remove([storageKey]);
            console.log('[History] 🗑️ 历史记录已清空', { windowId });
        } else {
            // 清除所有窗口的历史
            const allData = await chrome.storage.local.get(null);
            const keysToRemove = Object.keys(allData).filter(key => 
                key.startsWith(HISTORY_CONFIG.STORAGE_KEY)
            );
            
            if (keysToRemove.length > 0) {
                await chrome.storage.local.remove(keysToRemove);
                console.log('[History] 🗑️ 所有窗口的历史记录已清空', { count: keysToRemove.length });
            }
        }
    } catch (error) {
        console.error('[History] ❌ 清空历史记录失败:', error);
    }
}

/**
 * 获取历史统计（按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<Object>}
 */
export async function getHistoryStats(windowId = null) {
    try {
        const history = await getHistory(windowId);
        
        const stats = {
            total: history.length,
            liked: history.filter(r => r.liked).length,
            collected: history.filter(r => r.collected).length,
            commented: history.filter(r => r.commented).length,
            today: history.filter(r => r.date === formatDate(new Date())).length,
        };
        
        return stats;
    } catch (error) {
        console.error('[History] ❌ 获取统计失败:', error);
        return {
            total: 0,
            liked: 0,
            collected: 0,
            commented: 0,
            today: 0,
        };
    }
}


/**
 * 导出为Excel格式（按作者分组，按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<Blob>}
 */
export async function exportToExcel(windowId = null) {
    try {
        const history = await getHistory(windowId);
        
        // 按作者分组
        const groupedByAuthor = {};
        history.forEach(record => {
            const author = record.author || '未知作者';
            if (!groupedByAuthor[author]) {
                groupedByAuthor[author] = [];
            }
            groupedByAuthor[author].push(record);
        });
        
        // 按每个作者的帖子数量排序
        const sortedAuthors = Object.keys(groupedByAuthor).sort((a, b) => {
            return groupedByAuthor[b].length - groupedByAuthor[a].length;
        });
        
        // 生成表头
        const headers = [
            '作者',
            '帖子数',
            '重点关注',
            '帖子标题',
            '浏览日期',
            '浏览时间',
            '点赞',
            '收藏',
            '关注',
            '评论',
            '评论内容',
            '帖子链接'
        ];
        
        const headerCells = headers.map(h => 
            `<Cell><Data ss:Type="String">${escapeXml(h)}</Data></Cell>`
        ).join('');
        
        // 生成数据行
        let dataRows = '';
        let rowIndex = 0;
        
        sortedAuthors.forEach(author => {
            const posts = groupedByAuthor[author];
            const postCount = posts.length;
            
            // 检查是否有重点关注的帖子
            const hasFocused = posts.some(p => p.isFocused);
            const focusedCount = posts.filter(p => p.isFocused).length;
            const focusText = hasFocused ? `是(${focusedCount}/${postCount}次×10)` : '否';
            
            posts.forEach((record, index) => {
                rowIndex++;
                const isFirstRow = index === 0;
                
                // 第一行显示作者信息，后续行合并
                const authorCell = isFirstRow 
                    ? `<Cell ss:MergeDown="${postCount - 1}"><Data ss:Type="String">${escapeXml(author)}</Data></Cell>`
                    : '';
                
                const postCountCell = isFirstRow
                    ? `<Cell ss:MergeDown="${postCount - 1}"><Data ss:Type="Number">${postCount}</Data></Cell>`
                    : '';
                
                const focusCell = isFirstRow
                    ? `<Cell ss:MergeDown="${postCount - 1}"><Data ss:Type="String">${escapeXml(focusText)}</Data></Cell>`
                    : '';
                
                // 只在第一行输出作者、帖子数、重点关注
                if (isFirstRow) {
                    dataRows += `<Row>
                        ${authorCell}
                        ${postCountCell}
                        ${focusCell}
                        <Cell><Data ss:Type="String">${escapeXml(record.title)}</Data></Cell>
                        <Cell><Data ss:Type="String">${record.date}</Data></Cell>
                        <Cell><Data ss:Type="String">${record.time}</Data></Cell>
                        <Cell><Data ss:Type="String">${record.liked ? '✓' : ''}</Data></Cell>
                        <Cell><Data ss:Type="String">${record.collected ? '✓' : ''}</Data></Cell>
                        <Cell><Data ss:Type="String">${record.followed ? '✓' : ''}</Data></Cell>
                        <Cell><Data ss:Type="String">${record.commented ? '✓' : ''}</Data></Cell>
                        <Cell><Data ss:Type="String">${escapeXml(record.commentContent || '')}</Data></Cell>
                        <Cell><Data ss:Type="String">${escapeXml(record.fullUrl)}</Data></Cell>
                    </Row>`;
                } else {
                    dataRows += `<Row>
                        <Cell ss:Index="4"><Data ss:Type="String">${escapeXml(record.title)}</Data></Cell>
                        <Cell><Data ss:Type="String">${record.date}</Data></Cell>
                        <Cell><Data ss:Type="String">${record.time}</Data></Cell>
                        <Cell><Data ss:Type="String">${record.liked ? '✓' : ''}</Data></Cell>
                        <Cell><Data ss:Type="String">${record.collected ? '✓' : ''}</Data></Cell>
                        <Cell><Data ss:Type="String">${record.followed ? '✓' : ''}</Data></Cell>
                        <Cell><Data ss:Type="String">${record.commented ? '✓' : ''}</Data></Cell>
                        <Cell><Data ss:Type="String">${escapeXml(record.commentContent || '')}</Data></Cell>
                        <Cell><Data ss:Type="String">${escapeXml(record.fullUrl)}</Data></Cell>
                    </Row>`;
                }
            });
        });
        
        // 生成完整的Excel XML
        const xml = `<?xml version="1.0"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
 <Worksheet ss:Name="浏览历史">
  <Table>
   <Row>${headerCells}</Row>
   ${dataRows}
  </Table>
 </Worksheet>
</Workbook>`;
        
        return new Blob([xml], { type: 'application/vnd.ms-excel' });
    } catch (error) {
        console.error('[History] ❌ 导出Excel失败:', error);
        throw error;
    }
}

/**
 * XML转义函数
 */
function escapeXml(str) {
    return String(str || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;');
}


/**
 * 导出历史记录为Excel（触发下载）
 * @param {string} format - 格式（保留参数兼容性，实际只支持excel）
 * @param {number|null} windowId - 窗口ID
 * @param {string} accountName - 账号名称（用于文件名）
 * @returns {Promise<void>}
 */
export async function exportHistory(format = 'excel', windowId = null, accountName = '') {
    try {
        const timestamp = formatDateTime(new Date());
        
        // 构建文件名，包含账号信息
        let filename;
        
        if (accountName) {
            // 清理账号名中的特殊字符
            const cleanAccountName = accountName.replace(/[<>:"/\\|?*]/g, '_');
            filename = `小红书浏览历史_${cleanAccountName}_${timestamp}.xls`;
        } else {
            filename = `小红书浏览历史_${timestamp}.xls`;
        }
        
        // 导出Excel
        const blob = await exportToExcel(windowId);
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();
        URL.revokeObjectURL(url);
        
        console.log('[History] ✅ Excel导出成功:', filename, { windowId, accountName });
    } catch (error) {
        console.error('[History] ❌ 导出失败:', error);
        throw error;
    }
}

// ===== 工具函数 =====

/**
 * 生成唯一ID
 * @returns {string}
 */
function generateId() {
    return `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * 从链接提取帖子ID
 * @param {string} link - 帖子链接
 * @returns {string}
 */
function extractPostId(link) {
    const match = link.match(/\/explore\/([^?]+)/);
    return match ? match[1] : '';
}

/**
 * 格式化日期
 * @param {Date} date - 日期对象
 * @returns {string} YYYY-MM-DD
 */
function formatDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

/**
 * 格式化时间
 * @param {Date} date - 日期对象
 * @returns {string} HH:mm:ss
 */
function formatTime(date) {
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
}

/**
 * 格式化日期时间（用于文件名）
 * @param {Date} date - 日期对象
 * @returns {string} YYYYMMDD_HHmmss
 */
function formatDateTime(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${year}${month}${day}_${hours}${minutes}${seconds}`;
}

/**
 * 获取状态文本
 * @param {string} status - 状态码
 * @returns {string}
 */
function getStatusText(status) {
    const statusMap = {
        'success': '成功',
        'failed': '失败',
        'skipped': '已有',
        'disabled': '跳过',
        'unknown': '未知',
    };
    return statusMap[status] || '未知';
}

