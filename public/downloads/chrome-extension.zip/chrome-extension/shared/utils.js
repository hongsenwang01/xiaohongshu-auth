// 共享工具函数

/**
 * 延迟函数
 * @param {number} ms - 延迟时间（毫秒）
 * @returns {Promise<void>}
 */
export function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * 生成随机延迟时间
 * @param {number} min - 最小延迟（毫秒）
 * @param {number} max - 最大延迟（毫秒）
 * @returns {number}
 */
export function randomDelay(min, max) {
    return min + Math.floor(Math.random() * (max - min));
}

/**
 * 格式化时间
 * @param {Date} date - 日期对象
 * @returns {string} - 格式化的时间字符串
 */
export function formatTime(date = new Date()) {
    return date.toLocaleTimeString('zh-CN', { 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit' 
    });
}

/**
 * 检查是否在评论区内
 * @param {Element} element - DOM元素
 * @returns {boolean}
 */
export function isInCommentArea(element) {
    return !!(
        element.closest('.comments-el') || 
        element.closest('.comment-item') ||
        element.closest('[class*="comment"]')
    );
}

/**
 * 获取响应结果对象
 * @param {boolean} success - 是否成功
 * @param {*} data - 数据或错误信息
 * @returns {Object}
 */
export function createResponse(success, data) {
    if (success) {
        return {
            success: true,
            data: data
        };
    } else {
        return {
            success: false,
            error: typeof data === 'string' ? data : data.message
        };
    }
}

