// 状态管理服务
import { sendToBackground } from './message.js';
import { MESSAGE_TYPES } from '../../shared/constants.js';

// 存储当前 popup 窗口的任务 ID
let currentTaskId = null;

/**
 * 获取当前任务 ID
 * @returns {string|null}
 */
export function getCurrentTaskId() {
    return currentTaskId;
}

/**
 * 设置当前任务 ID
 * @param {string} taskId - 任务ID
 */
export function setCurrentTaskId(taskId) {
    currentTaskId = taskId;
    // 保存到 sessionStorage，以便 popup 关闭后重新打开时恢复
    if (taskId) {
        sessionStorage.setItem('currentTaskId', taskId);
    } else {
        sessionStorage.removeItem('currentTaskId');
    }
}

/**
 * 从 sessionStorage 恢复任务 ID
 */
export function restoreTaskId() {
    const savedTaskId = sessionStorage.getItem('currentTaskId');
    if (savedTaskId) {
        currentTaskId = savedTaskId;
        return savedTaskId;
    }
    return null;
}

/**
 * 获取浏览状态
 * @param {string} taskId - 任务ID（可选）
 * @returns {Promise<Object|null>}
 */
export async function getBrowseState(taskId = null) {
    try {
        const request = { action: MESSAGE_TYPES.GET_BROWSE_STATE };
        if (taskId) {
            request.taskId = taskId;
        }
        
        const response = await sendToBackground(request);
        
        if (response.success && response.state) {
            return response.state;
        }
        return null;
    } catch (error) {
        console.error('获取浏览状态失败:', error);
        return null;
    }
}
/**
 * 获取当前窗口ID
 * @returns {Promise<number|null>}
 */
async function getCurrentWindowId() {
    try {
        // 获取当前窗口信息
        const currentWindow = await chrome.windows.getCurrent();
        return currentWindow.id;
    } catch (error) {
        console.error('获取窗口ID失败:', error);
        return null;
    }
}

/**
 * 开始浏览任务
 * @param {Array} posts - 帖子列表
 * @param {Object} config - 自动化配置
 * @returns {Promise<{success: boolean, taskId?: string}>}
 */
export async function startBrowseTask(posts, config = {}) {
    try {
        // 获取当前窗口ID
        const windowId = await getCurrentWindowId();
        console.log('当前窗口ID:', windowId);
        
        const response = await sendToBackground({
            action: MESSAGE_TYPES.START_BROWSE,
            posts: posts,
            config: config,
            windowId: windowId // 传递窗口ID
        });
        
        if (response.success && response.taskId) {
            // 保存任务 ID
            setCurrentTaskId(response.taskId);
            //console.log(`✅ 任务已创建并绑定到窗口 ${windowId}`);
            return { success: true, taskId: response.taskId };
        }
        
        return { success: false };
    } catch (error) {
        console.error('开始浏览失败:', error);
        return { success: false };
    }
}

/**
 * 停止浏览任务
 * @param {string} taskId - 任务ID（可选，默认使用当前任务ID）
 * @returns {Promise<boolean>}
 */
export async function stopBrowseTask(taskId = null) {
    try {
        const idToStop = taskId || currentTaskId;
        if (!idToStop) {
            console.warn('没有正在运行的任务ID');
            return false;
        }
        
        const response = await sendToBackground({
            action: MESSAGE_TYPES.STOP_BROWSE,
            taskId: idToStop
        });
        
        if (response.success) {
            // 清除任务 ID
            if (idToStop === currentTaskId) {
                setCurrentTaskId(null);
            }
        }
        
        return response.success;
    } catch (error) {
        console.error('停止浏览失败:', error);
        return false;
    }
}

