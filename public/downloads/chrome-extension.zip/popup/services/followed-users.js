/**
 * 已关注用户列表管理模块
 * 用于保存、加载、导出已关注的用户信息
 * 按窗口ID隔离存储
 */

import { generateFilterTemplate, downloadTemplate } from '../../shared/excel-templates.js';

const STORAGE_KEY_BASE = 'followedUsersList';

/**
 * 生成窗口特定的存储键
 * @param {number|null} windowId - 窗口ID
 * @returns {string}
 */
function getWindowStorageKey(windowId) {
    if (windowId) {
        return `${STORAGE_KEY_BASE}_window_${windowId}`;
    }
    return STORAGE_KEY_BASE; // 兼容旧版本（无窗口ID）
}

/**
 * 添加用户到已关注列表（按窗口ID隔离）
 * @param {Object} userInfo - 用户信息
 * @param {string} userInfo.userId - 用户ID
 * @param {string} userInfo.userName - 用户昵称
 * @param {string} userInfo.userUrl - 用户主页URL
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<void>}
 */
export async function addFollowedUser(userInfo, windowId = null) {
    try {
        const list = await getFollowedUsers(windowId);
        
        // 检查是否已存在（使用userId去重）
        const exists = list.some(user => user.userId === userInfo.userId);
        if (exists) {
            console.log('[FollowedUsers] 用户已在列表中:', userInfo.userName, { windowId });
            return;
        }
        
        // 添加到列表
        list.push({
            userId: userInfo.userId,
            userName: userInfo.userName,
            userUrl: userInfo.userUrl,
            followedAt: new Date().toISOString()
        });
        
        // 保存到存储
        await saveFollowedUsers(list, windowId);
        console.log('[FollowedUsers] 添加用户成功:', userInfo.userName, { windowId });
    } catch (error) {
        console.error('[FollowedUsers] 添加用户失败:', error);
        throw error;
    }
}

/**
 * 获取已关注用户列表（按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<Array>}
 */
export async function getFollowedUsers(windowId = null) {
    return new Promise((resolve, reject) => {
        const storageKey = getWindowStorageKey(windowId);
        chrome.storage.local.get([storageKey], (result) => {
            if (chrome.runtime.lastError) {
                reject(new Error('读取失败: ' + chrome.runtime.lastError.message));
            } else {
                resolve(result[storageKey] || []);
            }
        });
    });
}

/**
 * 获取已关注用户的ID列表（用于快速过滤，按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<Array<string>>}
 */
export async function getFollowedUserIds(windowId = null) {
    const list = await getFollowedUsers(windowId);
    return list.map(user => user.userId);
}

/**
 * 获取已关注用户的昵称列表（用于快速过滤，按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<Array<string>>}
 */
export async function getFollowedUserNames(windowId = null) {
    const list = await getFollowedUsers(windowId);
    return list.map(user => user.userName);
}

/**
 * 保存已关注用户列表（按窗口ID隔离）
 * @param {Array} list - 用户列表
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<void>}
 */
async function saveFollowedUsers(list, windowId = null) {
    return new Promise((resolve, reject) => {
        const storageKey = getWindowStorageKey(windowId);
        chrome.storage.local.set({ [storageKey]: list }, () => {
            if (chrome.runtime.lastError) {
                reject(new Error('保存失败: ' + chrome.runtime.lastError.message));
            } else {
                resolve();
            }
        });
    });
}

/**
 * 从Excel导入已关注用户列表（按窗口ID隔离）
 * @param {Array} entries - Excel中解析的用户数据，可以是昵称数组或对象数组
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<number>} 新增的用户数量
 */
export async function importFollowedUsers(entries, windowId = null) {
    try {
        const existingList = await getFollowedUsers(windowId);
        const existingUserNames = new Set(existingList.map(u => u.userName));
        
        // 转换格式并去重
        let addedCount = 0;
        for (const entry of entries) {
            // 支持多种格式：字符串（纯昵称）或对象（{nickname, redId}）
            let userName;
            if (typeof entry === 'string') {
                userName = entry.trim();
            } else if (entry && entry.nickname) {
                userName = entry.nickname.trim();
            } else {
                continue;
            }
            
            if (!userName) continue;
            
            // 使用昵称作为唯一标识
            if (!existingUserNames.has(userName)) {
                existingList.push({
                    userId: userName, // 使用昵称作为ID
                    userName: userName,
                    userUrl: '',
                    followedAt: new Date().toISOString(),
                    importedFromExcel: true
                });
                existingUserNames.add(userName);
                addedCount++;
            }
        }
        
        await saveFollowedUsers(existingList, windowId);
        console.log(`[FollowedUsers] 导入完成，新增 ${addedCount} 个用户`, { windowId });
        return addedCount;
    } catch (error) {
        console.error('[FollowedUsers] 导入失败:', error);
        throw error;
    }
}

/**
 * 解析已关注用户列表的Excel文件（只包含昵称列）
 * @param {File} file - Excel文件
 * @returns {Promise<Array<string>>} 昵称数组
 */
export async function parseFollowedUsersExcel(file) {
    return new Promise((resolve, reject) => {
        const name = (file?.name || '').toLowerCase();
        if (!name.endsWith('.xls')) {
            reject(new Error('请上传Excel(.xls)文件'));
            return;
        }
        
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const xml = decodeToText(e.target.result);
                const usernames = parseSpreadsheetMLForUsernames(xml);
                resolve(usernames);
            } catch (err) {
                reject(new Error('文件解析失败: ' + err.message));
            }
        };
        reader.onerror = () => reject(new Error('文件读取失败'));
        reader.readAsArrayBuffer(file);
    });
}

// 解析SpreadsheetML，提取昵称列
function parseSpreadsheetMLForUsernames(xml) {
    const usernames = [];
    const rowRegex = /<Row[\s\S]*?>[\s\S]*?<\/Row>/gi;
    let m;
    const rows = [];
    
    while ((m = rowRegex.exec(xml)) !== null) {
        rows.push(m[0]);
    }
    
    if (rows.length <= 1) return usernames; // 只有表头或空文件
    
    // 从第二行开始（跳过表头）
    for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        const cellRegex = /<Cell[\s\S]*?>[\s\S]*?<\/Cell>/gi;
        const cells = [];
        let cm;
        
        while ((cm = cellRegex.exec(row)) !== null) {
            const cellXml = cm[0];
            const dataMatch = cellXml.match(/<Data[\s\S]*?>([\s\S]*?)<\/Data>/i);
            const val = dataMatch ? unescapeXml(dataMatch[1]).trim() : '';
            cells.push(val);
        }
        
        // 只取第一列（昵称）
        const nickname = (cells[0] || '').trim();
        if (nickname) {
            usernames.push(nickname);
        }
    }
    
    return usernames;
}

// 解码文本
function decodeToText(arrayBuffer) {
    const bytes = new Uint8Array(arrayBuffer);
    if (bytes.length >= 2 && bytes[0] === 0xFF && bytes[1] === 0xFE) {
        return new TextDecoder('utf-16le').decode(bytes);
    }
    if (bytes.length >= 2 && bytes[0] === 0xFE && bytes[1] === 0xFF) {
        return new TextDecoder('utf-16be').decode(bytes);
    }
    try { 
        return new TextDecoder('utf-8', { fatal: true }).decode(bytes); 
    } catch {}
    return new TextDecoder('utf-8', { fatal: false }).decode(bytes);
}

// XML反转义
function unescapeXml(s) {
    return String(s || '')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&apos;/g, "'")
        .replace(/&amp;/g, '&');
}

/**
 * 导出已关注用户列表为Excel（只包含昵称列，按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<void>}
 */
export async function exportFollowedUsers(windowId = null) {
    try {
        const list = await getFollowedUsers(windowId);
        
        if (list.length === 0) {
            throw new Error('没有已关注的用户可以导出');
        }
        
        // 生成Excel XML - 只保留昵称列
        const headers = ['小红书昵称'];
        const headerCells = headers.map(v => `<Cell><Data ss:Type="String">${escapeXml(v)}</Data></Cell>`).join('');
        
        // 生成数据行 - 只包含昵称
        const dataRows = list.map(user => {
            const cells = [escapeXml(user.userName || '')];
            return `<Row>${cells.map(c => `<Cell><Data ss:Type="String">${c}</Data></Cell>`).join('')}</Row>`;
        }).join('');
        
        const xml = `<?xml version="1.0"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
 <Worksheet ss:Name="已关注用户列表">
  <Table>
   <Row>${headerCells}</Row>
   ${dataRows}
  </Table>
 </Worksheet>
</Workbook>`;
        
        const blob = new Blob([xml], { type: 'application/vnd.ms-excel' });
        const windowSuffix = windowId ? `_窗口${windowId}` : '';
        const filename = `已关注用户列表${windowSuffix}_${new Date().toLocaleDateString('zh-CN').replace(/\//g, '-')}.xls`;
        downloadTemplate(blob, filename);
        
        console.log('[FollowedUsers] 导出成功:', filename, { windowId });
    } catch (error) {
        console.error('[FollowedUsers] 导出失败:', error);
        throw error;
    }
}

/**
 * 清除已关注用户列表（按窗口ID隔离）
 * @param {number|null} windowId - 窗口ID，如果为null则清除所有窗口的列表
 * @returns {Promise<void>}
 */
export async function clearFollowedUsers(windowId = null) {
    return new Promise(async (resolve, reject) => {
        try {
            if (windowId) {
                // 清除指定窗口的列表
                const storageKey = getWindowStorageKey(windowId);
                await chrome.storage.local.remove(storageKey);
                console.log('[FollowedUsers] 已清除指定窗口的已关注用户', { windowId });
                resolve();
            } else {
                // 清除所有窗口的列表
                const allData = await chrome.storage.local.get(null);
                const keysToRemove = Object.keys(allData).filter(key => 
                    key.startsWith(STORAGE_KEY_BASE)
                );
                
                if (keysToRemove.length > 0) {
                    await chrome.storage.local.remove(keysToRemove);
                    console.log('[FollowedUsers] 已清除所有窗口的已关注用户', { count: keysToRemove.length });
                }
                resolve();
            }
        } catch (error) {
            reject(new Error('清除失败: ' + error.message));
        }
    });
}

/**
 * 检查用户是否已在关注列表中（按窗口ID隔离）
 * @param {string} userId - 用户ID
 * @param {number|null} windowId - 窗口ID
 * @returns {Promise<boolean>}
 */
export async function isUserFollowed(userId, windowId = null) {
    const list = await getFollowedUsers(windowId);
    return list.some(user => user.userId === userId);
}

// XML转义函数
function escapeXml(s) {
    return String(s || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;');
}

