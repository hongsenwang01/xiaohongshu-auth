// 历史记录处理器
import { getHistory, getHistoryStats, exportHistory, clearHistory } from '../../shared/history.js';
import { showToast } from '../ui/toast.js';
import { getCachedUserInfo } from '../services/cache.js';

/**
 * 获取当前窗口ID
 * @returns {Promise<number|null>}
 */
async function getCurrentWindowId() {
    try {
        const currentWindow = await chrome.windows.getCurrent();
        return currentWindow.id;
    } catch (error) {
        console.error('[History] 获取窗口ID失败:', error);
        return null;
    }
}

/**
 * 加载历史记录统计（按窗口隔离）
 */
export async function loadHistoryStats() {
    try {
        const windowId = await getCurrentWindowId();
        const stats = await getHistoryStats(windowId);
        
        const todayCount = document.getElementById('todayCount');
        const totalCount = document.getElementById('totalCount');
        
        if (todayCount) todayCount.textContent = stats.today;
        if (totalCount) totalCount.textContent = stats.total;
        
        // 如果有记录，显示历史卡片
        if (stats.total > 0) {
            const historyCard = document.getElementById('historyCard');
            if (historyCard) historyCard.style.display = 'block';
        }
        
        console.log('[History] 加载统计完成:', { windowId, stats });
    } catch (error) {
        console.error('[History] 加载统计失败:', error);
    }
}

/**
 * 查看历史记录（按窗口隔离）
 */
export async function viewHistory() {
    try {
        const windowId = await getCurrentWindowId();
        const history = await getHistory(windowId);
        const historyList = document.getElementById('historyList');
        
        if (!historyList) return;
        
        if (history.length === 0) {
            showToast('暂无历史记录', 'info');
            return;
        }
        
        // 渲染历史列表
        historyList.innerHTML = history.map(record => createHistoryItemHTML(record)).join('');
        historyList.style.display = 'block';
        
        console.log('[History] 查看历史完成:', { windowId, count: history.length });
    } catch (error) {
        console.error('[History] 查看历史失败:', error);
        showToast('查看历史失败', 'error');
    }
}

/**
 * 隐藏历史列表
 */
export function hideHistory() {
    const historyList = document.getElementById('historyList');
    if (historyList) {
        historyList.style.display = 'none';
    }
}

/**
 * 导出历史记录（按窗口隔离，文件名包含账号信息）
 */
export async function exportHistoryToFile() {
    try {
        showToast('正在导出...', 'info');
        
        // 获取当前窗口ID
        const windowId = await getCurrentWindowId();
        
        // 尝试获取当前账号信息
        const userInfo = await getCachedUserInfo(windowId);
        let accountName = '';
        
        if (userInfo) {
            // 优先使用用户昵称（界面显示的名字），否则使用小红书号或用户ID
            accountName = userInfo.username || userInfo.redId || userInfo.userId || '';
            console.log('[History] 导出账号:', accountName, { username: userInfo.username, redId: userInfo.redId });
        }
        
        await exportHistory('excel', windowId, accountName);
        showToast('Excel导出成功！', 'success');
    } catch (error) {
        console.error('[History] 导出失败:', error);
        showToast('导出失败', 'error');
    }
}

/**
 * 清空历史记录（按窗口隔离）
 */
export async function clearHistoryRecords() {
    if (!confirm('确定要清空当前账号的历史记录吗？此操作不可恢复。')) {
        return;
    }
    
    try {
        const windowId = await getCurrentWindowId();
        await clearHistory(windowId);
        
        const historyList = document.getElementById('historyList');
        if (historyList) {
            historyList.innerHTML = '';
            historyList.style.display = 'none';
        }
        await loadHistoryStats();
        
        // 隐藏历史卡片
        const historyCard = document.getElementById('historyCard');
        if (historyCard) historyCard.style.display = 'none';
        
        showToast('历史记录已清空', 'success');
    } catch (error) {
        console.error('[History] 清空失败:', error);
        showToast('清空失败', 'error');
    }
}

/**
 * 创建历史记录项HTML
 */
function createHistoryItemHTML(record) {
    return `
        <div class="history-item">
            <div class="history-item-header">
                <div class="history-item-title" title="${record.title}">${record.title}</div>
                <div class="history-item-time">${record.time}</div>
            </div>
            <div class="history-item-meta">
                <span>👤 ${record.author}</span>
                <span>📅 ${record.date}</span>
            </div>
            <div class="history-item-actions">
                ${record.liked ? `<span class="action-badge ${getStatusClass(record.likeStatus)}">👍 ${getStatusText(record.likeStatus)}</span>` : ''}
                ${record.collected ? `<span class="action-badge ${getStatusClass(record.collectStatus)}">⭐ ${getStatusText(record.collectStatus)}</span>` : ''}
                ${record.followed ? `<span class="action-badge ${getStatusClass(record.followStatus)}">👤 ${getStatusText(record.followStatus)}</span>` : ''}
                ${record.commented ? `<span class="action-badge ${getStatusClass(record.commentStatus)}">💬 ${getStatusText(record.commentStatus)}</span>` : ''}
            </div>
            ${record.commentContent ? `<div class="history-item-comment">💬 ${record.commentContent}</div>` : ''}
        </div>
    `;
}

function getStatusClass(status) {
    const map = {
        'success': 'success',
        'skipped': 'skipped',
        'disabled': 'disabled',
        'failed': 'failed'
    };
    return map[status] || '';
}

function getStatusText(status) {
    const map = {
        'success': '成功',
        'skipped': '已有',
        'disabled': '跳过',
        'failed': '失败'
    };
    return map[status] || '';
}

