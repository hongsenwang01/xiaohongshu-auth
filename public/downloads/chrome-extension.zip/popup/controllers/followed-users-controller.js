/**
 * 已关注用户列表控制器
 * 处理已关注用户列表的UI交互和管理
 * 按窗口ID隔离存储
 */

import { 
    getFollowedUsers, 
    exportFollowedUsers, 
    importFollowedUsers, 
    clearFollowedUsers,
    parseFollowedUsersExcel 
} from '../services/followed-users.js';
import { showToast } from '../ui/toast.js';

// 存储当前窗口ID
let currentWindowId = null;

/**
 * 获取当前窗口ID
 * @returns {Promise<number|null>}
 */
async function getCurrentWindowId() {
    try {
        const window = await chrome.windows.getCurrent();
        return window.id;
    } catch (error) {
        console.error('[FollowedUsersController] 获取窗口ID失败:', error);
        return null;
    }
}

/**
 * 初始化已关注用户列表控制器（按窗口ID隔离）
 */
export async function initFollowedUsersController() {
    console.log('[FollowedUsersController] 初始化已关注用户列表控制器');
    
    // 获取当前窗口ID
    currentWindowId = await getCurrentWindowId();
    console.log('[FollowedUsersController] 当前窗口ID:', currentWindowId);
    
    // 绑定事件
    bindDownloadButton();
    bindUploadButton();
    bindClearButton();
    bindFileInput();
    
    // 加载并显示当前列表状态
    await loadFollowedUsersStatus();
}

/**
 * 绑定下载按钮事件
 */
function bindDownloadButton() {
    const downloadBtn = document.getElementById('downloadFollowedUsersBtn');
    if (!downloadBtn) return;
    
    downloadBtn.addEventListener('click', async () => {
        try {
            console.log('[FollowedUsersController] 开始导出已关注用户列表', { windowId: currentWindowId });
            await exportFollowedUsers(currentWindowId);
            showToast('已关注用户列表导出成功！', 'success');
        } catch (error) {
            console.error('[FollowedUsersController] 导出失败:', error);
            showToast(error.message || '导出失败', 'error');
        }
    });
}

/**
 * 绑定上传按钮事件
 */
function bindUploadButton() {
    const uploadBtn = document.getElementById('uploadFollowedUsersBtn');
    const fileInput = document.getElementById('followedUsersFileInput');
    
    if (!uploadBtn || !fileInput) return;
    
    uploadBtn.addEventListener('click', () => {
        fileInput.click();
    });
}

/**
 * 绑定文件输入事件
 */
function bindFileInput() {
    const fileInput = document.getElementById('followedUsersFileInput');
    if (!fileInput) return;
    
    fileInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        try {
            console.log('[FollowedUsersController] 开始解析上传的文件');
            showToast('正在解析文件...', 'info');
            
            // 使用专门的解析函数解析已关注用户列表Excel文件
            const usernames = await parseFollowedUsersExcel(file);
            
            if (!usernames || usernames.length === 0) {
                throw new Error('文件中没有有效的用户数据');
            }
            
            console.log(`[FollowedUsersController] 解析到 ${usernames.length} 个用户`, { windowId: currentWindowId });
            
            // 导入到已关注列表（传入昵称数组和窗口ID）
            const addedCount = await importFollowedUsers(usernames, currentWindowId);
            
            showToast(`成功导入 ${addedCount} 个用户到已关注列表！`, 'success');
            
            // 刷新状态显示
            await loadFollowedUsersStatus();
            
        } catch (error) {
            console.error('[FollowedUsersController] 上传失败:', error);
            showToast(error.message || '上传失败', 'error');
        } finally {
            // 清空文件输入，允许重复上传同一文件
            fileInput.value = '';
        }
    });
}

/**
 * 绑定清除按钮事件
 */
function bindClearButton() {
    const clearBtn = document.getElementById('clearFollowedUsersBtn');
    if (!clearBtn) return;
    
    clearBtn.addEventListener('click', async () => {
        if (!confirm('确定要清除当前窗口的所有已关注用户吗？此操作不可恢复。')) {
            return;
        }
        
        try {
            console.log('[FollowedUsersController] 清除已关注用户列表', { windowId: currentWindowId });
            await clearFollowedUsers(currentWindowId);
            showToast('已关注用户列表已清除', 'success');
            
            // 刷新状态显示
            await loadFollowedUsersStatus();
        } catch (error) {
            console.error('[FollowedUsersController] 清除失败:', error);
            showToast(error.message || '清除失败', 'error');
        }
    });
}

/**
 * 加载并显示已关注用户列表状态（按窗口ID隔离）
 */
async function loadFollowedUsersStatus() {
    try {
        const users = await getFollowedUsers(currentWindowId);
        const count = users.length;
        
        console.log(`[FollowedUsersController] 当前已关注用户数: ${count}`, { windowId: currentWindowId });
        
        // 更新显示
        const infoDiv = document.getElementById('followedUsersInfo');
        const countSpan = document.getElementById('followedUsersCount');
        const clearBtn = document.getElementById('clearFollowedUsersBtn');
        
        if (count > 0) {
            if (infoDiv) infoDiv.style.display = 'flex';
            if (countSpan) countSpan.textContent = count;
            if (clearBtn) clearBtn.style.display = 'inline-block';
        } else {
            if (infoDiv) infoDiv.style.display = 'none';
            if (clearBtn) clearBtn.style.display = 'none';
        }
    } catch (error) {
        console.error('[FollowedUsersController] 加载状态失败:', error);
    }
}

/**
 * 刷新已关注用户列表状态（供外部调用）
 */
export async function refreshFollowedUsersStatus() {
    await loadFollowedUsersStatus();
}

