// 快速涨粉页面脚本
import { MESSAGE_TYPES } from '../shared/constants.js';
import { showToast } from './ui/toast.js';
import { addFollowedUser, getFollowedUserNames } from './services/followed-users.js';
import { initFollowedUsersController } from './controllers/followed-users-controller.js';

// 执行状态管理
let isExecuting = false;
let shouldStop = false;
let currentWindowId = null;

/**
 * 获取当前窗口ID
 * @returns {Promise<number|null>}
 */
async function getCurrentWindowId() {
    try {
        const window = await chrome.windows.getCurrent();
        return window.id;
    } catch (error) {
        console.error('[QuickFollow] 获取窗口ID失败:', error);
        return null;
    }
}

/**
 * 发送消息到标签页（带重试机制）
 * @param {number} tabId - 标签页ID
 * @param {object} message - 消息对象
 * @param {number} maxRetries - 最大重试次数
 * @returns {Promise<object>} 响应对象
 */
async function sendMessageWithRetry(tabId, message, maxRetries = 3) {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            const response = await chrome.tabs.sendMessage(tabId, message);
            return response;
        } catch (error) {
            if (attempt < maxRetries) {
                console.log(`[Retry] 第 ${attempt} 次尝试失败，等待1秒后重试...`);
                await new Promise(resolve => setTimeout(resolve, 1000));
            } else {
                throw error;
            }
        }
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    // 获取当前窗口ID
    currentWindowId = await getCurrentWindowId();
    console.log('[QuickFollow] 当前窗口ID:', currentWindowId);
    
    // 初始化已关注用户列表控制器
    await initFollowedUsersController();
    
    // 返回按钮
    const backBtn = document.getElementById('backBtn');
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            window.location.href = chrome.runtime.getURL('side-panel.html');
        });
    }

    // 开始/停止执行按钮
    const executeBtn = document.getElementById('executeBtn');
    if (executeBtn) {
        executeBtn.addEventListener('click', async () => {
            // 如果正在执行，则停止
            if (isExecuting) {
                console.log('[QuickFollow] 用户请求停止执行');
                shouldStop = true;
                showToast('正在停止...', 'info');
                executeBtn.disabled = true;
                return;
            }
            
            // 开始执行
            const searchKeyword = document.getElementById('searchKeyword')?.value?.trim() || '互关';
            const followCount = document.getElementById('followCount')?.value || 10;
            const commentContent = document.getElementById('commentContent')?.value || '';
            
            console.log('[QuickFollow] 开始执行快速涨粉');
            console.log('[QuickFollow] 配置:', { searchKeyword, followCount, commentContent });
            
            // 更新按钮状态
            isExecuting = true;
            shouldStop = false;
            updateExecuteButton(executeBtn, true);
            
            try {
                // 获取当前标签页
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                if (!tab || !tab.url.includes('xiaohongshu.com')) {
                    showToast('请在小红书页面使用此功能', 'error');
                    isExecuting = false;
                    updateExecuteButton(executeBtn, false);
                    return;
                }
                
                // 第一步：搜索关键词
                showToast(`正在搜索"${searchKeyword}"关键词...`, 'info');
                const searchResponse = await chrome.tabs.sendMessage(tab.id, {
                    action: MESSAGE_TYPES.SEARCH_KEYWORD,
                    keyword: searchKeyword
                });
                
                if (searchResponse && searchResponse.success) {
                    showToast('搜索成功！', 'success');
                    console.log('[QuickFollow] ✅ 搜索成功');
                    
                    // 等待搜索结果加载
                    await new Promise(resolve => setTimeout(resolve, 2000));
                    
                    // 第二步和第三步：循环打开帖子并收集用户
                    showToast(`正在收集 ${followCount} 个用户...`, 'info');
                        
                        const collectedUsers = new Map(); // 使用 Map 去重，key是userId，value是userUrl
                        const maxPosts = 10; // 最多打开10个帖子
                        
                        // 生成随机的帖子访问顺序（避免每次都从第一个开始）
                        const postIndices = Array.from({ length: maxPosts }, (_, i) => i);
                        // Fisher-Yates 洗牌算法，打乱顺序
                        for (let i = postIndices.length - 1; i > 0; i--) {
                            const j = Math.floor(Math.random() * (i + 1));
                            [postIndices[i], postIndices[j]] = [postIndices[j], postIndices[i]];
                        }
                        console.log('[QuickFollow] 📋 随机帖子访问顺序:', postIndices);
                        
                        let currentPostIdx = 0; // 当前处理的帖子在随机序列中的索引
                        
                        // 获取已关注用户昵称列表，用于过滤（按窗口ID隔离）
                        const followedUserNames = await getFollowedUserNames(currentWindowId);
                        console.log(`[QuickFollow] 已加载 ${followedUserNames.length} 个已关注用户（窗口${currentWindowId}），将在收集时过滤`);
                        console.log(`[QuickFollow] 已关注用户昵称列表:`, followedUserNames);
                        showToast(`已加载 ${followedUserNames.length} 个已关注用户`, 'info');
                        
                        // 循环打开帖子收集用户（按随机顺序）
                        while (collectedUsers.size < followCount && currentPostIdx < maxPosts && !shouldStop) {
                            const postIndex = postIndices[currentPostIdx]; // 获取随机顺序中的帖子索引
                            console.log(`[QuickFollow] 📝 打开第 ${currentPostIdx + 1} 个帖子（实际索引: ${postIndex}）`);
                            showToast(`打开第 ${currentPostIdx + 1} 个帖子...`, 'info');
                            
                            // 检查是否需要停止
                            if (shouldStop) {
                                console.log('[QuickFollow] ⏹️ 用户停止执行');
                                showToast('已停止执行', 'warning');
                                break;
                            }
                            
                            // 打开帖子
                            const openPostResponse = await chrome.tabs.sendMessage(tab.id, {
                                action: MESSAGE_TYPES.OPEN_POST_BY_INDEX,
                                index: postIndex
                            });
                            
                            if (!openPostResponse || !openPostResponse.success) {
                                console.error('[QuickFollow] ❌ 打开帖子失败');
                                break;
                            }
                            
                            // 等待帖子页面加载
                            await new Promise(resolve => setTimeout(resolve, 3000));
                            
                            // 在当前帖子中收集用户
                            let scrollAttempts = 0;
                            const maxScrollAttempts = 10; // 每个帖子最多滚动10次
                            let noNewUsersCount = 0; // 连续没有新用户的次数
                            
                            console.log(`[QuickFollow] 🔍 在第 ${postIndex + 1} 个帖子中收集用户`);
                            
                            while (collectedUsers.size < followCount && scrollAttempts < maxScrollAttempts && !shouldStop) {
                                // 检查是否需要停止
                                if (shouldStop) {
                                    console.log('[QuickFollow] ⏹️ 用户停止执行');
                                    break;
                                }
                                
                                console.log(`[QuickFollow] 📊 第 ${scrollAttempts + 1} 轮收集，当前已收集 ${collectedUsers.size}/${followCount} 个用户`);
                                
                                // 获取当前页面所有符合条件的评论者（传入已收集的用户ID和已关注用户昵称）
                                const allCommentersResponse = await chrome.tabs.sendMessage(tab.id, {
                                    action: MESSAGE_TYPES.GET_ALL_RECENT_COMMENTERS,
                                    collectedUrls: Array.from(collectedUsers.keys()), // 传入已收集的用户ID数组
                                    followedUserNames: followedUserNames // 传入已关注用户昵称数组，用于过滤
                                });
                                
                                if (allCommentersResponse && allCommentersResponse.success) {
                                    const { users, totalChecked } = allCommentersResponse.data;
                                    console.log(`[QuickFollow] 📝 本轮检查了 ${totalChecked} 条评论，找到 ${users.length} 个新用户`);
                                    
                                    // 将所有新用户添加到收集列表（使用userId作为key避免重复）
                                    let addedCount = 0;
                                    for (const user of users) {
                                        if (collectedUsers.size >= followCount) {
                                            console.log(`[QuickFollow] 🎉 已收集够 ${followCount} 个用户`);
                                            break;
                                        }
                                        
                                        // 使用 userId 作为 key，userUrl 作为 value
                                        if (!collectedUsers.has(user.userId)) {
                                            collectedUsers.set(user.userId, user.userUrl);
                                            addedCount++;
                                            console.log(`[QuickFollow] ✅ 收集到用户 ${collectedUsers.size}/${followCount}: ${user.userName} (${user.timeText}) [ID: ${user.userId}]`);
                                        }
                                    }
                                    
                                    showToast(`已收集 ${collectedUsers.size}/${followCount} 个用户`, 'info');
                                    
                                    // 如果已经收集够了，退出循环
                                    if (collectedUsers.size >= followCount) {
                                        console.log(`[QuickFollow] 🎉 已收集够 ${followCount} 个用户`);
                                        break;
                                    }
                                    
                                    // 如果没有找到新用户
                                    if (users.length === 0) {
                                        noNewUsersCount++;
                                        console.log(`[QuickFollow] ⚠️ 本轮未找到新用户（连续 ${noNewUsersCount} 次）`);
                                        
                                        if (noNewUsersCount >= 5) {
                                            console.log(`[QuickFollow] ⚠️ 连续5次未找到新用户，停止收集`);
                                            break;
                                        }
                                    } else {
                                        noNewUsersCount = 0;
                                    }
                                }
                                
                                // 如果还没收集够且还可以滚动，则滚动加载更多评论
                                if (collectedUsers.size < followCount && scrollAttempts < maxScrollAttempts - 1) {
                                    scrollAttempts++;
                                    console.log(`[QuickFollow] 📜 第 ${scrollAttempts} 次滚动评论区，等待加载更多评论...`);
                                    
                                    const scrollResponse = await chrome.tabs.sendMessage(tab.id, {
                                        action: MESSAGE_TYPES.SCROLL_COMMENTS
                                    });
                                    
                                    if (scrollResponse && scrollResponse.success) {
                                        // 等待新评论加载（增加等待时间，确保评论加载完成）
                                        console.log('[QuickFollow] ⏳ 等待3秒让新评论加载...');
                                        await new Promise(resolve => setTimeout(resolve, 3000));
                                    } else {
                                        console.error('[QuickFollow] ❌ 滚动评论区失败');
                                        break;
                                    }
                                } else {
                                    // 达到最大滚动次数
                                    scrollAttempts++;
                                    break;
                                }
                            }
                            
                            // 关闭当前帖子详情（点击空白处）
                            console.log(`[QuickFollow] 关闭第 ${currentPostIdx + 1} 个帖子详情`);
                            const closeResponse = await chrome.tabs.sendMessage(tab.id, {
                                action: MESSAGE_TYPES.CLOSE_POST_DETAIL
                            });
                            
                            if (closeResponse && closeResponse.success) {
                                console.log('[QuickFollow] ✅ 帖子详情已关闭');
                            }
                            
                            // 等待关闭动画完成
                            await new Promise(resolve => setTimeout(resolve, 1000));
                            
                            // 移动到下一个帖子
                            currentPostIdx++;
                            
                            // 如果还没收集够，继续下一个帖子
                            if (collectedUsers.size < followCount && currentPostIdx < maxPosts) {
                                console.log(`[QuickFollow] 当前已收集 ${collectedUsers.size}/${followCount} 个用户，继续下一个帖子`);
                            }
                        }
                        
                        // 检查是否收集到用户或已停止
                        if (shouldStop) {
                            console.log('[QuickFollow] ⏹️ 执行已停止');
                            showToast('执行已停止', 'warning');
                            return;
                        }
                        
                        if (collectedUsers.size === 0) {
                            console.log('[QuickFollow] ❌ 未收集到任何用户');
                            showToast('未找到符合条件的用户', 'error');
                            return;
                        }
                        
                        console.log(`[QuickFollow] 🎉 收集完成！共收集 ${collectedUsers.size} 个用户`);
                        
                        // 第四步：批量关注用户
                        if (!shouldStop) {
                            showToast(`开始关注 ${collectedUsers.size} 个用户...`, 'info');
                        }
                        
                        const userUrls = Array.from(collectedUsers.values()); // 获取所有 userUrl
                        const userIds = Array.from(collectedUsers.keys()); // 获取所有 userId
                        let followedCount = 0;
                        let errorCount = 0;
                        let alreadyFollowedCount = 0; // 统计已关注的数量
                        
                        for (let i = 0; i < userUrls.length && !shouldStop; i++) {
                            // 检查是否需要停止
                            if (shouldStop) {
                                console.log('[QuickFollow] ⏹️ 用户停止执行，停止关注操作');
                                showToast('已停止执行', 'warning');
                                break;
                            }
                            
                            const userUrl = userUrls[i];
                            const userId = userIds[i];
                            console.log(`[QuickFollow] 正在关注第 ${i + 1}/${userUrls.length} 个用户`);
                            showToast(`正在关注第 ${i + 1}/${userUrls.length} 个用户...`, 'info');
                            
                            let userTab = null;
                            try {
                                // 打开用户主页
                                userTab = await chrome.tabs.create({
                                    url: userUrl,
                                    active: false
                                });
                                
                                // 等待页面加载（增加等待时间到5秒）
                                console.log(`[QuickFollow] ⏳ 等待页面加载...`);
                                await new Promise(resolve => setTimeout(resolve, 5000));
                                
                                // 获取用户信息（用于保存到已关注列表）
                                const userInfoResponse = await sendMessageWithRetry(userTab.id, {
                                    action: MESSAGE_TYPES.GET_USER_INFO
                                }, 3);
                                
                                let userName = '未知用户';
                                if (userInfoResponse && userInfoResponse.success) {
                                    userName = userInfoResponse.data.username || '未知用户';
                                }
                                
                                // 检查关注状态并执行关注（使用重试机制）
                                const followResponse = await sendMessageWithRetry(userTab.id, {
                                    action: MESSAGE_TYPES.CHECK_USER_FOLLOWED
                                }, 3);
                                
                                if (followResponse && followResponse.success) {
                                    const { followed, buttonFound } = followResponse.data;
                                    
                                    if (!buttonFound) {
                                        console.warn(`[QuickFollow] ⚠️ 用户 ${i + 1} 未找到关注按钮`);
                                        errorCount++;
                                    } else if (followed) {
                                        console.log(`[QuickFollow] ℹ️ 用户 ${i + 1} ${userName} 已关注过，记录到关注列表`);
                                        alreadyFollowedCount++;
                                        
                                        // 保存到已关注列表（按窗口ID隔离）
                                        try {
                                            await addFollowedUser({
                                                userId: userId,
                                                userName: userName,
                                                userUrl: userUrl
                                            }, currentWindowId);
                                            console.log(`[QuickFollow] ✅ 已将 ${userName} 添加到关注列表（窗口${currentWindowId}）`);
                                        } catch (error) {
                                            console.error(`[QuickFollow] ❌ 保存到关注列表失败:`, error);
                                        }
                                        
                                        followedCount++;
                                    } else {
                                        // 执行关注操作（使用重试机制）
                                        const clickResponse = await sendMessageWithRetry(userTab.id, {
                                            action: MESSAGE_TYPES.FOLLOW_USER,
                                            delay: 0
                                        }, 3);
                                        
                                        if (clickResponse && clickResponse.success) {
                                            console.log(`[QuickFollow] ✅ 用户 ${i + 1} ${userName} 关注成功`);
                                            followedCount++;
                                            
                                            // 关注成功后也保存到已关注列表（按窗口ID隔离）
                                            try {
                                                await addFollowedUser({
                                                    userId: userId,
                                                    userName: userName,
                                                    userUrl: userUrl
                                                }, currentWindowId);
                                                console.log(`[QuickFollow] ✅ 已将 ${userName} 添加到关注列表（窗口${currentWindowId}）`);
                                            } catch (error) {
                                                console.error(`[QuickFollow] ❌ 保存到关注列表失败:`, error);
                                            }
                                        } else {
                                            console.error(`[QuickFollow] ❌ 用户 ${i + 1} ${userName} 关注失败`);
                                            errorCount++;
                                        }
                                    }
                                } else {
                                    console.error(`[QuickFollow] ❌ 用户 ${i + 1} 未收到响应`);
                                    errorCount++;
                                }
                                
                            } catch (error) {
                                console.error(`[QuickFollow] ❌ 处理用户 ${i + 1} 时出错:`, error);
                                errorCount++;
                            } finally {
                                // 确保关闭用户主页标签
                                if (userTab && userTab.id) {
                                    try {
                                        await chrome.tabs.remove(userTab.id);
                                    } catch (e) {
                                        console.warn(`[QuickFollow] ⚠️ 关闭标签页失败:`, e);
                                    }
                                }
                                
                                // 等待一下，避免操作过快
                                await new Promise(resolve => setTimeout(resolve, 1000));
                            }
                        }
                        
                        // 显示最终结果
                        console.log(`[QuickFollow] 🎉 完成！成功: ${followedCount}, 失败: ${errorCount}, 已关注: ${alreadyFollowedCount}`);
                        showToast(`关注完成！成功: ${followedCount}${alreadyFollowedCount > 0 ? `, 已关注: ${alreadyFollowedCount}` : ''}, 失败: ${errorCount}`, 'success');
                } else {
                    throw new Error(searchResponse?.error || '搜索失败');
                }
                
            } catch (error) {
                console.error('[QuickFollow] ❌ 执行失败:', error);
                showToast('执行失败: ' + error.message, 'error');
            } finally {
                // 恢复按钮状态
                isExecuting = false;
                shouldStop = false;
                updateExecuteButton(executeBtn, false);
            }
        });
    }
});

/**
 * 更新执行按钮的状态
 * @param {HTMLElement} button - 按钮元素
 * @param {boolean} executing - 是否正在执行
 */
function updateExecuteButton(button, executing) {
    if (!button) return;
    
    if (executing) {
        // 正在执行：显示"停止执行"
        button.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="6" y="6" width="12" height="12"></rect>
            </svg>
            停止执行
        `;
        button.style.background = 'linear-gradient(135deg, #FF6B6B 0%, #FF2D55 100%)';
        button.disabled = false;
    } else {
        // 未执行：显示"开始执行"
        button.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polygon points="5 3 19 12 5 21 5 3"></polygon>
            </svg>
            开始执行
        `;
        button.style.background = 'linear-gradient(135deg, #FF6B6B 0%, #FF2D55 100%)';
        button.disabled = false;
    }
}
