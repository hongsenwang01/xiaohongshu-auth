import { MESSAGE_TYPES } from '../shared/constants.js';
import { checkIsXhsPage } from './services/message.js';
import { getBrowseState, restoreTaskId } from './services/state.js';
import { showToast } from './ui/toast.js';
import { showPageDetectCard, showNormalUI } from './ui/page-detect.js';
import { handleBrowseUpdate } from './handlers/browse.js';
import { getUserInfo } from './handlers/user.js';
import { launchXiaohongshu } from './utils/helpers.js';
import { 
    loadHistoryStats, 
    viewHistory, 
    hideHistory, 
    exportHistoryToFile, 
    clearHistoryRecords 
} from './handlers/history.js';
import { initFilterOptions } from './handlers/filter.js';
import { initLicensePageEvents } from './handlers/license.js';

import { tabController } from './controllers/tab-controller.js';
import { configController } from './controllers/config-controller.js';
import { browseController } from './controllers/browse-controller.js';
import { fetchController } from './controllers/fetch-controller.js';

class XiaohongshuAssistant {
    constructor() {
        this.posts = [];
        this.isFetchingPosts = false;
        this.fetchedPosts = [];
        this.init();
    }

    async init() {
        const isXhsPage = await checkIsXhsPage();
        if (!isXhsPage) {
            this.showPageDetect();
            return;
        }

        this.showNormal();
        await this.restoreState();
        this.bindEvents();
        initLicensePageEvents();
        initFilterOptions();
        this.initTabState();
        this.listenToMessages();
        await getUserInfo();
        await loadHistoryStats();
        await this.restoreDurationConfig();
        await this.restoreBrowseCountConfig();
        await this.restoreToggleStates();
        await this.restoreCommentContents();
        await this.restoreCollapseStates();
    }

    showPageDetect() {
        showPageDetectCard();

        const launchBtn = document.getElementById('launchXhsBtn');
        if (!launchBtn) return;

        launchBtn.addEventListener('click', async () => {
            try {
                showToast('正在打开小红书...', 'info');
                await launchXiaohongshu();
            } catch (error) {
                showToast('启动失败，请手动打开小红书页面', 'error');
            }
        });
    }

    showNormal() {
        showNormalUI();
    }

    bindEvents() {
        this.bindTabEvents();
        this.bindHelpTooltip();
        this.bindDurationInputs();
        this.bindToggleEvents();
        this.bindCollapsibleHeaders();

        const startBrowseBtn = document.getElementById('startBrowseBtn');
        const stopBrowseBtn = document.getElementById('stopBrowseBtn');
        const refreshUserBtn = document.getElementById('refreshUserBtn');
        const viewHistoryBtn = document.getElementById('viewHistoryBtn');
        const exportHistoryBtn = document.getElementById('exportHistoryBtn');
        const clearHistoryBtn = document.getElementById('clearHistoryBtn');
        const quickFollowBtn = document.getElementById('quickFollowBtn');

        if (startBrowseBtn) {
            startBrowseBtn.addEventListener('click', () => this.handleStartBrowse());
        }

        if (stopBrowseBtn) {
            stopBrowseBtn.addEventListener('click', () => this.handleStopBrowse());
        }

        if (refreshUserBtn) {
            refreshUserBtn.addEventListener('click', () => this.handleRefreshUser());
        }

        if (viewHistoryBtn) {
            let historyVisible = false;
            viewHistoryBtn.addEventListener('click', () => {
                if (historyVisible) {
                    hideHistory();
                    viewHistoryBtn.textContent = '查看历史';
                } else {
                    viewHistory();
                    viewHistoryBtn.textContent = '隐藏历史';
                }
                historyVisible = !historyVisible;
            });
        }

        if (exportHistoryBtn) {
            exportHistoryBtn.addEventListener('click', () => exportHistoryToFile());
        }

        if (clearHistoryBtn) {
            clearHistoryBtn.addEventListener('click', () => clearHistoryRecords());
        }

        if (quickFollowBtn) {
            quickFollowBtn.addEventListener('click', () => this.handleQuickFollow());
        }
    }

    listenToMessages() {
        chrome.runtime.onMessage.addListener((message) => {
            if (message.action === MESSAGE_TYPES.BROWSE_UPDATE) {
                handleBrowseUpdate(message);
            }
        });
    }

    async restoreState() {
        try {
            const taskId = restoreTaskId();
            if (!taskId) {
                this.setButtonState('idle');
                return;
            }

            const state = await getBrowseState(taskId);
            if (state && state.isRunning) {
                console.log('✅ 检测到任务正在运行，恢复UI状态');
                this.setButtonState('browsing');
                if (state.posts && state.posts.length > 0) {
                    this.posts = state.posts;
                    console.log(`🔄 恢复任务进度: ${state.currentIndex}/${state.totalPosts}`);
                }
            } else {
                this.setButtonState('idle');
            }
        } catch (error) {
            console.error('恢复状态失败:', error);
            this.setButtonState('idle');
        }
    }

    async handleQuickFollow() {
        try {
            // 检查授权
            console.log('[Quick Follow] 检查授权');
            const currentWindow = await chrome.windows.getCurrent();
            const windowId = currentWindow.id;
            const { getCachedUserInfo } = await import('./services/cache.js');
            const userInfo = await getCachedUserInfo(windowId);

            if (!userInfo) {
                showToast('无法获取账号信息，请刷新后重试', 'error');
                return;
            }

            if (!userInfo.licenseValid) {
                console.error('[License] 授权验证失败: 该账号未授权或授权已过期');
                showToast('该账号未授权，请绑定授权码', 'error');
                const { showLicensePage } = await import('./handlers/license.js');
                showLicensePage();
                return;
            }

            // 授权验证通过，跳转到快速涨粉页面
            console.log('[Quick Follow] 授权验证通过，跳转到快速涨粉页面');
            window.location.href = chrome.runtime.getURL('popup.html');
        } catch (error) {
            console.error('[Quick Follow] 处理失败:', error);
            showToast('操作失败，请稍后重试', 'error');
        }
    }
}

Object.assign(
    XiaohongshuAssistant.prototype,
    tabController,
    configController,
    browseController,
    fetchController
);

export default XiaohongshuAssistant;
