// 帖子信息提取模块
import { SELECTORS } from '../../shared/constants.js';

/**
 * 从页面提取帖子信息
 * @returns {Array<Object>}
 */
export function extractPostsFromPage() {
    const posts = [];

    // 查找所有的帖子section
    const sections = document.querySelectorAll(SELECTORS.POST_ITEM);
    console.log(`找到 ${sections.length} 个帖子`);
    
    sections.forEach((section, index) => {
        try {
            // 提取完整链接（带token）
            const linkElement = section.querySelector(SELECTORS.POST_LINK);
            if (!linkElement) return;
            
            const fullLink = linkElement.getAttribute('href');
            if (!fullLink) return;
            
            // 提取标题
            const titleElement = section.querySelector(SELECTORS.POST_TITLE);
            const title = titleElement ? titleElement.textContent.trim() : '无标题';
            
            // 提取作者
            const authorElement = section.querySelector(SELECTORS.POST_AUTHOR);
            const author = authorElement ? authorElement.textContent.trim() : '未知作者';
            
            // 提取用户ID（从作者链接中提取）
            let userId = null;
            const authorLinkElement = section.querySelector('a.author');
            if (authorLinkElement) {
                const authorHref = authorLinkElement.getAttribute('href');
                if (authorHref) {
                    // 从 /user/profile/{userId} 中提取 userId
                    const userIdMatch = authorHref.match(/\/user\/profile\/([a-zA-Z0-9]+)/);
                    if (userIdMatch && userIdMatch[1]) {
                        userId = userIdMatch[1];
                    }
                }
            }
            
            // 提取图片
            const imgElement = section.querySelector(SELECTORS.POST_IMAGE);
            const image = imgElement ? imgElement.src : '';
            
            // 提取点赞数
            const likeElement = section.querySelector(SELECTORS.POST_LIKES);
            const likes = likeElement ? likeElement.textContent.trim() : '0';
            
            posts.push({
                index: index + 1,
                title: title,
                author: author,
                userId: userId,  // 添加用户ID
                link: fullLink,
                fullUrl: `https://www.xiaohongshu.com${fullLink}`,
                image: image,
                likes: likes
            });
            
            console.log(`提取帖子 #${index + 1}:`, {
                title,
                author,
                link: fullLink,
                likes
            });
            
        } catch (error) {
            console.error(`提取第 ${index + 1} 个帖子失败:`, error);
        }
    });
    
    console.log(`成功提取 ${posts.length} 个帖子`);
    return posts;
}

