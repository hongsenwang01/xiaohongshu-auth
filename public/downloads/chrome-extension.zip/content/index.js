// 小红书助手 - 内容脚本主入口
import { MESSAGE_TYPES } from '../shared/constants.js';
import { performLike } from './actions/like.js';
import { performCollect } from './actions/collect.js';
import { performFollow } from './actions/follow.js';
import { performComment } from './actions/comment.js';
import { extractPostsFromPage } from './extractors/posts.js';
import { extractUserInfo } from './extractors/user.js';
import { createResponse } from '../shared/utils.js';
import { checkUserProfileFollowStatus } from './selectors/buttons.js';

// 监听来自popup和background的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    //console.log('Content Script 收到消息:', request);
    
    const { action } = request;
    
    switch (action) {
        case MESSAGE_TYPES.GET_POSTS:
            handleGetPosts(sendResponse);
            break;
            
        case MESSAGE_TYPES.LIKE_POST:
            handleLikePost(request, sendResponse);
            return true; // 异步响应
            
        case MESSAGE_TYPES.COLLECT_POST:
            handleCollectPost(request, sendResponse);
            return true; // 异步响应

        case MESSAGE_TYPES.FOLLOW_USER:
            handleFollowUser(request, sendResponse);
            return true; // 异步响应

        case MESSAGE_TYPES.COMMENT_POST:
            handleCommentPost(request, sendResponse);
            return true; // 异步响应
            
        case MESSAGE_TYPES.GET_USER_INFO:
            handleGetUserInfo(sendResponse);
            break;
            
        case MESSAGE_TYPES.CHECK_USER_FOLLOWED:
            handleCheckUserFollowed(sendResponse);
            break;
            
        case MESSAGE_TYPES.CHECK_SECURITY_CAPTCHA:
            handleCheckSecurityCaptcha(sendResponse);
            break;
            
        case MESSAGE_TYPES.SEARCH_KEYWORD:
            handleSearchKeyword(request, sendResponse);
            return true; // 异步响应
            
        case MESSAGE_TYPES.OPEN_FIRST_POST:
            handleOpenFirstPost(sendResponse);
            break;
            
        case MESSAGE_TYPES.OPEN_POST_BY_INDEX:
            handleOpenPostByIndex(request, sendResponse);
            break;
            
        case MESSAGE_TYPES.CLOSE_POST_DETAIL:
            handleClosePostDetail(sendResponse);
            break;
            
        case MESSAGE_TYPES.GET_RECENT_COMMENTER:
            handleGetRecentCommenter(request, sendResponse);
            break;
            
        case MESSAGE_TYPES.GET_ALL_RECENT_COMMENTERS:
            handleGetAllRecentCommenters(request, sendResponse);
            break;
            
        case MESSAGE_TYPES.SCROLL_COMMENTS:
            handleScrollComments(sendResponse);
            break;
            
        case 'scrollPage':
            handleScrollPage(sendResponse);
            break;
            
        default:
            sendResponse(createResponse(false, '未知的消息类型'));
    }
    
    return true; // 保持消息通道开启
});

/**
 * 处理获取帖子请求
 * @param {Function} sendResponse - 响应函数
 */
function handleGetPosts(sendResponse) {
    try {
        const posts = extractPostsFromPage();
        sendResponse(createResponse(true, posts));
    } catch (error) {
        console.error('获取帖子失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理点赞请求
 * @param {Object} request - 请求对象
 * @param {Function} sendResponse - 响应函数
 */
async function handleLikePost(request, sendResponse) {
    try {
        const result = await performLike(request.delay);
        sendResponse(result);
    } catch (error) {
        console.error('点赞操作失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理收藏请求
 * @param {Object} request - 请求对象
 * @param {Function} sendResponse - 响应函数
 */
async function handleCollectPost(request, sendResponse) {
    try {
        const result = await performCollect(request.delay);
        sendResponse(result);
    } catch (error) {
        console.error('收藏操作失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理关注请求
 * @param {Object} request - 请求对象
 * @param {Function} sendResponse - 响应函数
 */
async function handleFollowUser(request, sendResponse) {
    try {
        const result = await performFollow(request.delay);
        sendResponse(result);
    } catch (error) {
        console.error('关注操作失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理评论请求
 * @param {Object} request - 请求对象
 * @param {Function} sendResponse - 响应函数
 */
async function handleCommentPost(request, sendResponse) {
    try {
        const result = await performComment(request.delay, request.content);
        sendResponse(result);
    } catch (error) {
        console.error('评论操作失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理获取用户信息请求
 * @param {Function} sendResponse - 响应函数
 */
function handleGetUserInfo(sendResponse) {
    try {
        const userInfo = extractUserInfo();
        sendResponse(createResponse(true, userInfo));
    } catch (error) {
        console.error('获取用户信息失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理检查用户主页关注状态请求
 * @param {Function} sendResponse - 响应函数
 */
function handleCheckUserFollowed(sendResponse) {
    try {
        const result = checkUserProfileFollowStatus();
        sendResponse(createResponse(true, result));
    } catch (error) {
        console.error('检查关注状态失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理检查安全验证请求
 * @param {Function} sendResponse - 响应函数
 */
function handleCheckSecurityCaptcha(sendResponse) {
    try {
        const captchaHeader = document.querySelector('.red-captcha-header');
        const captchaTitle = document.querySelector('.red-captcha-title');
        
        const hasCaptcha = !!(captchaHeader || captchaTitle);
        
        if (hasCaptcha) {
            console.log('[SecurityCheck] 🚨 检测到安全验证页面');
        }
        
        sendResponse(createResponse(true, { hasCaptcha }));
    } catch (error) {
        console.error('检查安全验证失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理搜索关键词请求
 * @param {Object} request - 请求对象
 * @param {Function} sendResponse - 响应函数
 */
async function handleSearchKeyword(request, sendResponse) {
    try {
        const { keyword } = request;
        console.log(`[Search] 🔍 开始搜索关键词: ${keyword}`);
        
        // 查找搜索输入框
        const searchInput = document.querySelector('#search-input');
        if (!searchInput) {
            throw new Error('未找到搜索输入框');
        }
        
        // 清空并输入关键词
        searchInput.value = '';
        searchInput.focus();
        
        // 模拟真实输入
        await new Promise(resolve => setTimeout(resolve, 200));
        searchInput.value = keyword;
        
        // 触发 input 事件
        const inputEvent = new Event('input', { bubbles: true });
        searchInput.dispatchEvent(inputEvent);
        
        // 等待一下让页面响应
        await new Promise(resolve => setTimeout(resolve, 300));
        
        // 触发回车事件
        const keydownEvent = new KeyboardEvent('keydown', {
            key: 'Enter',
            code: 'Enter',
            keyCode: 13,
            which: 13,
            bubbles: true
        });
        searchInput.dispatchEvent(keydownEvent);
        
        const keypressEvent = new KeyboardEvent('keypress', {
            key: 'Enter',
            code: 'Enter',
            keyCode: 13,
            which: 13,
            bubbles: true
        });
        searchInput.dispatchEvent(keypressEvent);
        
        const keyupEvent = new KeyboardEvent('keyup', {
            key: 'Enter',
            code: 'Enter',
            keyCode: 13,
            which: 13,
            bubbles: true
        });
        searchInput.dispatchEvent(keyupEvent);
        
        console.log('[Search] ✅ 搜索关键词成功');
        sendResponse(createResponse(true, '搜索成功'));
    } catch (error) {
        console.error('[Search] ❌ 搜索失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理打开第一个帖子请求
 * @param {Function} sendResponse - 响应函数
 */
function handleOpenFirstPost(sendResponse) {
    try {
        console.log('[OpenPost] 🔍 查找第一个帖子');
        
        // 查找第一个帖子链接
        const firstPost = document.querySelector('section.note-item a.cover');
        if (!firstPost) {
            throw new Error('未找到帖子');
        }
        
        const postUrl = firstPost.href;
        console.log('[OpenPost] 📝 找到帖子:', postUrl);
        
        // 点击打开帖子
        firstPost.click();
        
        console.log('[OpenPost] ✅ 已打开第一个帖子');
        sendResponse(createResponse(true, { url: postUrl }));
    } catch (error) {
        console.error('[OpenPost] ❌ 打开帖子失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理按索引打开帖子请求
 * @param {Object} request - 请求对象
 * @param {Function} sendResponse - 响应函数
 */
function handleOpenPostByIndex(request, sendResponse) {
    try {
        const { index } = request;
        console.log(`[OpenPost] 🔍 查找第 ${index + 1} 个帖子`);
        
        // 查找所有帖子
        const posts = document.querySelectorAll('section.note-item a.cover');
        if (posts.length === 0) {
            throw new Error('未找到帖子');
        }
        
        if (index >= posts.length) {
            throw new Error(`只有 ${posts.length} 个帖子，无法打开第 ${index + 1} 个`);
        }
        
        const post = posts[index];
        const postUrl = post.href;
        console.log(`[OpenPost] 📝 找到第 ${index + 1} 个帖子:`, postUrl);
        
        // 点击打开帖子
        post.click();
        
        console.log(`[OpenPost] ✅ 已打开第 ${index + 1} 个帖子`);
        sendResponse(createResponse(true, { url: postUrl, index }));
    } catch (error) {
        console.error('[OpenPost] ❌ 打开帖子失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理关闭帖子详情请求
 * @param {Function} sendResponse - 响应函数
 */
function handleClosePostDetail(sendResponse) {
    try {
        console.log('[ClosePost] 🔍 查找关闭按钮');
        
        // 方法1: 查找帖子详情页的关闭按钮（优先使用）
        const closeCircle = document.querySelector('.close-circle .close');
        if (closeCircle) {
            console.log('[ClosePost] ✅ 找到关闭圆圈按钮，点击');
            closeCircle.click();
            sendResponse(createResponse(true, '已关闭帖子详情'));
            return;
        }
        
        // 方法2: 查找其他关闭按钮
        const closeButton = document.querySelector('.close-mask-dark, .close');
        if (closeButton && closeButton.closest('.close-circle')) {
            console.log('[ClosePost] ✅ 找到关闭按钮，点击');
            closeButton.click();
            sendResponse(createResponse(true, '已关闭帖子详情'));
            return;
        }
        
        // 方法3: 按 ESC 键
        console.log('[ClosePost] 使用 ESC 键关闭');
        const escEvent = new KeyboardEvent('keydown', {
            key: 'Escape',
            code: 'Escape',
            keyCode: 27,
            which: 27,
            bubbles: true
        });
        document.dispatchEvent(escEvent);
        
        console.log('[ClosePost] ✅ 已尝试关闭帖子详情');
        sendResponse(createResponse(true, '已尝试关闭帖子详情'));
    } catch (error) {
        console.error('[ClosePost] ❌ 关闭失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 判断时间是否在1天内
 * @param {string} timeText - 时间文本，如"刚刚"、"4分钟前"、"2小时前"、"1天前"
 * @returns {boolean}
 */
function isWithin1Day(timeText) {
    if (!timeText) return false;
    
    timeText = timeText.trim();
    console.log('[TimeCheck] 检查时间:', timeText);
    
    // "刚刚" 肯定在1天内
    if (timeText === '刚刚' || timeText === '刚才') {
        console.log('[TimeCheck] ✅ 时间: 刚刚');
        return true;
    }
    
    // 匹配 "X分钟前"
    const minuteMatch = timeText.match(/^(\d+)分钟前$/);
    if (minuteMatch) {
        console.log('[TimeCheck] ✅ 时间: 分钟前');
        return true; // 任何分钟数都在1天内
    }
    
    // 匹配 "X小时前"
    const hourMatch = timeText.match(/^(\d+)小时前$/);
    if (hourMatch) {
        const hours = parseInt(hourMatch[1], 10);
        const result = hours <= 24;
        console.log(`[TimeCheck] ${result ? '✅' : '❌'} 时间: ${hours}小时前`);
        return result;
    }
    
    // 匹配 "1天前"
    const dayMatch = timeText.match(/^(\d+)天前$/);
    if (dayMatch) {
        const days = parseInt(dayMatch[1], 10);
        const result = days <= 1;
        console.log(`[TimeCheck] ${result ? '✅' : '❌'} 时间: ${days}天前`);
        return result;
    }
    
    // 其他情况（周、月等）都不在1天内
    console.log('[TimeCheck] ❌ 时间超过1天:', timeText);
    return false;
}

/**
 * 处理获取最近评论者请求
 * @param {Object} request - 请求对象，包含 collectedUrls（已收集的用户URL数组）
 * @param {Function} sendResponse - 响应函数
 */
function handleGetRecentCommenter(request, sendResponse) {
    try {
        const collectedUrls = request.collectedUrls || [];
        console.log('[GetCommenter] 🔍 查找1天内的评论者');
        console.log(`[GetCommenter] 已收集的用户数: ${collectedUrls.length}`);
        
        // 查找所有一级评论（parent-comment）
        const parentComments = document.querySelectorAll('.parent-comment');
        console.log(`[GetCommenter] 找到 ${parentComments.length} 条一级评论`);
        console.log('[GetCommenter] ========== 开始检查每条评论 ==========');
        
        if (parentComments.length === 0) {
            throw new Error('未找到评论');
        }
        
        let checkCount = 0;
        // 遍历评论，找到1天内且未收集过的第一个
        for (const comment of parentComments) {
            checkCount++;
            
            // 获取时间
            const dateSpan = comment.querySelector('.date span');
            if (!dateSpan) {
                console.log(`[GetCommenter] [${checkCount}] ⚠️ 未找到时间元素，跳过`);
                continue;
            }
            
            const timeText = dateSpan.textContent.trim();
            
            // 获取用户信息（先获取，用于日志输出）
            const authorLink = comment.querySelector('.author .name');
            const userName = authorLink ? authorLink.textContent.trim() : '未知用户';
            const userUrl = authorLink ? authorLink.href : '';
            
            // 输出每条评论的详细信息
            console.log(`[GetCommenter] [${checkCount}] 👤 用户: ${userName}`);
            console.log(`[GetCommenter] [${checkCount}] ⏰ 时间: ${timeText}`);
            
            // 判断是否在1天内
            const isWithinTime = isWithin1Day(timeText);
            console.log(`[GetCommenter] [${checkCount}] ${isWithinTime ? '✅' : '❌'} 时间判断: ${isWithinTime ? '符合' : '不符合'}1天内`);
            
            if (!isWithinTime) {
                continue;
            }
            
            if (!authorLink) {
                console.log(`[GetCommenter] [${checkCount}] ⚠️ 未找到用户链接，跳过`);
                continue;
            }
            
            // 检查是否已收集过
            const isCollected = collectedUrls.includes(userUrl);
            console.log(`[GetCommenter] [${checkCount}] ${isCollected ? '⚠️ 已收集过' : '🎯 未收集'}: ${userUrl}`);
            
            if (isCollected) {
                continue;
            }
            
            // 找到符合条件的评论者
            console.log(`[GetCommenter] [${checkCount}] ✅✅✅ 找到新的1天内评论者: ${userName}`);
            console.log(`[GetCommenter] 用户链接: ${userUrl}`);
            console.log(`[GetCommenter] 评论时间: ${timeText}`);
            console.log('[GetCommenter] ========== 检查完成 ==========');
            
            sendResponse(createResponse(true, {
                userName,
                userUrl,
                timeText
            }));
            return;
        }
        
        console.log('[GetCommenter] ========== 检查完成 ==========');
        console.log(`[GetCommenter] 共检查了 ${checkCount} 条评论，未找到新的符合条件的评论者`);
        
        // 没有找到1天内的评论
        throw new Error('未找到1天内的新评论者');
        
    } catch (error) {
        console.error('[GetCommenter] ❌ 获取评论者失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理获取所有最近评论者请求（返回所有符合条件的用户，而不是只返回第一个）
 * @param {Object} request - 请求对象，包含 collectedUrls（已收集的用户ID数组）和 followedUserNames（已关注用户昵称数组）
 * @param {Function} sendResponse - 响应函数
 */
function handleGetAllRecentCommenters(request, sendResponse) {
    try {
        const collectedUrls = request.collectedUrls || [];
        const followedUserNames = request.followedUserNames || [];
        console.log('[GetAllCommenters] 🔍 查找所有1天内的评论者');
        console.log(`[GetAllCommenters] 已收集的用户数: ${collectedUrls.length}`);
        console.log(`[GetAllCommenters] 已关注用户昵称数: ${followedUserNames.length}`);
        
        // 查找所有一级评论（parent-comment）
        const parentComments = document.querySelectorAll('.parent-comment');
        console.log(`[GetAllCommenters] 找到 ${parentComments.length} 条一级评论`);
        console.log('[GetAllCommenters] ========== 开始检查每条评论 ==========');
        
        if (parentComments.length === 0) {
            throw new Error('未找到评论');
        }
        
        const newUsers = [];
        let checkCount = 0;
        
        // 遍历所有评论，收集所有符合条件且未收集过的用户
        for (const comment of parentComments) {
            checkCount++;
            
            // 获取时间
            const dateSpan = comment.querySelector('.date span');
            if (!dateSpan) {
                console.log(`[GetAllCommenters] [${checkCount}] ⚠️ 未找到时间元素，跳过`);
                continue;
            }
            
            const timeText = dateSpan.textContent.trim();
            
            // 获取用户信息
            const authorLink = comment.querySelector('.author .name');
            const userName = authorLink ? authorLink.textContent.trim() : '未知用户';
            const userUrl = authorLink ? authorLink.href : '';
            
            // 提取用户ID（从URL中提取，避免参数不同导致重复）
            let userId = '';
            if (userUrl) {
                const userIdMatch = userUrl.match(/\/user\/profile\/([a-zA-Z0-9]+)/);
                userId = userIdMatch ? userIdMatch[1] : userUrl;
            }
            
            // 输出每条评论的详细信息
            console.log(`[GetAllCommenters] [${checkCount}] 👤 用户: ${userName}`);
            console.log(`[GetAllCommenters] [${checkCount}] 🆔 用户ID: ${userId}`);
            console.log(`[GetAllCommenters] [${checkCount}] ⏰ 时间: ${timeText}`);
            
            // 判断是否在1天内
            const isWithinTime = isWithin1Day(timeText);
            console.log(`[GetAllCommenters] [${checkCount}] ${isWithinTime ? '✅' : '❌'} 时间判断: ${isWithinTime ? '符合' : '不符合'}1天内`);
            
            if (!isWithinTime) {
                continue;
            }
            
            if (!authorLink || !userId) {
                console.log(`[GetAllCommenters] [${checkCount}] ⚠️ 未找到用户链接或ID，跳过`);
                continue;
            }
            
            // 检查是否已收集过（使用用户ID检查）
            const isCollected = collectedUrls.includes(userId);
            console.log(`[GetAllCommenters] [${checkCount}] ${isCollected ? '⚠️ 已收集过' : '🎯 未收集'}: ${userId}`);
            
            if (isCollected) {
                continue;
            }
            
            // 检查是否已在关注列表中（只通过昵称过滤）
            const isFollowed = followedUserNames.includes(userName);
            console.log(`[GetAllCommenters] [${checkCount}] ${isFollowed ? '⚠️ 已在关注列表' : '✅ 不在关注列表'}: ${userName}`);
            
            if (isFollowed) {
                console.log(`[GetAllCommenters] [${checkCount}] ⏭️ 跳过已关注用户: ${userName}`);
                continue;
            }
            
            // 添加到结果数组
            console.log(`[GetAllCommenters] [${checkCount}] ✅✅✅ 添加新用户: ${userName}`);
            newUsers.push({
                userName,
                userUrl,
                userId,
                timeText
            });
        }
        
        console.log('[GetAllCommenters] ========== 检查完成 ==========');
        console.log(`[GetAllCommenters] 共检查了 ${checkCount} 条评论，找到 ${newUsers.length} 个新的符合条件的用户`);
        
        sendResponse(createResponse(true, {
            users: newUsers,
            totalChecked: checkCount
        }));
        
    } catch (error) {
        console.error('[GetAllCommenters] ❌ 获取评论者失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理滚动评论区请求
 * @param {Function} sendResponse - 响应函数
 */
function handleScrollComments(sendResponse) {
    try {
        console.log('[ScrollComments] 📜 滚动评论区');
        
        // 查找 note-scroller 容器（帖子详情页的滚动容器）
        const noteScroller = document.querySelector('.note-scroller');
        if (!noteScroller) {
            console.error('[ScrollComments] ❌ 未找到 .note-scroller 容器');
            sendResponse(createResponse(false, '未找到评论区滚动容器'));
            return;
        }
        
        console.log('[ScrollComments] ✅ 找到 .note-scroller 容器');
        
        // 记录滚动前的评论数量
        const commentsBefore = document.querySelectorAll('.parent-comment').length;
        console.log(`[ScrollComments] 滚动前评论数: ${commentsBefore}`);
        
        // 滚动 note-scroller 容器到底部
        const scrollHeight = noteScroller.scrollHeight;
        const currentScroll = noteScroller.scrollTop;
        console.log(`[ScrollComments] 当前滚动位置: ${currentScroll}, 总高度: ${scrollHeight}`);
        
        noteScroller.scrollTo({
            top: scrollHeight,
            behavior: 'smooth'
        });
        
        console.log(`[ScrollComments] ✅ 已滚动到底部`);
        
        sendResponse(createResponse(true, { commentsBefore }));
    } catch (error) {
        console.error('[ScrollComments] ❌ 滚动失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

/**
 * 处理滚动页面请求
 * @param {Function} sendResponse - 响应函数
 */
function handleScrollPage(sendResponse) {
    try {
        console.log('[Content] 📜 执行页面滚动');
        
        // 滚动到页面底部
        window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: 'smooth'
        });
        
        // 备用方案
        setTimeout(() => {
            document.documentElement.scrollTop = document.documentElement.scrollHeight;
        }, 100);
        
        sendResponse(createResponse(true, '滚动完成'));
    } catch (error) {
        console.error('滚动页面失败:', error);
        sendResponse(createResponse(false, error.message));
    }
}

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', () => {
    console.log('小红书助手 Content Script 已加载');
    console.log('当前页面:', window.location.href);
});

//console.log('小红书助手 Content Script 初始化完成');

