// 存储管理服务

/**
 * 保存浏览状态
 * @param {Object} state - 浏览状态对象
 * @returns {Promise<void>}
 */
export async function saveBrowseState(state) {
    try {
        await chrome.storage.local.set({ browseState: state });
    } catch (error) {
        console.error('保存状态失败:', error);
    }
}

/**
 * 获取浏览状态
 * @returns {Promise<Object|null>}
 */
export async function loadBrowseState() {
    try {
        const result = await chrome.storage.local.get(['browseState']);
        return result.browseState || null;
    } catch (error) {
        console.error('加载状态失败:', error);
        return null;
    }
}

/**
 * 清除浏览状态
 * @returns {Promise<void>}
 */
export async function clearBrowseState() {
    try {
        await chrome.storage.local.remove(['browseState']);
    } catch (error) {
        console.error('清除状态失败:', error);
    }
}

